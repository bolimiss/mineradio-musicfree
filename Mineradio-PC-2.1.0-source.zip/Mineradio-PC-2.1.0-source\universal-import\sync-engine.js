'use strict';

const { diffTracks, toPlaylist } = require('./models');
const { detectPlatform } = require('./platform-detector');

class PlaylistSyncEngine {
  constructor(options) {
    this.database = options.database;
    this.parse = options.parse;
    this.intervalMs = Math.max(1000, Number(options.intervalMs) || 5000);
    this.running = false;
    this.timer = null;
    this.lastCycle = { startedAt: 0, finishedAt: 0, checked: 0, updated: 0, failures: [] };
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.syncAll('scheduler').catch(() => {}), this.intervalMs);
    if (this.timer.unref) this.timer.unref();
  }

  stop() { if (this.timer) clearInterval(this.timer); this.timer = null; }

  async syncOne(id, reason = 'manual') {
    const existing = this.database.get(id);
    if (!existing) throw new Error('PLAYLIST_NOT_FOUND');
    const platform = existing.platform || detectPlatform(existing.sourceUrl).id;
    this.database.upsert(Object.assign({}, existing, { syncStatus: 'syncing' }));
    try {
      const raw = await this.parse(existing.sourceUrl, platform);
      const incoming = toPlaylist(raw, { platform, sourceUrl: existing.sourceUrl });
      const diff = diffTracks(existing.tracks, incoming.tracks);
      const saved = this.database.upsert(Object.assign({}, existing, incoming, {
        id: existing.id,
        playlistId: existing.playlistId,
        sourceUrl: existing.sourceUrl,
        autoSync: existing.autoSync !== false,
        syncTime: Date.now(),
        lastSyncTime: Date.now(),
        syncStatus: diff.changed ? 'updated' : 'unchanged',
        lastDiff: { added: diff.added.length, removed: diff.removed.length, updated: diff.updated.length },
        lastSyncError: '',
      }));
      this.database.event(diff.changed ? 'playlist-updated' : 'playlist-unchanged', { id: existing.id, reason, diff: saved.lastDiff });
      return { playlist: saved, diff };
    } catch (error) {
      this.database.upsert(Object.assign({}, existing, { syncStatus: 'error', lastSyncTime: Date.now(), lastSyncError: error.code || error.message || 'SYNC_FAILED' }));
      this.database.event('playlist-sync-failed', { id: existing.id, reason, error: error.code || error.message || 'SYNC_FAILED' });
      throw error;
    }
  }

  async syncAll(reason = 'manual') {
    if (this.running) return Object.assign({ skipped: true }, this.lastCycle);
    this.running = true;
    const cycle = { startedAt: Date.now(), finishedAt: 0, checked: 0, updated: 0, failures: [] };
    try {
      for (const playlist of this.database.list().filter(item => item.autoSync !== false)) {
        try {
          const result = await this.syncOne(playlist.id, reason);
          cycle.checked += 1;
          if (result.diff.changed) cycle.updated += 1;
        } catch (error) {
          cycle.checked += 1;
          cycle.failures.push({ id: playlist.id, error: error.code || error.message || 'SYNC_FAILED' });
        }
      }
      return cycle;
    } finally {
      cycle.finishedAt = Date.now();
      this.lastCycle = cycle;
      this.running = false;
    }
  }

  status() { return { running: this.running, intervalMs: this.intervalMs, lastCycle: this.lastCycle }; }
}

module.exports = { PlaylistSyncEngine };
