// ============================================================
function animateListItems(container, selector, opts) {
  if (!container || !window.gsap) return;
  opts = opts || {};
  var items = Array.prototype.slice.call(container.querySelectorAll(selector));
  if (!items.length) return;
  var limit = opts.limit || 18;
  var targets = items.slice(0, limit);
  window.gsap.killTweensOf(targets);
  window.gsap.fromTo(targets, {
    autoAlpha: 0,
    y: opts.y == null ? 8 : opts.y,
    x: opts.x == null ? -6 : opts.x
  }, {
    autoAlpha: 1,
    y: 0,
    x: 0,
    duration: opts.duration || 0.22,
    stagger: opts.stagger || 0.012,
    ease: opts.ease || 'power2.out',
    force3D: true,
    overwrite: true
  });
}
function smoothScrollToItem(scroller, item, opts) {
  if (!scroller || !item) return;
  opts = opts || {};
  var target = item.offsetTop - Math.max(0, (scroller.clientHeight - item.offsetHeight) * (opts.align == null ? 0.42 : opts.align));
  target = Math.max(0, Math.min(target, Math.max(0, scroller.scrollHeight - scroller.clientHeight)));
  if (window.gsap) {
    if (typeof scroller.__syncSmoothWheelTarget === 'function') scroller.__syncSmoothWheelTarget(target);
    window.gsap.killTweensOf(scroller);
    window.gsap.to(scroller, { scrollTop: target, duration: opts.duration || 0.30, ease: opts.ease || 'power2.out', overwrite: true });
  } else if (scroller.scrollTo) {
    scroller.scrollTo({ top: target, behavior: 'smooth' });
  } else {
    scroller.scrollTop = target;
  }
}
function bindSmoothWheelScroll(scroller) {
  if (!scroller || scroller.__smoothWheelBound) return;
  scroller.__smoothWheelBound = true;
  var targetTop = scroller.scrollTop;
  var tween = null;
  scroller.__syncSmoothWheelTarget = function (top) {
    if (tween) {
      tween.kill();
      tween = null;
    }
    targetTop = isFinite(top) ? top : scroller.scrollTop;
  };
  scroller.addEventListener('wheel', function (e) {
    if (!window.gsap || e.ctrlKey) return;
    var max = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    if (max <= 0 || Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
    var delta = e.deltaY;
    if (e.deltaMode === 1) delta *= 18;
    else if (e.deltaMode === 2) delta *= scroller.clientHeight;
    var current = tween ? targetTop : scroller.scrollTop;
    var next = Math.max(0, Math.min(max, current + delta));
    if (next === current && ((delta < 0 && scroller.scrollTop <= 0) || (delta > 0 && scroller.scrollTop >= max - 1))) {
      targetTop = scroller.scrollTop;
      return;
    }
    e.preventDefault();
    targetTop = next;
    if (tween) tween.kill();
    tween = window.gsap.to(scroller, {
      scrollTop: targetTop,
      duration: 0.24,
      ease: 'power2.out',
      overwrite: true,
      onComplete: function () {
        tween = null;
        targetTop = scroller.scrollTop;
      }
    });
  }, { passive: false });
  scroller.addEventListener('scroll', function () {
    if (!tween) targetTop = scroller.scrollTop;
  }, { passive: true });
}
function bindSmoothQueueScrolling() {
  if (smoothWheelScrollBound) return;
  smoothWheelScrollBound = true;
  [
    'mini-queue-list',
    'search-results',
    'fx-panel',
    'playlist-panel',
    'track-detail-body'
  ].forEach(function (id) {
    bindSmoothWheelScroll(document.getElementById(id));
  });
}
function animateVisiblePanelList(listEl, selector, scroller, activeSelector, opts) {
  if (!listEl) return;
  opts = opts || {};
  requestAnimationFrame(function () {
    animateListItems(listEl, selector, { x: -8, y: 6, stagger: 0.01, duration: 0.20, limit: 16 });
    var active = activeSelector ? listEl.querySelector(activeSelector) : null;
    if (active && scroller && opts.scrollActive !== false) smoothScrollToItem(scroller, active, { duration: 0.32 });
  });
}
function miniQueueSkeleton() {
  return '<div class="mini-queue-skeleton"></div><div class="mini-queue-skeleton"></div><div class="mini-queue-skeleton"></div>';
}
function queueHydrationExpectedTotal() {
  var loaded = playQueue && playQueue.length || 0;
  if (!queueHydrationState || queueHydrationState.queueRef !== playQueue) return loaded;
  if (!queueHydrationState.active && !queueHydrationState.loading && !queueHydrationState.error) return loaded;
  return Math.max(loaded, Number(queueHydrationState.total) || 0);
}
function queueHydrationFooterHtml(compact) {
  if (!queueHydrationState || queueHydrationState.queueRef !== playQueue) return '';
  var loaded = playQueue.length;
  var total = queueHydrationExpectedTotal();
  if (!queueHydrationState.active && !queueHydrationState.error && (!total || loaded >= total)) return '';
  var label = queueHydrationState.error
    ? ('后续歌曲载入中断 · 已准备 ' + loaded + (total ? '/' + total : ''))
    : (queueHydrationState.loading
      ? ('正在载入下一批 · ' + loaded + (total ? '/' + total : ''))
      : ('已准备 ' + loaded + (total ? '/' + total : '') + ' · 播放或滚动到末尾时继续'));
  var retry = queueHydrationState.error
    ? '<button type="button" class="queue-hydration-retry" onclick="event.stopPropagation();retryPlaylistQueueHydration()">重试</button>'
    : (queueHydrationState.active && !queueHydrationState.loading
      ? '<button type="button" class="queue-hydration-retry" onclick="event.stopPropagation();requestPlaylistQueueHydrationForBrowse()">再载一批</button>'
      : '');
  return '<div class="queue-hydration-status' + (compact ? ' compact' : '') + '">' +
    '<span class="queue-hydration-spinner' + (queueHydrationState.loading ? ' spinning' : '') + '"></span>' +
    '<span>' + label + '</span>' + retry + '</div>';
}
function togglePlaylistPanel(force) {
  var el = document.getElementById('playlist-panel');
  if (force === false) el.classList.remove('show');
  else if (force === true) el.classList.add('show');
  else el.classList.toggle('show');
  if (el.classList.contains('show')) {
    markPlaylistPanelMotion(el, playlistPanelMotionMs('open'));
    var runPlaylistOpenAnimation = shouldAnimatePlaylistPanelOpen(el);
    scheduleUiWarmTask(function () {
      flushDeferredQueuePanel('playlist-panel-open');
      preparePlaylistPanelTabOnOpen(el);
      if (runPlaylistOpenAnimation) animatePlaylistPanelCurrentTab(el, { scrollActive: false });
    }, 180);
  }
}
function closePlaylistPanelSoft(reason) {
  var panel = document.getElementById('playlist-panel');
  if (!panel || playlistPanelPinned) return false;
  if (!panel.classList.contains('peek') && !panel.classList.contains('show')) return false;
  if (peekTimers.pl) { clearTimeout(peekTimers.pl); peekTimers.pl = null; }
  if (typeof resetSecondaryPlaylistEdgeGuard === 'function') resetSecondaryPlaylistEdgeGuard();
  panel.classList.add('playlist-panel-closing');
  panel.classList.remove('peek', 'show');
  markPlaylistPanelMotion(panel, playlistPanelMotionMs('close'));
  setTimeout(function () { panel.classList.remove('playlist-panel-closing'); }, playlistPanelMotionMs('close') + 80);
  return true;
}
function applyPlaylistPanelPinState(openPanel) {
  var panel = document.getElementById('playlist-panel');
  var btn = document.getElementById('playlist-pin-btn');
  if (panel) {
    panel.classList.toggle('pinned', !!playlistPanelPinned);
    if (playlistPanelPinned || openPanel) {
      panel.dataset.preserveTabOnOpen = '1';
      setPeek(panel, true, 'pl');
    }
  }
  if (btn) {
    btn.classList.toggle('active', !!playlistPanelPinned);
    btn.title = playlistPanelPinned ? '取消常开歌单' : '常开歌单';
  }
}
function setPlaylistPanelPinned(on, silent) {
  playlistPanelPinned = !!on;
  saveBooleanPreference(PLAYLIST_PANEL_PIN_STORE_KEY, playlistPanelPinned);
  applyPlaylistPanelPinState(playlistPanelPinned);
  if (!silent) showToast(playlistPanelPinned ? '左侧歌单已常开' : '左侧歌单已恢复自动隐藏');
}
function togglePlaylistPanelPinned() {
  setPlaylistPanelPinned(!playlistPanelPinned);
}
function scrollPlaylistPanelToCurrent() {
  var panel = document.getElementById('playlist-panel');
  var list = document.getElementById('queue-list');
  if (!panel || !list || queueViewTab !== 'queue') return;
  var now = performance.now();
  if (panel.__lastCurrentScrollAt && now - panel.__lastCurrentScrollAt < 650) return;
  panel.__lastCurrentScrollAt = now;
  requestAnimationFrame(function () {
    renderQueuePanel({ animate: false, scrollCurrent: true });
    smoothScrollToItem(panel, list.querySelector('.queue-item.now'), { duration: 0.28, align: 0.34 });
  });
}
function animatePlaylistPanelCurrentTab(panel, opts) {
  opts = opts || {};
  panel = panel || document.getElementById('playlist-panel');
  if (queueViewTab === 'queue') {
    animateVisiblePanelList(document.getElementById('queue-list'), '.queue-item', panel, '.queue-item.now', { scrollActive: opts.scrollActive !== false });
  } else if (queueViewTab === 'playlists') {
    animateVisiblePanelList(document.getElementById('pl-list'), '.pl-card', panel);
  } else {
    animateVisiblePanelList(document.getElementById('podcast-list'), '.pl-card', panel);
  }
}
function preparePlaylistPanelTabOnOpen(panel) {
  var preserve = !!(panel && panel.dataset && panel.dataset.preserveTabOnOpen === '1');
  if (preserve && panel.dataset) {
    delete panel.dataset.preserveTabOnOpen;
  } else if (!playQueue.length && queueViewTab === 'queue') {
    switchPlaylistTab('playlists', { save: false, animate: false, refresh: false });
  }
  if (queueViewTab === 'queue') scrollPlaylistPanelToCurrent();
  else if (queueViewTab === 'playlists') renderSideMusicLibrary();
  else if (queueViewTab === 'podcasts') refreshUserPlaylists();
}
function switchPlaylistTab(tab, opts) {
  opts = opts || {};
  tab = normalizePlaylistPanelTab(tab);
  queueViewTab = tab;
  if (opts.save !== false) savePlaylistPanelTabPreference(tab);
  var queueTab = document.getElementById('tab-queue');
  var playlistTab = document.getElementById('tab-pl');
  if (queueTab) queueTab.classList.toggle('active', tab === 'queue');
  if (playlistTab) playlistTab.classList.toggle('active', tab === 'playlists');
  var podcastTab = document.getElementById('tab-podcast');
  if (podcastTab) podcastTab.classList.toggle('active', tab === 'podcasts');
  var queuePane = document.getElementById('queue-pane');
  var playlistPane = document.getElementById('pl-pane');
  if (queuePane) queuePane.style.display = tab === 'queue' ? '' : 'none';
  if (playlistPane) playlistPane.style.display = tab === 'playlists' ? '' : 'none';
  var podcastPane = document.getElementById('podcast-pane');
  if (podcastPane) podcastPane.style.display = tab === 'podcasts' ? '' : 'none';
  if (tab === 'playlists' && opts.refresh !== false) renderSideMusicLibrary();
  else if (tab === 'podcasts' && opts.refresh !== false) refreshUserPlaylists();
  if (opts.animate !== false) animatePlaylistPanelCurrentTab(document.getElementById('playlist-panel'));
}
function setMiniQueueOpen(open) {
  miniQueueOpen = !!open;
  var pop = document.getElementById('mini-queue-popover');
  var btn = document.getElementById('mini-queue-btn');
  if (pop) pop.classList.toggle('show', miniQueueOpen);
  if (btn) btn.classList.toggle('active', miniQueueOpen);
  if (miniQueueOpen) {
    var seq = ++miniQueueRenderSeq;
    requestAnimationFrame(function () {
      if (seq !== miniQueueRenderSeq || !miniQueueOpen) return;
      renderMiniQueuePanel({ animate: true, scrollCurrent: true });
    });
    revealBottomControls(1300);
  }
}
function toggleMiniQueue(e) {
  if (e) { e.preventDefault(); e.stopPropagation(); }
  setMiniQueueOpen(!miniQueueOpen);
}
function closeMiniQueue() {
  setMiniQueueOpen(false);
}
function openPlaylistPanelTab(tab, preserve) {
  tab = normalizePlaylistPanelTab(tab);
  var panel = document.getElementById('playlist-panel');
  if (panel && panel.dataset && preserve !== false) panel.dataset.preserveTabOnOpen = '1';
  switchPlaylistTab(tab);
  setPeek(panel, true, 'pl');
}
function renderMiniQueuePanel(opts) {
  opts = opts || {};
  var $list = document.getElementById('mini-queue-list');
  var $count = document.getElementById('mini-queue-count');
  if (!$list || !$count) return;
  var total = playQueue.length;
  var expectedTotal = queueHydrationExpectedTotal();
  $count.textContent = total ? ((expectedTotal > total ? (total + '/' + expectedTotal) : total) + ' 首' + (currentIdx >= 0 ? ' · 正在播放 ' + (currentIdx + 1) : '')) : '0 首';
  if (!miniQueueOpen && !opts.animate && !opts.scrollCurrent) return;
  if (!total) {
    $list.innerHTML = '<div class="mini-queue-empty">队列为空，先搜索或打开歌单</div>';
    return;
  }
  var windowInfo = queuePanelVirtualWindow($list, $list, total, true, opts.scrollCurrent ? currentIdx : -1);
  var visibleQueue = playQueue.slice(windowInfo.start, windowInfo.end);
  $list.innerHTML = queueVirtualSpacerHtml(windowInfo.top) + visibleQueue.map(function (song, localIndex) {
    var i = windowInfo.start + localIndex;
    var thumb = songCoverSrc(song, 60);
    var imgTag = thumb ? '<img src="' + thumb + '" alt="" loading="lazy" decoding="async" onerror="this.style.opacity=0.2">' : '<div class="mini-queue-cover"></div>';
    return '<div class="mini-queue-item' + (i === currentIdx ? ' now' : '') + '" data-queue-index="' + i + '" onclick="if(window.__mineradioSuppressReorderClick)return;playQueueAt(' + i + ')">' +
      imgTag +
      '<div class="mini-queue-info"><div class="mini-queue-name">' + escHtml(song.name) + '</div><div class="mini-queue-sub">' + escHtml(song.artist || '') + '</div></div>' +
      '<button class="mini-queue-remove mini-queue-next" onclick="event.stopPropagation();queueIndexNext(' + i + ')" title="下一首播放">下</button>' +
      '<button class="mini-queue-remove" onclick="event.stopPropagation();removeFromQueue(' + i + ')" title="移除">×</button>' +
      '</div>';
  }).join('') + queueVirtualSpacerHtml(windowInfo.bottom) + queueHydrationFooterHtml(true);
  if (opts.animate || opts.scrollCurrent) {
    requestAnimationFrame(function () {
      if (opts.animate) animateListItems($list, '.mini-queue-item', { x: 0, y: 6, stagger: 0.01, duration: 0.20, limit: 16 });
      if (opts.scrollCurrent) smoothScrollToItem($list, $list.querySelector('.mini-queue-item.now'), { duration: 0.30, align: 0.42 });
    });
  }
}
var panelReorderState = { timer: 0, active: false, pointerId: null, suppressClickUntil: 0 };
var reorderLongPressMs = 520;
var reorderMoveCancelPx = 9;
function clearPanelReorderClasses() {
  document.body.classList.remove('panel-reordering');
  Array.prototype.forEach.call(document.querySelectorAll('.reorder-pressing,.is-reordering,.is-reordering-list'), function (node) {
    node.classList.remove('reorder-pressing', 'is-reordering', 'is-reordering-list');
  });
}
function markPanelReorderSuppressed(ms) {
  panelReorderState.suppressClickUntil = performance.now() + (ms || 420);
  window.__mineradioSuppressReorderClick = true;
  setTimeout(function () {
    if (performance.now() >= panelReorderState.suppressClickUntil) window.__mineradioSuppressReorderClick = false;
  }, ms || 420);
}
function panelReorderClickSuppressed() {
  return performance.now() < (panelReorderState.suppressClickUntil || 0);
}
function cancelPanelReorder(markSuppress) {
  if (panelReorderState.timer) clearTimeout(panelReorderState.timer);
  if (markSuppress && panelReorderState.active && panelReorderState.kind === 'queue' && typeof saveLastPlaybackSnapshot === 'function') {
    saveLastPlaybackSnapshot(true, 'queue-reorder-final');
  }
  if (markSuppress && panelReorderState.active) markPanelReorderSuppressed(520);
  clearPanelReorderClasses();
  panelReorderState.timer = 0;
  panelReorderState.active = false;
  panelReorderState.pointerId = null;
}
function panelReorderBlockedTarget(target) {
  return !!(target && target.closest && target.closest('button,a,input,textarea,select,[data-pl-load-more],[data-pl-detail-load-more],[data-pl-detail-top],[data-pl-detail-play],[data-pl-detail-artist],[data-pl-detail-row],.pl-inline-detail'));
}
function panelReorderHitFromTarget(target) {
  if (!target || !target.closest || panelReorderBlockedTarget(target)) return null;
  var queueItem = target.closest('.queue-item[data-queue-index],.mini-queue-item[data-queue-index]');
  if (queueItem) {
    var queueRoot = queueItem.closest('#queue-list,#mini-queue-list');
    if (!queueRoot) return null;
    var queueIndex = Number(queueItem.getAttribute('data-queue-index'));
    if (!isFinite(queueIndex)) return null;
    return { kind: 'queue', item: queueItem, rootId: queueRoot.id, index: queueIndex, provider: '' };
  }
  var card = target.closest('.pl-card[data-playlist-index]');
  if (card && card.closest('#pl-list')) {
    var playlistIndex = Number(card.getAttribute('data-playlist-index'));
    if (!isFinite(playlistIndex) || playlistIndex < 0) return null;
    return {
      kind: 'playlist',
      item: card,
      rootId: 'pl-list',
      index: playlistIndex,
      provider: card.getAttribute('data-playlist-provider') || ''
    };
  }
  return null;
}
function panelReorderHitAtPoint(x, y, state) {
  var el = document.elementFromPoint(x, y);
  var hit = panelReorderHitFromTarget(el);
  if (!hit || !state || hit.kind !== state.kind || hit.rootId !== state.rootId) return null;
  if (state.kind === 'playlist' && state.provider && hit.provider !== state.provider) return null;
  return hit;
}
function markPanelReorderItem(state) {
  if (!state || !state.rootId) return;
  requestAnimationFrame(function () {
    var root = document.getElementById(state.rootId);
    if (!root) return;
    root.classList.add('is-reordering-list');
    var attr = state.kind === 'playlist' ? 'data-playlist-index' : 'data-queue-index';
    var item = root.querySelector('[' + attr + '="' + state.currentIndex + '"]');
    if (item) item.classList.add('is-reordering');
  });
}
function bindLongPressPanelReorder() {
  if (document.__mineradioPanelReorderBound) return;
  document.__mineradioPanelReorderBound = true;
  document.addEventListener('click', function (e) {
    if (!panelReorderClickSuppressed()) return;
    if (!e.target || !e.target.closest || !e.target.closest('#queue-list,#mini-queue-list,#pl-list')) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);
  document.addEventListener('pointerdown', function (e) {
    if (e.button != null && e.button !== 0) return;
    var hit = panelReorderHitFromTarget(e.target);
    if (!hit) return;
    cancelPanelReorder(false);
    panelReorderState = {
      timer: 0,
      active: false,
      pointerId: e.pointerId,
      kind: hit.kind,
      rootId: hit.rootId,
      provider: hit.provider,
      startX: e.clientX,
      startY: e.clientY,
      currentIndex: hit.index,
      suppressClickUntil: panelReorderState.suppressClickUntil || 0
    };
    hit.item.classList.add('reorder-pressing');
    panelReorderState.timer = setTimeout(function () {
      if (panelReorderState.pointerId !== e.pointerId) return;
      panelReorderState.active = true;
      document.body.classList.add('panel-reordering');
      markPanelReorderItem(panelReorderState);
      if (typeof markRenderInteraction === 'function') markRenderInteraction('panel-reorder', 900);
    }, reorderLongPressMs);
  }, true);
  document.addEventListener('pointermove', function (e) {
    if (panelReorderState.pointerId == null || e.pointerId !== panelReorderState.pointerId) return;
    var dx = e.clientX - panelReorderState.startX;
    var dy = e.clientY - panelReorderState.startY;
    if (!panelReorderState.active) {
      if (Math.sqrt(dx * dx + dy * dy) > reorderMoveCancelPx) cancelPanelReorder(false);
      return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
    if (typeof markRenderInteraction === 'function') markRenderInteraction('panel-reorder', 900);
    var hit = panelReorderHitAtPoint(e.clientX, e.clientY, panelReorderState);
    if (!hit || hit.index === panelReorderState.currentIndex) return;
    var moved = panelReorderState.kind === 'queue'
      ? (typeof moveQueueIndex === 'function' && moveQueueIndex(panelReorderState.currentIndex, hit.index, { rebuildShelf: true, renderPanel: true, persistSnapshot: false }))
      : (typeof moveUserPlaylistIndex === 'function' && moveUserPlaylistIndex(panelReorderState.currentIndex, hit.index, { rebuildShelf: true, renderPanel: true }));
    if (!moved) return;
    panelReorderState.currentIndex = hit.index;
    clearPanelReorderClasses();
    document.body.classList.add('panel-reordering');
    markPanelReorderItem(panelReorderState);
  }, { capture: true, passive: false });
  document.addEventListener('pointerup', function (e) {
    if (panelReorderState.pointerId == null || e.pointerId !== panelReorderState.pointerId) return;
    cancelPanelReorder(true);
  }, true);
  document.addEventListener('pointercancel', function (e) {
    if (panelReorderState.pointerId == null || e.pointerId !== panelReorderState.pointerId) return;
    cancelPanelReorder(false);
  }, true);
}
document.addEventListener('click', function (e) {
  if (miniQueueOpen && !(e.target && e.target.closest && e.target.closest('#bottom-bar'))) closeMiniQueue();
});
bindSmoothQueueScrolling();
bindPlaylistPanelLazyRender();
bindLongPressPanelReorder();
bindModalBackdropClose();
function renderQueuePanel(opts) {
  opts = opts || {};
  var $ql = document.getElementById('queue-list');
  var seq = ++queueRenderSeq;
  if (!playQueue.length) {
    $ql.innerHTML = '<div style="text-align:center;padding:24px 0;color:rgba(255,255,255,.32);font-size:11.5px">队列为空，搜索后点 + 设为下一首</div>';
    renderMiniQueuePanel();
    var panel = document.getElementById('playlist-panel');
    if (panel && (panel.classList.contains('show') || panel.classList.contains('peek')) && queueViewTab === 'queue') switchPlaylistTab('playlists', { save: false });
    return;
  }
  var total = playQueue.length;
  var panelScroller = document.getElementById('playlist-panel');
  var windowInfo = queuePanelVirtualWindow($ql, panelScroller, total, false, opts.scrollCurrent ? currentIdx : -1);
  var visibleQueue = playQueue.slice(windowInfo.start, windowInfo.end);
  $ql.innerHTML = queueVirtualSpacerHtml(windowInfo.top) + visibleQueue.map(function (song, localIndex) {
    var i = windowInfo.start + localIndex;
    var thumb = songCoverSrc(song, 60);
    var imgTag = thumb ? '<img src="' + thumb + '" alt="" loading="lazy" decoding="async" onerror="this.style.opacity=0.2">' : '<div style="width:38px;height:38px;border-radius:6px;background:rgba(255,255,255,.06);flex-shrink:0"></div>';
    return '<div class="queue-item' + (i === currentIdx ? ' now' : '') + '" data-queue-index="' + i + '" onclick="if(window.__mineradioSuppressReorderClick)return;playQueueAt(' + i + ')">' +
      imgTag +
      '<div class="qi-info"><div class="qi-name">' + escHtml(song.name) + '</div><div class="qi-sub"><button class="queue-artist-link" type="button" onclick="event.stopPropagation();openQueueArtist(' + i + ')">' + escHtml(song.artist || '未知歌手') + '</button></div></div>' +
      '<div class="qi-act">' +
      '<button class="' + (isSongLiked(song) ? 'liked' : '') + '" onclick="event.stopPropagation();toggleLikeQueueIndex(' + i + ')" title="' + (isSongLiked(song) ? '取消红心' : '红心喜欢') + '">' + heartIconSvg() + '</button>' +
      '<button class="queue-next" onclick="event.stopPropagation();queueIndexNext(' + i + ')" title="下一首播放">下</button>' +
      '<button onclick="event.stopPropagation();collectQueueIndex(' + i + ')" title="收藏到歌单">' + playlistPlusIconSvg() + '</button>' +
      '<button onclick="event.stopPropagation();removeFromQueue(' + i + ')" title="移除">×</button>' +
      '</div>' +
      '</div>';
  }).join('') + queueVirtualSpacerHtml(windowInfo.bottom) + queueHydrationFooterHtml(false);
  if (opts.animate && seq === queueRenderSeq) animateVisiblePanelList($ql, '.queue-item', document.getElementById('playlist-panel'), '.queue-item.now');
  renderMiniQueuePanel({ scrollCurrent: opts.scrollCurrent !== false && miniQueueOpen });
}
function playlistCatalogProviderArray(provider) {
  if (provider === 'netease') return neteasePlaylists;
  if (provider === 'qq') return qqPlaylists;
  if (provider === 'kugou') return kugouPlaylists;
  if (provider === 'qishui') return qishuiPlaylists;
  if (provider === 'spotify') return spotifyPlaylists;
  return [];
}
function setPlaylistCatalogProviderArray(provider, rows) {
  rows = Array.isArray(rows) ? rows : [];
  if (provider === 'netease') neteasePlaylists = rows;
  else if (provider === 'qq') qqPlaylists = rows;
  else if (provider === 'kugou') kugouPlaylists = rows;
  else if (provider === 'qishui') qishuiPlaylists = rows;
  else if (provider === 'spotify') spotifyPlaylists = rows;
}
function playlistCatalogProviderLoggedIn(provider) {
  if (provider === 'netease') return !!loginStatus.loggedIn;
  if (provider === 'qq') return !!qqLoginStatus.loggedIn;
  if (provider === 'kugou') return !!kugouLoginStatus.loggedIn;
  if (provider === 'qishui') return !!qishuiLoginStatus.loggedIn;
  if (provider === 'spotify') return !!spotifyLoginStatus.loggedIn;
  return false;
}
function playlistCatalogPageUrl(provider, offset, limit) {
  offset = Math.max(0, Number(offset) || 0);
  limit = Math.max(1, Number(limit) || PLAYLIST_CATALOG_FIRST_PAGE_SIZE);
  if (provider === 'netease') return '/api/user/playlists?paged=1&limit=' + limit + '&offset=' + offset;
  if (provider === 'spotify') return '/api/spotify/user/playlists?limit=' + Math.min(500, limit) + '&offset=' + offset;
  if (provider === 'qq') return '/api/qq/user/playlists';
  if (provider === 'kugou') return '/api/kugou/user/playlists';
  if (provider === 'qishui') return '/api/qishui/user/playlists';
  return '';
}
function mergePlaylistCatalogRows(existing, incoming, provider) {
  var seen = Object.create(null);
  var out = [];
  (existing || []).concat(incoming || []).forEach(function (pl) {
    if (!pl) return;
    pl.provider = provider;
    pl.source = provider;
    var key = String(pl.id || '');
    if (!key || seen[key]) return;
    seen[key] = true;
    out.push(pl);
  });
  return out;
}
function rebuildUserPlaylistsFromCatalog(opts) {
  opts = opts || {};
  userPlaylists = neteasePlaylists.concat(qqPlaylists, kugouPlaylists, qishuiPlaylists, spotifyPlaylists);
  if (typeof applyUserPlaylistOrder === 'function') applyUserPlaylistOrder();
  playlistCatalogRevision += 1;
  renderUserPlaylistsList({ animate: !!opts.animate, reset: !!opts.reset, preserveScroll: opts.preserveScroll !== false });
  if (emptyHomeActive) renderHomeDiscover();
  scheduleShelfRebuild(opts.reason || 'playlist-catalog-page', true);
}
async function loadPlaylistCatalogProviderPage(provider, reason) {
  var root = playlistCatalogSyncState;
  var state = root.providers && root.providers[provider];
  if (!state || state.loading || !state.hasMore || !playlistCatalogProviderLoggedIn(provider)) return false;
  var token = root.token;
  var first = state.nextOffset === 0 && !state.loaded;
  var limit = first ? PLAYLIST_CATALOG_FIRST_PAGE_SIZE : PLAYLIST_CATALOG_BACKGROUND_PAGE_SIZE;
  var requestOffset = state.nextOffset;
  var url = playlistCatalogPageUrl(provider, requestOffset, limit);
  if (!url) return false;
  state.loading = true;
  try {
    var r = await apiJson(url, { timeoutMs: 15000 });
    if (playlistCatalogSyncState.token !== token) return false;
    var incoming = (r && r.playlists || []).map(function (pl) { pl.provider = provider; pl.source = provider; return pl; });
    if (r && r.error && !incoming.length) throw new Error(r.message || r.error);
    var current = first ? [] : playlistCatalogProviderArray(provider);
    var merged = mergePlaylistCatalogRows(current, incoming, provider);
    setPlaylistCatalogProviderArray(provider, merged);
    state.loaded = merged.length;
    state.total = Math.max(state.loaded, Number(r && r.total) || 0);
    state.nextOffset = r && r.nextOffset != null ? Math.max(0, Number(r.nextOffset) || 0) : (requestOffset + incoming.length);
    var supportsPaging = provider === 'netease' || provider === 'spotify';
    state.hasMore = supportsPaging ? !!(r && r.hasMore) : false;
    if (state.total && state.nextOffset >= state.total) state.hasMore = false;
    if (!incoming.length) state.hasMore = false;
    state.error = (r && r.error) || '';
    rebuildUserPlaylistsFromCatalog({ animate: first && isPlaylistPanelVisibleForRender(), reset: first, preserveScroll: !first, reason: reason || 'playlist-catalog-page' });
    return incoming.length > 0;
  } catch (e) {
    if (playlistCatalogSyncState.token !== token) return false;
    console.warn('[PlaylistCatalogPage]', provider, e);
    state.error = e && e.message || 'PLAYLIST_CATALOG_PAGE_FAILED';
    state.hasMore = false;
    playlistCatalogSyncState.error = state.error;
    if (userPlaylists.length) renderUserPlaylistsList({ preserveScroll: true });
    return false;
  } finally {
    if (playlistCatalogSyncState.token === token) state.loading = false;
  }
}
function playlistCatalogHasPendingPages() {
  var providers = playlistCatalogSyncState.providers || {};
  return Object.keys(providers).some(function (key) { return providers[key] && (providers[key].loading || providers[key].hasMore); });
}
function requestNextPlaylistCatalogPage(reason) {
  var root = playlistCatalogSyncState;
  if (!root || !root.providers) return false;
  var order = ['netease', 'spotify', 'qq', 'kugou', 'qishui'];
  var provider = order.find(function (key) {
    var state = root.providers[key];
    return state && state.hasMore && !state.loading;
  });
  if (!provider) {
    root.loading = playlistCatalogHasPendingPages();
    return false;
  }
  loadPlaylistCatalogProviderPage(provider, reason || 'background').finally(function () {
    if (playlistCatalogSyncState !== root || !playlistCatalogHasPendingPages()) {
      root.loading = false;
      if (userPlaylists.length) renderUserPlaylistsList({ preserveScroll: true });
      return;
    }
    if (root.timer) clearTimeout(root.timer);
    root.timer = setTimeout(function () {
      root.timer = 0;
      requestNextPlaylistCatalogPage('background');
    }, 180);
  });
  return true;
}
var IMPORTED_PLAYLIST_STORE_KEY = 'mineradio-imported-link-playlists-v1';
var universalImportedPlaylistsCache = null;
var universalPlaylistPollTimer = null;
var universalLegacyMigrationStarted = false;
var MUSIC_LIBRARY_VIEW_STORE_KEY = 'mineradio-music-library-view-v1';
var unifiedPlaylistDetailState = { playlist: null, tracks: [], kind: '', previousFocus: null };
function playlistTrackUsesDirectLocalMedia(song) {
  if (!song) return false;
  var provider = String(song.provider || song.source || '').toLowerCase();
  var type = String(song.type || '').toLowerCase();
  return provider === 'local' || type === 'local' || !!(song.localUrl || song.localPath || song.localKey || song.localFileId);
}
function playlistTrackIsSpokenMedia(song) {
  if (!song) return false;
  var type = String(song.type || '').toLowerCase();
  return /^(podcast|episode|radio|fm)$/.test(type) || !!(song.isPodcast || song.stationUrl || song.episodeUrl);
}
function normalizePlaylistTrackForPlayback(song) {
  var copy = cloneSong(song || {});
  if (!playlistTrackUsesDirectLocalMedia(copy) && !playlistTrackIsSpokenMedia(copy) && (copy.name || copy.title)) {
    copy._resolveWithMusicFree = true;
  }
  return copy;
}
function normalizePlaylistTracksForPlayback(tracks) {
  return (Array.isArray(tracks) ? tracks : []).filter(Boolean).map(normalizePlaylistTrackForPlayback);
}
var musicLibraryViewMode = (function () {
  try {
    var saved = localStorage.getItem(MUSIC_LIBRARY_VIEW_STORE_KEY) || 'all';
    return /^(all|network|local)$/.test(saved) ? saved : 'all';
  } catch (_error) { return 'all'; }
})();
function setMusicLibraryViewMode(mode) {
  musicLibraryViewMode = /^(network|local)$/.test(mode) ? mode : 'all';
  try { localStorage.setItem(MUSIC_LIBRARY_VIEW_STORE_KEY, musicLibraryViewMode); } catch (_error) { }
  renderStandaloneMusicLibrary();
  renderSideMusicLibrary();
}
function readImportedLinkPlaylists() {
  if (Array.isArray(universalImportedPlaylistsCache)) return universalImportedPlaylistsCache;
  try {
    var value = JSON.parse(localStorage.getItem(IMPORTED_PLAYLIST_STORE_KEY) || '[]');
    return Array.isArray(value) ? value.map(function (playlist) {
      var copy = Object.assign({}, playlist || {});
      copy.tracks = normalizePlaylistTracksForPlayback(copy.tracks);
      return copy;
    }) : [];
  } catch (_error) {
    return [];
  }
}
function writeImportedLinkPlaylists(items) {
  universalImportedPlaylistsCache = Array.isArray(items) ? items : [];
  try {
    localStorage.setItem(IMPORTED_PLAYLIST_STORE_KEY, JSON.stringify(items || []));
    return true;
  } catch (error) {
    console.warn('[ImportedPlaylists]', error);
    showToast('网络歌单保存失败，请检查本地存储空间');
    return false;
  }
}
async function refreshUniversalImportedPlaylists(options) {
  options = options || {};
  try {
    var response = await apiJson('/api/universal-import/playlists', { timeoutMs: 10000 });
    var remote = response && Array.isArray(response.playlists) ? response.playlists : [];
    var local = readImportedLinkPlaylists();
    var legacy = local.filter(function (item) {
      return item && item.sourceUrl && !remote.some(function (remoteItem) {
        return remoteItem && (remoteItem.id === item.id || (remoteItem.platform === (item.platform || item.provider) && remoteItem.sourceUrl === item.sourceUrl));
      });
    });
    if (legacy.length && !universalLegacyMigrationStarted) {
      universalLegacyMigrationStarted = true;
      apiJson('/api/universal-import/migrate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlists: legacy }), timeoutMs: 30000
      }).then(function () { return refreshUniversalImportedPlaylists(); }).catch(function () { universalLegacyMigrationStarted = false; });
    }
    var merged = remote.slice();
    local.forEach(function (item) {
      if (!item) return;
      var duplicate = merged.some(function (remoteItem) {
        return remoteItem && (remoteItem.id === item.id || (remoteItem.platform === item.platform && remoteItem.sourceUrl === item.sourceUrl));
      });
      if (!duplicate) merged.push(item);
    });
    universalImportedPlaylistsCache = merged.map(function (playlist) {
      var copy = Object.assign({}, playlist || {});
      copy.tracks = normalizePlaylistTracksForPlayback(copy.tracks);
      return copy;
    });
    try { localStorage.setItem(IMPORTED_PLAYLIST_STORE_KEY, JSON.stringify(universalImportedPlaylistsCache)); } catch (_error) { }
    if (options.render !== false) { renderStandaloneMusicLibrary(); renderSideMusicLibrary(); }
    return universalImportedPlaylistsCache;
  } catch (error) {
    console.warn('[UniversalImport] playlist refresh failed', error);
    return readImportedLinkPlaylists();
  }
}
async function syncAllImportedPlaylists() {
  var button = document.getElementById('music-library-sync-all');
  if (button) button.disabled = true;
  try {
    var result = await apiJson('/api/universal-import/sync-all', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}', timeoutMs: 120000 });
    await refreshUniversalImportedPlaylists();
    showToast(result && result.updated ? ('已同步，更新 ' + result.updated + ' 个歌单') : '已同步，暂无变化');
  } catch (error) {
    showToast(error && error.message || '歌单同步失败');
  } finally {
    if (button) button.disabled = false;
  }
}
async function openImportTestCenter() {
  var modal = document.getElementById('import-test-center-modal');
  var content = document.getElementById('import-test-center-content');
  if (modal) openGsapModal(modal);
  if (content) content.innerHTML = '<div class="music-library-empty">正在读取导入诊断…</div>';
  try {
    var result = await apiJson('/api/universal-import/test-center', { timeoutMs: 10000 });
    var stats = result && result.diagnostics || {};
    var sync = result && result.sync || {};
    var failures = stats.failures || {};
    var failureRows = Object.keys(failures).slice(0, 8).map(function (reason) {
      return '<div class="pl-card"><div class="music-library-card-copy"><div class="pl-name">' + escHtml(reason) + '</div><div class="pl-sub">' + failures[reason] + ' 次</div></div></div>';
    }).join('');
    if (content) content.innerHTML =
      '<div class="music-library-view-options"><button class="active" type="button">总测试 ' + Number(stats.total || 0) + '</button><button type="button">成功率 ' + Math.round(Number(stats.successRate || 0) * 100) + '%</button><button type="button">平均 ' + Number(stats.averageMs || 0) + 'ms</button><button type="button">调度 ' + Number(sync.intervalMs || 5000) + 'ms</button></div>' +
      '<div class="pl-section-label">最近失败原因</div>' + (failureRows || '<div class="music-library-empty compact">暂无失败记录</div>');
  } catch (error) {
    if (content) content.innerHTML = '<div class="music-library-empty">诊断数据读取失败：' + escHtml(error && error.message || '') + '</div>';
  }
}
function closeImportTestCenter() {
  closeGsapModal(document.getElementById('import-test-center-modal'));
}
function ensureUniversalPlaylistPolling() {
  if (universalPlaylistPollTimer) return;
  universalPlaylistPollTimer = setInterval(function () { refreshUniversalImportedPlaylists({ render: true }); }, 5000);
}
function musicLibraryLocalState() {
  if (typeof readLocalCollections === 'function') return readLocalCollections();
  try {
    var value = JSON.parse(localStorage.getItem('mineradio-local-collections-v1') || '{}');
    return { favorites: Array.isArray(value.favorites) ? value.favorites : [], playlists: Array.isArray(value.playlists) ? value.playlists : [] };
  } catch (_error) {
    return { favorites: [], playlists: [] };
  }
}
function musicLibraryProviderName(provider, fallback) {
  var labels = { netease: '网易云', qq: 'QQ 音乐', kugou: '酷狗', kuwo: '酷我', qishui: '汽水音乐' };
  return labels[String(provider || '').toLowerCase()] || fallback || '网络歌单';
}
function musicLibraryCardHtml(kind, item, index) {
  item = item || {};
  var tracks = kind === 'favorite' ? (item.tracks || []) : (Array.isArray(item.tracks) ? item.tracks : []);
  var firstEntry = tracks[0] || {};
  var first = firstEntry.song || firstEntry;
  var cover = item.cover || (first && (first.cover || first.artwork)) || '';
  var name = item.name || (kind === 'favorite' ? '本地喜欢' : '未命名歌单');
  var source = kind === 'network' ? musicLibraryProviderName(item.provider, item.source) : '仅保存在本机';
  return '<div class="pl-card music-library-card" data-library-kind="' + kind + '" data-library-index="' + index + '" onclick="playStoredMusicLibraryPlaylist(\'' + kind + '\',' + index + ')">' +
    (cover ? '<img src="' + escHtml(cover) + '" alt="" loading="lazy" decoding="async" onerror="this.style.opacity=.2">' : '<div class="music-library-cover-placeholder">♫</div>') +
    '<div class="music-library-card-copy"><div class="pl-name">' + escHtml(name) + (kind === 'network' ? '<span class="music-library-provider-tag">' + escHtml(source) + '</span>' : '') + '</div><div class="pl-sub">' + tracks.length + ' 首 · ' + escHtml(source) + '</div></div>' +
    (kind === 'network' ? '<button class="music-library-remove" type="button" title="删除网络歌单" aria-label="删除网络歌单" onclick="event.stopPropagation();removeImportedLinkPlaylist(' + index + ')">×</button>' :
      (kind === 'local' || kind === 'favorite' ? '<button class="music-library-remove" type="button" title="删除本地歌单" aria-label="删除本地歌单" onclick="event.stopPropagation();removeLocalMusicLibraryPlaylist(\'' + kind + '\',' + index + ')">×</button>' : '')) +
    '</div>';
}
function renderStandaloneMusicLibrary() {
  var root = document.getElementById('music-library-list');
  if (!root) return;
  var local = musicLibraryLocalState();
  var imported = readImportedLinkPlaylists();
  var localRows = [];
  if (local.favorites.length) localRows.push(musicLibraryCardHtml('favorite', { name: '本地喜欢', tracks: local.favorites }, 0));
  (local.playlists || []).forEach(function (item, index) { localRows.push(musicLibraryCardHtml('local', item, index)); });
  var networkRows = imported.map(function (item, index) { return musicLibraryCardHtml('network', item, index); });
  var showNetwork = musicLibraryViewMode !== 'local';
  var showLocal = musicLibraryViewMode !== 'network';
  root.innerHTML =
    '<div class="music-library-view-options" role="group" aria-label="歌单显示选项">' +
      '<button type="button" class="' + (musicLibraryViewMode === 'all' ? 'active' : '') + '" onclick="setMusicLibraryViewMode(\'all\')">全部</button>' +
      '<button type="button" class="' + (musicLibraryViewMode === 'network' ? 'active' : '') + '" onclick="setMusicLibraryViewMode(\'network\')">网络导入</button>' +
      '<button type="button" class="' + (musicLibraryViewMode === 'local' ? 'active' : '') + '" onclick="setMusicLibraryViewMode(\'local\')">本地歌单</button>' +
    '</div>' +
    '<div class="music-library-groups">' +
      (showNetwork ? ('<section class="music-library-group"><div class="music-library-section-head"><div><span>NETWORK PLAYLISTS</span><h3>网络导入歌单</h3></div><b>' + networkRows.length + '</b></div><div class="music-library-grid">' +
        (networkRows.length ? networkRows.join('') : '<div class="music-library-empty">支持网易云、QQ、酷狗、酷我、汽水音乐公开链接</div>') + '</div></section>') : '') +
      (showLocal ? ('<section class="music-library-group"><div class="music-library-section-head"><div><span>LOCAL COLLECTION</span><h3>本地歌单</h3></div><b>' + localRows.length + '</b></div><div class="music-library-grid">' +
        (localRows.length ? localRows.join('') : '<div class="music-library-empty">还没有本地歌单<br>播放歌曲后可用底部“＋”按钮创建</div>') + '</div></section>') : '') +
    '</div>';
}

function renderSideMusicLibrary() {
  var root = document.getElementById('pl-list');
  if (!root) return;
  var local = musicLibraryLocalState();
  var imported = readImportedLinkPlaylists();
  var networkRows = imported.map(function (item, index) { return musicLibraryCardHtml('network', item, index); });
  var localRows = [];
  if (local.favorites.length) localRows.push(musicLibraryCardHtml('favorite', { name: '本地喜欢', tracks: local.favorites }, 0));
  (local.playlists || []).forEach(function (item, index) { localRows.push(musicLibraryCardHtml('local', item, index)); });
  root.innerHTML =
    '<div class="music-library-view-options side" role="group" aria-label="歌单显示选项">' +
      '<button type="button" class="' + (musicLibraryViewMode === 'all' ? 'active' : '') + '" onclick="setMusicLibraryViewMode(\'all\')">全部</button>' +
      '<button type="button" class="' + (musicLibraryViewMode === 'network' ? 'active' : '') + '" onclick="setMusicLibraryViewMode(\'network\')">网络</button>' +
      '<button type="button" class="' + (musicLibraryViewMode === 'local' ? 'active' : '') + '" onclick="setMusicLibraryViewMode(\'local\')">本地</button>' +
    '</div>' +
    (musicLibraryViewMode !== 'local' ? '<div class="pl-section-label">网络歌单</div>' + (networkRows.join('') || '<div class="music-library-empty compact">暂无网络歌单</div>') : '') +
    (musicLibraryViewMode !== 'network' ? '<div class="pl-section-label music-library-local-label">本地歌单</div>' + (localRows.join('') || '<div class="music-library-empty compact">暂无本地歌单</div>') : '');
}

function openCreateLocalPlaylistModal() {
  var modal = document.getElementById('create-local-playlist-modal');
  var input = document.getElementById('create-local-playlist-name');
  if (input) input.value = '';
  if (modal) { modal.setAttribute('aria-hidden', 'false'); openGsapModal(modal); }
  setTimeout(function () { if (input) input.focus(); }, 120);
}

function closeCreateLocalPlaylistModal() {
  var modal = document.getElementById('create-local-playlist-modal');
  if (modal) modal.setAttribute('aria-hidden', 'true');
  closeGsapModal(modal);
}

function createEmptyLocalPlaylist() {
  var input = document.getElementById('create-local-playlist-name');
  var name = String(input && input.value || '').trim();
  if (!name) { showToast('请输入歌单名称'); if (input) input.focus(); return; }
  var state = musicLibraryLocalState();
  if ((state.playlists || []).some(function (item) { return String(item && item.name || '').trim().toLowerCase() === name.toLowerCase(); })) {
    showToast('已经有同名本地歌单'); return;
  }
  state.playlists = Array.isArray(state.playlists) ? state.playlists : [];
  state.playlists.push({ id: 'local-' + Date.now().toString(36), name: name, cover: '', createdAt: Date.now(), tracks: [] });
  if (typeof writeLocalCollections === 'function' && writeLocalCollections(state)) {
    closeCreateLocalPlaylistModal();
    renderStandaloneMusicLibrary();
    renderSideMusicLibrary();
    showToast('已创建本地歌单“' + name + '”');
  }
}

function openMusicLibrary() {
  var modal = document.getElementById('music-library-modal');
  renderStandaloneMusicLibrary();
  refreshUniversalImportedPlaylists();
  ensureUniversalPlaylistPolling();
  if (modal) {
    modal.setAttribute('aria-hidden', 'false');
    openGsapModal(modal);
  }
}

function closeMusicLibrary() {
  var modal = document.getElementById('music-library-modal');
  if (modal) modal.setAttribute('aria-hidden', 'true');
  closeGsapModal(modal);
}

function returnPlaylistPlaybackToHome() {
  closeUnifiedPlaylistDetail();
  closeMusicLibrary();
  if (typeof closeHomePlatformRecommendations === 'function') closeHomePlatformRecommendations();
  var panel = document.getElementById('playlist-panel');
  if (panel) {
    panel.classList.remove('peek', 'show', 'playlist-panel-closing');
    if (typeof markPlaylistPanelMotion === 'function') markPlaylistPanelMotion(panel, playlistPanelMotionMs('close'));
  }
  homeSuppressed = false;
  homeForcedOpen = true;
  if (typeof setHomeControlsLocked === 'function') setHomeControlsLocked(true);
  if (typeof setPeek === 'function') {
    setPeek(document.getElementById('playlist-panel'), false, 'pl');
    setPeek(document.getElementById('search-area'), true, 'search');
  }
  if (typeof updateEmptyHomeVisibility === 'function') updateEmptyHomeVisibility({ forceLoad: false });
}
function playStoredMusicLibraryPlaylist(kind, index) {
  var item = null;
  var entries = [];
  if (kind === 'network') {
    item = readImportedLinkPlaylists()[Number(index)];
    entries = item && item.tracks || [];
  } else {
    var local = musicLibraryLocalState();
    if (kind === 'favorite') {
      item = { id: 'local-favorites', name: '本地喜欢', tracks: local.favorites || [] };
    } else {
      item = (local.playlists || [])[Number(index)];
    }
    entries = item && item.tracks || [];
  }
  var songs = entries.map(function (entry) { return entry && entry.song ? entry.song : entry; }).filter(Boolean);
  if (!item || !songs.length) { showToast('这个歌单暂时没有歌曲'); return; }
  openUnifiedPlaylistDetail({
    playlist: { id: item.id || '', name: item.name || (kind === 'favorite' ? '本地喜欢' : '本地歌单'), cover: item.cover || '', provider: kind === 'network' ? (item.provider || item.source || '') : 'local', storageKind: kind, storageIndex: Number(index) },
    tracks: songs,
    kind: kind === 'network' ? 'network' : 'local'
  });
}

function unifiedPlaylistDuration(value) {
  var seconds = Math.max(0, Math.round((Number(value) || 0) / ((Number(value) || 0) > 10000 ? 1000 : 1)));
  if (!seconds) return '—';
  return Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
}

function unifiedPlaylistProviderLabel(provider) {
  var labels = { netease: '网易云', qq: 'QQ 音乐', kugou: '酷狗音乐', kuwo: '酷我音乐', qishui: '汽水音乐', spotify: 'Spotify', musicfree: 'MusicFree', local: '本地歌单' };
  return labels[String(provider || '').toLowerCase()] || String(provider || '歌单');
}

function renderUnifiedPlaylistDetail() {
  var state = unifiedPlaylistDetailState;
  var playlist = state.playlist || {};
  var tracks = state.tracks || [];
  var cover = document.getElementById('unified-playlist-cover');
  var title = document.getElementById('unified-playlist-title');
  var kicker = document.getElementById('unified-playlist-kicker');
  var meta = document.getElementById('unified-playlist-meta');
  var list = document.getElementById('unified-playlist-tracks');
  var columns = document.querySelector('#playlist-detail-modal .unified-playlist-columns');
  var head = document.querySelector('#playlist-detail-modal .unified-playlist-head');
  var playAll = document.getElementById('unified-playlist-play-all');
  if (head && !playAll) {
    playAll = document.createElement('button');
    playAll.id = 'unified-playlist-play-all';
    playAll.className = 'unified-playlist-play-all';
    playAll.type = 'button';
    playAll.textContent = '全部播放';
    playAll.setAttribute('aria-label', '播放歌单全部歌曲');
    playAll.onclick = playUnifiedPlaylistAll;
    head.insertBefore(playAll, head.lastElementChild);
  }
  if (playAll) playAll.disabled = !tracks.length;
  if (title) title.textContent = playlist.name || '歌单详情';
  if (kicker) kicker.textContent = unifiedPlaylistProviderLabel(playlist.provider || playlist.source).toUpperCase() + ' · PLAYLIST';
  if (meta) meta.textContent = tracks.length + ' 首歌曲 · 点击歌曲后' + (state.kind === 'local' ? '播放本地文件' : '由 MusicFree 音源解析播放');
  if (cover) {
    cover.textContent = playlist.cover ? '' : '♫';
    cover.style.backgroundImage = playlist.cover ? 'url("' + cssImageUrl(playlist.cover) + '")' : '';
  }
  var canRemoveTracks = state.kind === 'local';
  if (columns) columns.classList.toggle('has-track-actions', canRemoveTracks);
  if (!list) return;
  list.innerHTML = tracks.map(function (song, index) {
    song = song || {};
    var songCover = song.cover || song.artwork || '';
    return '<div class="unified-playlist-track' + (canRemoveTracks ? ' has-track-actions' : '') + '" role="button" tabindex="0" aria-label="播放歌曲" onclick="playUnifiedPlaylistTrack(' + index + ')" onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();playUnifiedPlaylistTrack(' + index + ')}">' +
      '<span class="unified-playlist-index">' + String(index + 1).padStart(2, '0') + '</span>' +
      '<span class="unified-playlist-song">' + (songCover ? '<img src="' + escHtml(songCover) + '" alt="" loading="lazy" decoding="async">' : '<i>♫</i>') +
        '<span><b>' + escHtml(song.name || song.title || '未知歌曲') + '</b><small>' + escHtml(song.artist || '未知歌手') + '</small></span></span>' +
      '<span class="unified-playlist-album">' + escHtml(song.album || '—') + '</span>' +
      '<span class="unified-playlist-duration">' + unifiedPlaylistDuration(song.duration) + '</span>' +
      (canRemoveTracks ? '<button class="unified-playlist-track-remove" type="button" aria-label="从本地歌单移除" title="从歌单移除" onclick="event.stopPropagation();removeUnifiedLocalPlaylistTrack(' + index + ')">×</button>' : '') +
    '</div>';
  }).join('');
}

function removeUnifiedLocalPlaylistTrack(index) {
  var detail = unifiedPlaylistDetailState || {};
  var playlist = detail.playlist || {};
  var selectedIndex = Number(index);
  var selectedSong = detail.tracks && detail.tracks[selectedIndex];
  if (detail.kind !== 'local' || !selectedSong || typeof readLocalCollections !== 'function') return;
  var state = readLocalCollections();
  var entries = null;
  if (playlist.storageKind === 'favorite') entries = state.favorites;
  else if (Array.isArray(state.playlists) && state.playlists[playlist.storageIndex]) entries = state.playlists[playlist.storageIndex].tracks;
  if (!Array.isArray(entries)) return;
  var selectedKey = typeof localCollectionSongKey === 'function' ? localCollectionSongKey(selectedSong) : '';
  var storedIndex = entries.findIndex(function (entry) {
    var song = entry && entry.song ? entry.song : entry;
    return song === selectedSong || (selectedKey && typeof localCollectionSongKey === 'function' && localCollectionSongKey(song) === selectedKey);
  });
  if (storedIndex < 0 && selectedIndex < entries.length) storedIndex = selectedIndex;
  if (storedIndex < 0) return;
  entries.splice(storedIndex, 1);
  if (typeof writeLocalCollections !== 'function' || !writeLocalCollections(state)) return;
  detail.tracks.splice(selectedIndex, 1);
  renderUnifiedPlaylistDetail();
  showToast('已从歌单移除，不会删除音乐文件');
}

function openUnifiedPlaylistDetail(options) {
  options = options || {};
  var modal = document.getElementById('playlist-detail-modal');
  unifiedPlaylistDetailState = {
    playlist: options.playlist || {},
    tracks: normalizePlaylistTracksForPlayback(options.tracks),
    kind: options.kind || 'network',
    previousFocus: document.activeElement
  };
  renderUnifiedPlaylistDetail();
  if (modal) { modal.setAttribute('aria-hidden', 'false'); openGsapModal(modal); }
}

function closeUnifiedPlaylistDetail() {
  var modal = document.getElementById('playlist-detail-modal');
  if (modal) modal.setAttribute('aria-hidden', 'true');
  closeGsapModal(modal);
}

async function playUnifiedPlaylistTrack(index) {
  var tracks = unifiedPlaylistDetailState.tracks || [];
  var selectedIndex = Math.max(0, Math.min(tracks.length - 1, Number(index) || 0));
  if (!tracks[selectedIndex]) return;
  var queue = normalizePlaylistTracksForPlayback(tracks);
  playQueue = queue;
  currentIdx = selectedIndex;
  returnPlaylistPlaybackToHome();
  safeRenderQueuePanel('unified-playlist-detail', { scrollCurrent: true });
  safeShelfRebuild('unified-playlist-detail', true);
  forcePlaybackControlsInteractive();
  await playQueueAt(currentIdx, { manual: true, preserveHomeState: true, context: { type: 'unified-playlist', playlistName: unifiedPlaylistDetailState.playlist && unifiedPlaylistDetailState.playlist.name || '歌单' } });
}
async function playUnifiedPlaylistAll() {
  if (!unifiedPlaylistDetailState.tracks || !unifiedPlaylistDetailState.tracks.length) {
    showToast('这个歌单暂时没有歌曲');
    return;
  }
  await playUnifiedPlaylistTrack(0);
}
function removeImportedLinkPlaylist(index) {
  var items = readImportedLinkPlaylists();
  var removed = items.splice(Number(index), 1)[0];
  if (!removed || !writeImportedLinkPlaylists(items)) return;
  if (removed.id) apiJson('/api/universal-import/playlists/' + encodeURIComponent(removed.id), { method: 'DELETE', timeoutMs: 10000 }).catch(function () {});
  renderStandaloneMusicLibrary();
  renderSideMusicLibrary();
  showToast('已移除网络歌单“' + (removed.name || '') + '”');
}
function removeLocalMusicLibraryPlaylist(kind, index) {
  var state = musicLibraryLocalState();
  var name = kind === 'favorite' ? '本地喜欢' : (state.playlists && state.playlists[Number(index)] && state.playlists[Number(index)].name || '本地歌单');
  if (!window.confirm('确定删除“' + name + '”吗？此操作只删除该本地歌单，不会删除音乐文件。')) return;
  if (kind === 'favorite') state.favorites = [];
  else if (Array.isArray(state.playlists)) state.playlists.splice(Number(index), 1);
  if (typeof writeLocalCollections === 'function' && writeLocalCollections(state)) {
    renderStandaloneMusicLibrary();
    renderSideMusicLibrary();
    showToast('已删除“' + name + '”');
  }
}
function openPlaylistLinkImportModal() {
  var modal = document.getElementById('playlist-link-import-modal');
  var input = document.getElementById('playlist-link-import-input');
  var status = document.getElementById('playlist-link-import-status');
  if (status) { status.textContent = '歌单解析后仅保存在本机，不需要 Mineradio 账号。'; status.className = 'playlist-link-import-status'; }
  if (modal) openGsapModal(modal);
  bindUniversalImportDropTarget();
  setTimeout(function () { if (input) input.focus(); }, 120);
}
function closePlaylistLinkImportModal() {
  closeGsapModal(document.getElementById('playlist-link-import-modal'));
}
function playlistLinkFromShareText(text) {
  var raw = String(text || '').trim();
  var match = raw.match(/https?:\/\/[^\s<>"']+/i);
  return (match ? match[0] : raw).replace(/[，。；、]+$/, '');
}
async function submitPlaylistLinkImport() {
  var input = document.getElementById('playlist-link-import-input');
  var button = document.getElementById('playlist-link-import-submit');
  var status = document.getElementById('playlist-link-import-status');
  var link = playlistLinkFromShareText(input && input.value);
  // App schemes and encoded share payloads are normalized by the server. The
  // local placeholder only lets them pass the legacy http-only UI guard.
  if (!/^https?:\/\//i.test(link) && String(input && input.value || '').trim()) link = 'https://import.invalid/share';
  if (!/^https?:\/\//i.test(link)) { if (status) { status.textContent = '没有识别到有效的 http/https 歌单链接'; status.className = 'playlist-link-import-status error'; } return; }
  if (button && button.disabled) return;
  if (button) { button.disabled = true; button.textContent = '正在解析…'; }
  if (status) { status.textContent = '正在读取公开歌单曲目，请稍候…'; status.className = 'playlist-link-import-status busy'; }
  try {
    var result = await apiJson('/api/universal-import/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: input && input.value || link, receiver: 'windows-web' }),
      timeoutMs: 30000
    });
    if (!result || result.ok === false || !result.playlist || !Array.isArray(result.tracks) || !result.tracks.length) throw new Error(result && (result.error || result.message) || '歌单没有可导入曲目');
    var items = readImportedLinkPlaylists();
    var entry = Object.assign({}, result.playlist, {
      provider: result.playlist.platform || result.provider || '', source: result.source || '', sourceUrl: result.playlist.sourceUrl || link,
      importedAt: Date.now(), tracks: normalizePlaylistTracksForPlayback(result.tracks)
    });
    var duplicate = items.findIndex(function (item) { return item && (item.sourceUrl === link || item.id === entry.id); });
    if (duplicate >= 0) items.splice(duplicate, 1);
    items.unshift(entry);
    if (!writeImportedLinkPlaylists(items)) throw new Error('解析成功，但本地存储空间不足');
    if (input) input.value = '';
    renderStandaloneMusicLibrary();
    renderSideMusicLibrary();
    closePlaylistLinkImportModal();
    showToast('已导入“' + entry.name + '” · ' + entry.tracks.length + ' 首');
  } catch (error) {
    if (status) { status.textContent = error && error.message || '歌单链接导入失败'; status.className = 'playlist-link-import-status error'; }
  } finally {
    if (button) { button.disabled = false; button.textContent = '解析并导入'; }
  }
}
function bindUniversalImportDropTarget() {
  var modal = document.getElementById('playlist-link-import-modal');
  var input = document.getElementById('playlist-link-import-input');
  if (!modal || modal.__universalDropBound) return;
  modal.__universalDropBound = true;
  ['dragenter', 'dragover'].forEach(function (type) {
    modal.addEventListener(type, function (event) { event.preventDefault(); modal.classList.add('is-link-dragging'); });
  });
  ['dragleave', 'drop'].forEach(function (type) {
    modal.addEventListener(type, function () { modal.classList.remove('is-link-dragging'); });
  });
  modal.addEventListener('drop', function (event) {
    event.preventDefault();
    var transfer = event.dataTransfer;
    var value = transfer && (transfer.getData('text/uri-list') || transfer.getData('text/plain')) || '';
    if (input && value) { input.value = value; input.focus(); }
  });
}
async function refreshUserPlaylists(force) {
  if (!loginStatus.loggedIn && !qqLoginStatus.loggedIn && !kugouLoginStatus.loggedIn && !qishuiLoginStatus.loggedIn && !spotifyLoginStatus.loggedIn) {
    resetPlaylistPanelRenderLimit();
    renderStandaloneMusicLibrary();
    renderSideMusicLibrary();
    var podcastListLoggedOut = document.getElementById('podcast-list');
    if (podcastListLoggedOut) podcastListLoggedOut.innerHTML = '<div style="text-align:center;padding:14px 0;color:rgba(255,255,255,.28);font-size:11.5px">当前版本未启用网络播客收藏</div>';
    return;
  }
  var catalogNeedsNewProvider = playlistCatalogSyncState.loading && ['netease', 'qq', 'kugou', 'qishui', 'spotify'].some(function (provider) {
    var state = playlistCatalogSyncState.providers && playlistCatalogSyncState.providers[provider];
    return playlistCatalogProviderLoggedIn(provider) && (!state || !state.enabled);
  });
  if (playlistCatalogSyncState.loading && !catalogNeedsNewProvider && (!force || Date.now() - Number(playlistCatalogSyncState.startedAt || 0) < 1200)) {
    if (userPlaylists.length) renderUserPlaylistsList({ animate: isPlaylistPanelVisibleForRender(), preserveScroll: true });
    return;
  }
  if (!force && (userPlaylists.length || myPodcastCollections.length)) {
    var cachedAnimate = isPlaylistPanelVisibleForRender();
    renderUserPlaylistsList({ animate: cachedAnimate, preserveScroll: true });
    renderMyPodcastCollections({ animate: cachedAnimate });
    return;
  }
  var $pl = document.getElementById('pl-list');
  if ($pl) {
    $pl.innerHTML = miniQueueSkeleton();
    if (window.gsap) animateListItems($pl, '.mini-queue-skeleton', { x: 0, y: 6, stagger: 0.018, duration: 0.18, limit: 3 });
  }
  var $pod = document.getElementById('podcast-list');
  if ($pod) $pod.innerHTML = miniQueueSkeleton();
  if (playlistCatalogSyncState.timer) clearTimeout(playlistCatalogSyncState.timer);
  var token = playlistCatalogSyncState.token + 1;
  playlistCatalogSyncState = { token: token, loading: true, timer: 0, providers: {}, error: '', startedAt: Date.now() };
  ['netease', 'qq', 'kugou', 'qishui', 'spotify'].forEach(function (provider) {
    if (force && playlistCatalogProviderLoggedIn(provider)) setPlaylistCatalogProviderArray(provider, []);
    playlistCatalogSyncState.providers[provider] = {
      enabled: playlistCatalogProviderLoggedIn(provider),
      loaded: playlistCatalogProviderArray(provider).length,
      total: playlistCatalogProviderArray(provider).length,
      nextOffset: 0,
      hasMore: playlistCatalogProviderLoggedIn(provider),
      loading: false,
      error: ''
    };
  });
  if (force) {
    userPlaylists = [];
    playlistCatalogRevision += 1;
  }
  var firstPageTasks = Object.keys(playlistCatalogSyncState.providers).filter(playlistCatalogProviderLoggedIn).map(function (provider) {
    return loadPlaylistCatalogProviderPage(provider, 'first-page');
  });
  var podcastTask = loginStatus.loggedIn
    ? apiJson('/api/podcast/my', { timeoutMs: 12000 }).then(function (r) {
      if (playlistCatalogSyncState.token !== token) return;
      myPodcastCollections = r && r.collections || [];
      renderMyPodcastCollections({ animate: isPlaylistPanelVisibleForRender() });
    }).catch(function (e) { console.warn('[PodcastCatalog]', e); })
    : Promise.resolve();
  await Promise.allSettled(firstPageTasks.concat([podcastTask]));
  if (playlistCatalogSyncState.token !== token) return;
  playlistCatalogSyncState.loading = playlistCatalogHasPendingPages();
  if (userPlaylists.length) renderUserPlaylistsList({ animate: isPlaylistPanelVisibleForRender(), preserveScroll: true });
  if (playlistCatalogSyncState.loading) requestNextPlaylistCatalogPage('after-first-pages');
}
