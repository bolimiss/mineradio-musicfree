'use strict';

const path = require('path');
const { Worker } = require('worker_threads');
const { ERROR_CODES, MusicFreeRuntimeError } = require('./errors');

class IsolatedPluginRuntime {
  constructor(options = {}) {
    this.options = Object.assign({ callTimeoutMs: 15000, loadTimeoutMs: 5000 }, options);
    this.worker = null;
    this.pending = new Map();
    this.serial = 0;
    this.generation = 0;
    this.metadata = Object.assign({}, options.metadata || {});
    this.capabilities = [];
    this.methods = {};
    this.userVariables = [];
    this.supportedSearchType = [];
    this.fallbackPolicy = '';
    this.qualityPolicy = '';
    this.status = 'idle';
    this.failures = 0;
    this.lastError = null;
    this.ready = this.start();
  }

  start() {
    this.generation += 1;
    const generation = this.generation;
    this.status = 'starting';
    return new Promise((resolve, reject) => {
      const worker = new Worker(path.join(__dirname, 'plugin-worker.js'), {
        workerData: {
          source: String(this.options.source || ''),
          filename: this.options.filename,
          appRoot: this.options.appRoot || path.dirname(this.options.filename),
          metadata: this.options.metadata || {},
          userVariables: this.options.userVariables || {},
          appVersion: this.options.appVersion || '',
          allowedModules: this.options.allowedModules || [],
          loadTimeoutMs: this.options.loadTimeoutMs,
        },
      });
      this.worker = worker;
      let settled = false;
      const loadTimer = setTimeout(() => {
        if (settled || generation !== this.generation) return;
        settled = true;
        this.failures += 1;
        this.status = 'failed';
        worker.terminate();
        const error = new MusicFreeRuntimeError(ERROR_CODES.TIMEOUT, '插件加载超时');
        this.lastError = error.toJSON();
        reject(error);
      }, this.options.loadTimeoutMs + 500);

      worker.on('message', message => {
        if (generation !== this.generation || !message) return;
        if (message.type === 'ready') {
          clearTimeout(loadTimer);
          settled = true;
          this.metadata = Object.assign({}, this.metadata, message.metadata || {});
          this.capabilities = message.capabilities || [];
          this.methods = message.methods || {};
          this.userVariables = message.userVariables || [];
          this.supportedSearchType = message.supportedSearchType || [];
          this.fallbackPolicy = String(message.fallbackPolicy || '').toLowerCase();
          this.qualityPolicy = String(message.qualityPolicy || '').toLowerCase();
          this.status = 'ready';
          resolve(this);
          return;
        }
        if (message.type === 'fatal') {
          clearTimeout(loadTimer);
          settled = true;
          const error = new MusicFreeRuntimeError(ERROR_CODES.LOAD_FAILED, message.error && message.error.message, message.error || {});
          this.lastError = error.toJSON();
          this.status = 'failed';
          worker.terminate().catch(() => {});
          reject(error);
          return;
        }
        if (message.type === 'log') {
          const level = message.level === 'error' ? 'error' : message.level === 'warn' ? 'warn' : 'log';
          console[level]('[MusicFree:' + (this.metadata.platform || this.metadata.id || 'plugin') + ']', ...(message.args || []));
          return;
        }
        const pending = this.pending.get(message.id);
        if (!pending) return;
        this.pending.delete(message.id);
        clearTimeout(pending.timer);
        if (message.type === 'result') pending.resolve(message.result);
        else {
          this.failures += 1;
          this.lastError = message.error || null;
          pending.reject(new MusicFreeRuntimeError(message.error && message.error.code, message.error && message.error.message, message.error || {}));
        }
      });
      worker.on('error', error => this.handleWorkerFailure(error, generation, settled ? null : reject));
      worker.on('exit', code => {
        clearTimeout(loadTimer);
        if (generation !== this.generation || this.status === 'closed') return;
        if (code !== 0) this.handleWorkerFailure(new Error('插件运行进程退出，代码 ' + code), generation, settled ? null : reject);
      });
    });
  }

  handleWorkerFailure(error, generation, startupReject) {
    if (generation !== this.generation) return;
    this.failures += 1;
    this.status = 'failed';
    this.lastError = { code: ERROR_CODES.CRASHED, message: String(error && error.message || error) };
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new MusicFreeRuntimeError(ERROR_CODES.CRASHED, this.lastError.message));
    }
    this.pending.clear();
    if (startupReject) startupReject(new MusicFreeRuntimeError(ERROR_CODES.LOAD_FAILED, this.lastError.message));
  }

  has(capability) { return this.capabilities.includes(capability); }

  async call(capability, ...args) {
    await this.ready;
    if (!this.has(capability)) throw new MusicFreeRuntimeError(ERROR_CODES.UNSUPPORTED, '插件不支持 ' + capability, { capability });
    if (!this.worker || this.status !== 'ready') await this.restart();
    const id = ++this.serial;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(async () => {
        if (!this.pending.has(id)) return;
        this.pending.delete(id);
        this.failures += 1;
        this.lastError = { code: ERROR_CODES.TIMEOUT, message: capability + ' 调用超时' };
        reject(new MusicFreeRuntimeError(ERROR_CODES.TIMEOUT, this.lastError.message, { capability }));
        await this.restart().catch(() => {});
      }, this.options.callTimeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.worker.postMessage({ type: 'call', id, capability, args });
    });
  }

  async restart() {
    const old = this.worker;
    this.worker = null;
    this.generation += 1;
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new MusicFreeRuntimeError(ERROR_CODES.CRASHED, '插件运行环境正在恢复'));
    }
    this.pending.clear();
    if (old) await old.terminate().catch(() => {});
    this.ready = this.start();
    return this.ready;
  }

  async close() {
    this.status = 'closed';
    this.generation += 1;
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new MusicFreeRuntimeError(ERROR_CODES.CRASHED, '插件运行环境已关闭'));
    }
    this.pending.clear();
    if (this.worker) await this.worker.terminate().catch(() => {});
    this.worker = null;
  }

  diagnostics() {
    return {
      status: this.status,
      failures: this.failures,
      lastError: this.lastError,
      capabilities: this.capabilities.slice(),
      methods: Object.assign({}, this.methods),
    };
  }
}

class IsolatedPluginAdapter {
  constructor(runtime) {
    this.runtime = runtime;
    this.metadata = runtime.metadata;
  }

  has(capability) { return this.runtime.has(capability); }
  capabilities() { return this.runtime.capabilities.slice(); }
  methodName(capability) { return this.runtime.methods[capability] || ''; }
  call(capability, ...args) { return this.runtime.call(capability, ...args); }
  search(query, page, type) { return this.runtime.call('search', query, page, type); }
  media(item, quality) { return this.runtime.call('getMediaSource', item, quality); }
  video(item, quality) { return this.runtime.call('getVideoSource', item, quality); }
}

module.exports = { IsolatedPluginRuntime, IsolatedPluginAdapter };
