'use strict';

const { followRedirects, normalizeInput } = require('./link-normalizer');
const { detectPlatform, detectResourceType } = require('./platform-detector');
const { toPlaylist } = require('./models');

class UniversalImportService {
  constructor(options) {
    this.database = options.database;
    this.parse = options.parse;
  }

  async normalize(input, options = {}) {
    const received = normalizeInput(input);
    if (!received.sourceUrl) throw new Error('IMPORT_LINK_EMPTY');
    if (!received.isHttp) {
      const error = new Error('APP_SCHEME_REQUIRES_EMBEDDED_WEB_URL');
      error.code = 'APP_SCHEME_UNSUPPORTED';
      throw error;
    }
    const resolvedUrl = options.followRedirects === false ? received.sourceUrl : await followRedirects(received.sourceUrl, { timeoutMs: 8000 });
    const platform = detectPlatform(resolvedUrl);
    if (!platform.id) {
      const error = new Error('UNSUPPORTED_MUSIC_PLATFORM');
      error.code = 'PLATFORM_NOT_SUPPORTED';
      throw error;
    }
    return Object.assign(received, { sourceUrl: resolvedUrl, originalUrl: received.sourceUrl, platform: platform.id, platformLabel: platform.label, resourceType: detectResourceType(resolvedUrl) });
  }

  async preview(input, options = {}) {
    const startedAt = Date.now();
    let normalized;
    try {
      normalized = await this.normalize(input, options);
      const raw = await this.parse(normalized.sourceUrl, normalized.platform);
      const playlist = toPlaylist(raw, normalized);
      if (!playlist.tracks.length) throw new Error('IMPORT_CONTAINS_NO_TRACKS');
      const result = { ok: true, normalized, playlist, elapsedMs: Date.now() - startedAt };
      this.database.recordTest({ ok: true, at: Date.now(), platform: normalized.platform, resourceType: normalized.resourceType, elapsedMs: result.elapsedMs, trackCount: playlist.tracks.length, receiver: options.receiver || 'web' });
      return result;
    } catch (error) {
      this.database.recordTest({ ok: false, at: Date.now(), platform: normalized && normalized.platform || '', resourceType: normalized && normalized.resourceType || '', elapsedMs: Date.now() - startedAt, error: error.code || error.message || 'IMPORT_FAILED', receiver: options.receiver || 'web' });
      throw error;
    }
  }

  async import(input, options = {}) {
    const result = await this.preview(input, options);
    const existing = this.database.list().find(item => item.platform === result.playlist.platform && (item.sourceUrl === result.playlist.sourceUrl || item.id === result.playlist.id));
    if (existing) result.playlist = Object.assign({}, existing, result.playlist, { id: existing.id, playlistId: existing.playlistId, autoSync: existing.autoSync !== false });
    const saved = this.database.upsert(result.playlist);
    this.database.event(existing ? 'playlist-reimported' : 'playlist-imported', { id: saved.id, platform: saved.platform, trackCount: saved.tracks.length, receiver: options.receiver || 'web' });
    return Object.assign({}, result, { playlist: saved, created: !existing });
  }

  migrate(playlists) {
    const saved = [];
    for (const item of Array.isArray(playlists) ? playlists : []) {
      if (!item || !item.sourceUrl || !Array.isArray(item.tracks)) continue;
      const normalized = { platform: item.platform || item.provider || item.source || '', sourceUrl: item.sourceUrl };
      const playlist = toPlaylist({
        provider: normalized.platform,
        sourceUrl: item.sourceUrl,
        playlist: { id: item.playlistId || item.id, name: item.name || item.title, cover: item.cover, creator: item.creator },
        tracks: item.tracks,
      }, normalized);
      playlist.autoSync = item.autoSync !== false;
      saved.push(this.database.upsert(playlist));
    }
    if (saved.length) this.database.event('legacy-playlists-migrated', { count: saved.length });
    return saved;
  }
}

module.exports = { UniversalImportService };
