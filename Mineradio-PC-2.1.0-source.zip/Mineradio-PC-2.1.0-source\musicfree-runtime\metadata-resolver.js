'use strict';

function present(value) {
  return value != null && String(value).trim() !== '' && !/^未知(?:歌曲|歌手|专辑)$/.test(String(value).trim());
}

function mergeTrackMetadata(primary, candidates = []) {
  const output = Object.assign({}, primary || {});
  output.metadataProvenance = Object.assign({}, primary && primary.metadataProvenance || {});
  const fields = ['cover', 'album', 'artist', 'duration', 'lyric'];
  for (const candidate of candidates) {
    if (!candidate || typeof candidate !== 'object') continue;
    for (const field of fields) {
      if (present(output[field]) || !present(candidate[field])) continue;
      output[field] = candidate[field];
      if (field === 'cover') output.artwork = candidate.artwork || candidate.cover;
      output.metadataProvenance[field] = {
        pluginId: String(candidate.musicFreePluginId || candidate.unifiedSource && candidate.unifiedSource.pluginId || ''),
        platform: String(candidate.musicFreeLabel || candidate.musicFreePlatform || ''),
      };
    }
    if (output.cover && output.album && present(output.artist)) break;
  }
  return output;
}

function needsMetadata(track) {
  return !!track && (!present(track.cover) || !present(track.album) || !present(track.artist));
}

module.exports = { mergeTrackMetadata, needsMetadata, present };
