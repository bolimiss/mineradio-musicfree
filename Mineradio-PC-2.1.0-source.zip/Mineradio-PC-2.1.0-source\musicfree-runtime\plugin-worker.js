'use strict';

const path = require('path');
const vm = require('vm');
const Module = require('module');
const { parentPort, workerData } = require('worker_threads');
const nodeCrypto = require('crypto');
const { PluginAdapter } = require('./plugin-adapter');
const { serializeError } = require('./errors');

const BLOCKED_BUILTINS = new Set([
  'child_process', 'cluster', 'dgram', 'diagnostics_channel', 'fs', 'fs/promises',
  'inspector', 'module', 'repl', 'worker_threads', 'vm', 'v8'
]);
const ALLOWED_BUILTINS = new Set([
  'assert', 'buffer', 'crypto', 'events', 'http', 'https', 'os', 'path',
  'querystring', 'stream', 'string_decoder', 'timers', 'tty', 'url', 'util', 'zlib'
]);

function normalizeSource(source) {
  let text = String(source || '').replace(/^\uFEFF/, '');
  if (/\bexport\s+default\b/.test(text)) {
    text = text.replace(/\bexport\s+default\s+(?=\{)/, 'module.exports = ');
    text = text.replace(/\bexport\s+default\s+([A-Za-z_$][\w$]*)\s*;?\s*$/, 'module.exports = $1;');
  }
  if (/^\s*import\s/m.test(text)) throw new Error('PLUGIN_ESM_IMPORT_REQUIRES_BUNDLE');
  if (!/\bmodule\.exports\b|\bexports\s*=/.test(text) && /\b(?:const|let|var)\s+plugin\s*=/.test(text)) {
    text += '\nmodule.exports = plugin;\n';
  }
  return text;
}

function packageName(request) {
  const value = String(request || '');
  if (value.startsWith('@')) return value.split('/').slice(0, 2).join('/');
  return value.split('/')[0];
}

function createRestrictedRequire(filename, appRoot) {
  const appRequire = Module.createRequire(path.join(path.resolve(appRoot), 'package.json'));
  const localRequire = Module.createRequire(filename);
  return function restrictedRequire(request) {
    const value = String(request || '');
    const builtin = value.replace(/^node:/, '');
    if (Module.builtinModules.includes(value) || Module.builtinModules.includes(builtin)) {
      if (BLOCKED_BUILTINS.has(builtin) || !ALLOWED_BUILTINS.has(builtin)) {
        throw new Error('PLUGIN_REQUIRE_BLOCKED:' + builtin);
      }
      return require(builtin);
    }
    if (value.startsWith('.') || path.isAbsolute(value)) {
      const resolved = localRequire.resolve(value);
      const allowedRoot = path.resolve(path.dirname(filename)) + path.sep;
      if (!path.resolve(resolved).startsWith(allowedRoot)) throw new Error('PLUGIN_REQUIRE_OUTSIDE_PACKAGE:' + value);
      return localRequire(resolved);
    }
    const name = packageName(value);
    const allowed = Array.isArray(workerData.allowedModules) ? workerData.allowedModules : [];
    if (allowed.length && !allowed.includes(name)) throw new Error('PLUGIN_DEPENDENCY_NOT_ALLOWED:' + name);
    return appRequire(value);
  };
}

function serializable(value) {
  if (value == null) return value;
  try { return JSON.parse(JSON.stringify(value)); }
  catch (_) { throw new Error('PLUGIN_RESPONSE_NOT_SERIALIZABLE'); }
}

function createPlugin() {
  const filename = path.resolve(workerData.filename);
  const moduleObject = { exports: {} };
  const safeProcess = Object.freeze({
    platform: process.platform,
    arch: process.arch,
    versions: Object.freeze({ node: process.versions.node }),
    env: Object.freeze({ NODE_ENV: process.env.NODE_ENV || 'production' }),
  });
  const context = vm.createContext({
    module: moduleObject,
    exports: moduleObject.exports,
    require: createRestrictedRequire(filename, workerData.appRoot),
    __filename: filename,
    __dirname: path.dirname(filename),
    Buffer,
    URL,
    URLSearchParams,
    TextEncoder,
    TextDecoder,
    AbortController,
    AbortSignal,
    fetch,
    Headers: typeof Headers === 'undefined' ? undefined : Headers,
    Request: typeof Request === 'undefined' ? undefined : Request,
    Response: typeof Response === 'undefined' ? undefined : Response,
    FormData: typeof FormData === 'undefined' ? undefined : FormData,
    Blob: typeof Blob === 'undefined' ? undefined : Blob,
    atob: typeof atob === 'undefined' ? undefined : atob,
    btoa: typeof btoa === 'undefined' ? undefined : btoa,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    setImmediate,
    clearImmediate,
    queueMicrotask,
    crypto: nodeCrypto.webcrypto,
    navigator: Object.freeze({ platform: process.platform, userAgent: 'Mineradio/' + String(workerData.appVersion || '') }),
    console: Object.freeze({
      log: (...args) => parentPort.postMessage({ type: 'log', level: 'info', args: serializable(args) }),
      warn: (...args) => parentPort.postMessage({ type: 'log', level: 'warn', args: serializable(args) }),
      error: (...args) => parentPort.postMessage({ type: 'log', level: 'error', args: serializable(args) }),
    }),
    process: safeProcess,
    env: Object.freeze({
      os: process.platform,
      appVersion: String(workerData.appVersion || ''),
      getUserVariables: async () => Object.assign({}, workerData.userVariables || {}),
    }),
  });
  context.global = context;
  context.globalThis = context;
  const wrapper = '(function (exports, require, module, __filename, __dirname) {\n' + normalizeSource(workerData.source) + '\n})';
  const script = new vm.Script(wrapper, { filename, displayErrors: true });
  const factory = script.runInContext(context, { timeout: Number(workerData.loadTimeoutMs) || 5000 });
  factory(moduleObject.exports, context.require, moduleObject, filename, path.dirname(filename));
  return new PluginAdapter(moduleObject.exports, workerData.metadata || {});
}

let adapter;
try {
  adapter = createPlugin();
  parentPort.postMessage({
    type: 'ready',
    metadata: adapter.metadata,
    capabilities: adapter.capabilities(),
    methods: adapter.methods,
    userVariables: serializable(adapter.plugin.userVariables || []),
    supportedSearchType: serializable(adapter.plugin.supportedSearchType || []),
    fallbackPolicy: String(adapter.plugin.fallbackPolicy || '').toLowerCase(),
    qualityPolicy: String(adapter.plugin.qualityPolicy || '').toLowerCase(),
  });
} catch (error) {
  parentPort.postMessage({ type: 'fatal', error: serializeError(error, { phase: 'load' }) });
  parentPort.close();
}

parentPort.on('message', async message => {
  if (!adapter || !message || message.type !== 'call') return;
  try {
    let result;
    if (message.capability === 'search') result = await adapter.search(...(message.args || []));
    else if (message.capability === 'getMediaSource') result = await adapter.media(...(message.args || []));
    else if (message.capability === 'getVideoSource') result = await adapter.video(...(message.args || []));
    else result = await adapter.call(message.capability, ...(message.args || []));
    parentPort.postMessage({ type: 'result', id: message.id, result: serializable(result) });
  } catch (error) {
    parentPort.postMessage({ type: 'error', id: message.id, error: serializeError(error, { capability: message.capability }) });
  }
});
