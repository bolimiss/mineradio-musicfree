'use strict';

const ERROR_CODES = Object.freeze({
  TIMEOUT: 'PLUGIN_TIMEOUT',
  CRASHED: 'PLUGIN_CRASHED',
  LOAD_FAILED: 'PLUGIN_LOAD_FAILED',
  INVALID_EXPORT: 'PLUGIN_INVALID_EXPORT',
  UNSUPPORTED: 'PLUGIN_CAPABILITY_UNSUPPORTED',
  INVALID_RESPONSE: 'PLUGIN_INVALID_RESPONSE',
  EMPTY_RESULT: 'PLUGIN_EMPTY_RESULT',
  MEDIA_UNAVAILABLE: 'MEDIA_UNAVAILABLE',
  MEDIA_INVALID: 'MEDIA_INVALID',
  NETWORK: 'NETWORK_ERROR',
  CONFIG_REQUIRED: 'PLUGIN_CONFIG_REQUIRED',
});

class MusicFreeRuntimeError extends Error {
  constructor(code, message, details = {}) {
    super(message || code || 'MUSICFREE_RUNTIME_ERROR');
    this.name = 'MusicFreeRuntimeError';
    this.code = code || 'MUSICFREE_RUNTIME_ERROR';
    this.details = details && typeof details === 'object' ? details : {};
  }

  toJSON() {
    return { name: this.name, code: this.code, message: this.message, details: this.details };
  }
}

function errorCode(error) {
  if (error && error.code) return String(error.code);
  const message = String(error && error.message || error || '').toUpperCase();
  if (message.includes('TIMEOUT') || message.includes('ABORT')) return ERROR_CODES.TIMEOUT;
  if (message.includes('FETCH') || message.includes('NETWORK') || message.includes('ECONN')) return ERROR_CODES.NETWORK;
  return ERROR_CODES.CRASHED;
}

function serializeError(error, details = {}) {
  const source = error || {};
  return {
    name: String(source.name || 'Error'),
    code: errorCode(source),
    message: String(source.message || source || 'Unknown error'),
    stack: String(source.stack || ''),
    details: Object.assign({}, source.details || {}, details || {}),
  };
}

module.exports = { ERROR_CODES, MusicFreeRuntimeError, errorCode, serializeError };
