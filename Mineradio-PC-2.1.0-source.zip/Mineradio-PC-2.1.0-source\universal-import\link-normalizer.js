'use strict';

const HTTP_URL = /https?:\/\/[^\s<>"'\]\[\u3008\u3009]+/ig;
const APP_URL = /(?:qqmusic|orpheus|neteasecloudmusic|kugou|kuwo|qishui|luna|music):\/\/[^\s<>"']+/ig;

function trimSharedUrl(value) {
  return String(value || '')
    .trim()
    .replace(/[\u3002\uff0c\uff1b\uff01\uff1f,;.!?]+$/g, '');
}

function safelyDecode(value) {
  let current = String(value || '');
  for (let i = 0; i < 2; i += 1) {
    try {
      const decoded = decodeURIComponent(current);
      if (decoded === current) break;
      current = decoded;
    } catch (_) { break; }
  }
  return current;
}

function extractCandidates(input) {
  const raw = safelyDecode(String(input || '').trim());
  const http = raw.match(HTTP_URL) || [];
  const app = raw.match(APP_URL) || [];
  return [...http, ...app].map(trimSharedUrl).filter(Boolean);
}

function httpFromAppScheme(value) {
  const raw = safelyDecode(value);
  const embedded = raw.match(HTTP_URL);
  if (embedded && embedded[0]) return trimSharedUrl(embedded[0]);
  try {
    const parsed = new URL(raw);
    for (const key of ['url', 'link', 'target', 'shareUrl', 'share_url', 'webUrl']) {
      const candidate = safelyDecode(parsed.searchParams.get(key) || '');
      if (/^https?:\/\//i.test(candidate)) return trimSharedUrl(candidate);
    }
  } catch (_) { }
  return raw;
}

function normalizeInput(input) {
  const raw = String(input || '').trim();
  const candidates = extractCandidates(raw);
  let sourceUrl = candidates[0] || trimSharedUrl(raw);
  if (!/^https?:\/\//i.test(sourceUrl)) sourceUrl = httpFromAppScheme(sourceUrl);
  return {
    raw,
    sourceUrl,
    candidates,
    isHttp: /^https?:\/\//i.test(sourceUrl),
    isAppScheme: /^[a-z][a-z0-9+.-]*:\/\//i.test(sourceUrl) && !/^https?:\/\//i.test(sourceUrl),
  };
}

async function followRedirects(sourceUrl, options = {}) {
  if (!/^https?:\/\//i.test(sourceUrl)) return sourceUrl;
  const timeoutMs = Math.max(1000, Number(options.timeoutMs) || 8000);
  try {
    const response = await fetch(sourceUrl, {
      method: 'GET',
      redirect: 'follow',
      headers: {
        'User-Agent': options.userAgent || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/json;q=0.8,*/*;q=0.5',
        Range: 'bytes=0-65535',
      },
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (response.body && typeof response.body.cancel === 'function') await response.body.cancel().catch(() => {});
    return String(response.url || sourceUrl);
  } catch (_) {
    return sourceUrl;
  }
}

module.exports = { extractCandidates, followRedirects, normalizeInput, safelyDecode, trimSharedUrl };
