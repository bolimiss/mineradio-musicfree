var homeDashboardReviewOffset = 0;
var homeDashboardHeroFingerprint = '';
var homeDashboardQuickFingerprint = '';
var homeDashboardDiscoveryFingerprint = '';
var homeDashboardDiscoveryCache = [];
var homeDashboardRefreshTimer = null;
var HOME_DASHBOARD_VIDEO_DB_NAME = 'mineradio-home-dashboard-video-v1';
var HOME_DASHBOARD_VIDEO_STORE = 'media';
var HOME_DASHBOARD_VIDEO_BLOB_ID = 'home-hero-video';
var HOME_DASHBOARD_VIDEO_META_KEY = 'mineradio-home-dashboard-video-meta-v1';
var HOME_DASHBOARD_VIDEO_MAX_BYTES = 300 * 1024 * 1024;
var homeDashboardVideoDbPromise = null;
var homeDashboardVideoObjectUrl = '';
var homeDashboardVideoSourceUrl = '';
var homeDashboardVideoLoadToken = 0;
var homeDashboardVideoAttachBusy = false;
var homeDashboardVideoDecodeFailed = false;
var homeDashboardVideoPowerObserver = null;
var homeDashboardVideoControlsBound = false;
var homeWallpaperCropDraft = null;
var homeWallpaperCropObjectUrl = '';
var homeWallpaperProjectItems = [];
var homePlatformRecommendationControlsBound = false;
var homePlatformRecommendationDailyRenderRaf = 0;
var HOME_PLATFORM_DAILY_ROW_HEIGHT = 84;
var HOME_PLATFORM_DAILY_OVERSCAN_ROWS = 3;
var HOME_PLATFORM_DAILY_MAX_RENDERED_CARDS = 24;
var homePlatformRecommendationState = {
  open: false,
  source: 'netease',
  contentType: 'songs',
  previousFocus: null,
  neteaseLoading: false,
  feeds: {
    qq: { loading: false, loaded: false, songs: [], error: '', message: '', mode: '', source: '', fallback: false, provenance: '' },
    qishui: { loading: false, loaded: false, songs: [], error: '', message: '', mode: '', source: '', fallback: false, provenance: '' },
    kugou: { loading: false, loaded: false, songs: [], error: '', message: '', mode: '', source: '', fallback: false, provenance: '' },
    spotify: { loading: false, loaded: false, songs: [], error: '', message: '', mode: '', source: '', fallback: false, provenance: '' },
  },
  publicFeeds: { songs: {}, playlists: {} },
};

var HOME_DASHBOARD_REVIEW_DEFAULTS = [
  { text: '有些歌不是突然好听，而是终于听懂了。', source: '每日热评' },
  { text: '慢一点没关系，重要的是一直在向喜欢的生活靠近。', source: '每日热评' },
  { text: '错过落日余晖，还会有满天星辰。', source: '每日热评' },
  { text: '保持热爱，奔赴下一场山海。', source: '每日热评' },
  { text: '答案在路上，自由在风里。', source: '每日热评' },
  { text: '让今天的声音，从你喜欢的地方开始。', source: 'Mineradio' },
];

function homeDashboardSvgText(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function homeDashboardCoverInitials(text) {
  var raw = String(text || '音乐').replace(/\s+/g, '').trim();
  var chars = Array.from(raw || '音乐');
  return chars.slice(0, Math.min(2, chars.length)).join('');
}

function homeDashboardGeneratedCover(title, label, tone) {
  var palettes = {
    search: ['#9db8cf', '#f8f4ee', '#00f5d4'],
    playlist: ['#9db8cf', '#00f5d4', '#2442ff'],
    library: ['#00f5d4', '#f8f4ee', '#2442ff'],
    mix: ['#f8f4ee', '#00f5d4', '#2442ff'],
  };
  var palette = palettes[tone] || palettes.playlist;
  var letters = homeDashboardSvgText(homeDashboardCoverInitials(title || label));
  var sub = homeDashboardSvgText(String(label || 'MINERADIO').toUpperCase().slice(0, 14));
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 320">' +
    '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0" stop-color="' + palette[0] + '"/><stop offset=".52" stop-color="' + palette[1] + '"/>' +
    '<stop offset="1" stop-color="' + palette[2] + '"/></linearGradient>' +
    '<radialGradient id="r" cx="34%" cy="24%" r="72%"><stop offset="0" stop-color="#fff" stop-opacity=".55"/>' +
    '<stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>' +
    '<rect width="320" height="320" rx="54" fill="#080a10"/>' +
    '<rect width="320" height="320" rx="54" fill="url(#g)" opacity=".84"/>' +
    '<circle cx="242" cy="66" r="98" fill="url(#r)"/>' +
    '<circle cx="112" cy="214" r="84" fill="#05060a" opacity=".34"/>' +
    '<circle cx="112" cy="214" r="52" fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="2"/>' +
    '<circle cx="112" cy="214" r="22" fill="#fff" opacity=".18"/>' +
    '<path d="M222 118v98c0 19-16 34-39 34-20 0-35-11-35-27 0-17 16-29 38-29 7 0 14 1 20 4v-90l72-18v30z" fill="#fff" opacity=".32"/>' +
    '<text x="28" y="72" fill="#fff" opacity=".72" font-size="18" font-family="Arial,Microsoft YaHei,sans-serif" font-weight="800" letter-spacing="2">' + sub + '</text>' +
    '<text x="28" y="148" fill="#fff" font-size="58" font-family="Arial,Microsoft YaHei,sans-serif" font-weight="900">' + letters + '</text>' +
    '<rect x="0" y="0" width="320" height="320" rx="54" fill="none" stroke="#fff" stroke-opacity=".20"/>' +
    '</svg>';
  return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}

function homeDashboardReadReviews() {
  try {
    var saved = JSON.parse(localStorage.getItem('mineradio-daily-review-quotes-v1') || '[]');
    if (Array.isArray(saved) && saved.length) {
      var normalized = saved.map(function (item) {
        if (typeof item === 'string') return { text: item.trim(), source: '我的热评' };
        return {
          text: String(item && item.text || '').trim(),
          source: String(item && item.source || '我的热评').trim(),
        };
      }).filter(function (item) { return item.text; });
      if (normalized.length) return normalized;
    }
  } catch (_error) { }
  return HOME_DASHBOARD_REVIEW_DEFAULTS.slice();
}

function homeDashboardDayNumber() {
  var now = new Date();
  return Math.floor(new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() / 86400000);
}

function homeDashboardSelectedReview() {
  var reviews = homeDashboardReadReviews();
  if (!reviews.length) return { text: '让今天的声音，从你喜欢的地方开始。', source: 'Mineradio' };
  var index = ((homeDashboardDayNumber() + homeDashboardReviewOffset) % reviews.length + reviews.length) % reviews.length;
  return reviews[index];
}

function homeDashboardUpdateClock() {
  var time = document.getElementById('daily-review-time');
  var date = document.getElementById('daily-review-date');
  if (!time || !date) return;
  var now = new Date();
  time.textContent = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
  date.textContent = now.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'long',
  });
}

function homeDashboardNotify(message) {
  if (typeof showToast === 'function') showToast(message);
  else console.info('[HomeDashboard]', message);
}

function homeDashboardOpenVideoDb() {
  if (homeDashboardVideoDbPromise) return homeDashboardVideoDbPromise;
  homeDashboardVideoDbPromise = new Promise(function (resolve, reject) {
    if (!window.indexedDB) {
      reject(new Error('INDEXEDDB_UNAVAILABLE'));
      return;
    }
    var request = window.indexedDB.open(HOME_DASHBOARD_VIDEO_DB_NAME, 1);
    request.onupgradeneeded = function () {
      var db = request.result;
      if (!db.objectStoreNames.contains(HOME_DASHBOARD_VIDEO_STORE)) {
        db.createObjectStore(HOME_DASHBOARD_VIDEO_STORE, { keyPath: 'id' });
      }
    };
    request.onsuccess = function () { resolve(request.result); };
    request.onerror = function () {
      homeDashboardVideoDbPromise = null;
      reject(request.error || new Error('HOME_VIDEO_DB_OPEN_FAILED'));
    };
  });
  return homeDashboardVideoDbPromise;
}

async function homeDashboardPutVideoBlob(blob, meta) {
  var db = await homeDashboardOpenVideoDb();
  return new Promise(function (resolve, reject) {
    var transaction = db.transaction(HOME_DASHBOARD_VIDEO_STORE, 'readwrite');
    transaction.objectStore(HOME_DASHBOARD_VIDEO_STORE).put({
      id: HOME_DASHBOARD_VIDEO_BLOB_ID,
      blob: blob,
      meta: meta,
    });
    transaction.oncomplete = function () { resolve(); };
    transaction.onerror = function () { reject(transaction.error || new Error('HOME_VIDEO_SAVE_FAILED')); };
    transaction.onabort = function () { reject(transaction.error || new Error('HOME_VIDEO_SAVE_ABORTED')); };
  });
}

async function homeDashboardGetVideoBlob() {
  var db = await homeDashboardOpenVideoDb();
  return new Promise(function (resolve, reject) {
    var transaction = db.transaction(HOME_DASHBOARD_VIDEO_STORE, 'readonly');
    var request = transaction.objectStore(HOME_DASHBOARD_VIDEO_STORE).get(HOME_DASHBOARD_VIDEO_BLOB_ID);
    request.onsuccess = function () { resolve(request.result || null); };
    request.onerror = function () { reject(request.error || new Error('HOME_VIDEO_READ_FAILED')); };
  });
}

async function homeDashboardDeleteVideoBlob() {
  var db = await homeDashboardOpenVideoDb();
  return new Promise(function (resolve, reject) {
    var transaction = db.transaction(HOME_DASHBOARD_VIDEO_STORE, 'readwrite');
    transaction.objectStore(HOME_DASHBOARD_VIDEO_STORE).delete(HOME_DASHBOARD_VIDEO_BLOB_ID);
    transaction.oncomplete = function () { resolve(); };
    transaction.onerror = function () { reject(transaction.error || new Error('HOME_VIDEO_DELETE_FAILED')); };
    transaction.onabort = function () { reject(transaction.error || new Error('HOME_VIDEO_DELETE_ABORTED')); };
  });
}

function homeDashboardReadVideoMeta() {
  try {
    var meta = JSON.parse(localStorage.getItem(HOME_DASHBOARD_VIDEO_META_KEY) || 'null');
    if (!meta || (meta.version !== 1 && meta.version !== 2 && meta.version !== 3)) return null;
    if (meta.version === 1 && !/\.mp4$/i.test(String(meta.name || ''))) return null;
    if (meta.version === 1) meta.kind = 'video';
    if (!/^(video|image)$/.test(String(meta.kind || ''))) return null;
    return meta;
  } catch (_error) {
    return null;
  }
}

function homeDashboardMediaKind(file) {
  if (!file) return '';
  var type = String(file.type || '').toLowerCase();
  var name = String(file.name || '').toLowerCase();
  if (/^image\//.test(type) || /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(name)) return 'image';
  if (/^video\//.test(type) || /\.(mp4|webm|mov|m4v|mkv)$/i.test(name)) return 'video';
  return '';
}

function homeDashboardVideoShouldPlay() {
  return !document.hidden
    && typeof emptyHomeActive !== 'undefined'
    && !!emptyHomeActive
    && !!document.body
    && document.body.classList.contains('empty-home-active');
}

function homeDashboardReleaseVideoSource(removeElement) {
  homeDashboardVideoLoadToken += 1;
  var video = document.querySelector('#empty-home .home-dashboard-media, #empty-home .home-dashboard-video');
  if (video) {
    try { if (typeof video.pause === 'function') video.pause(); } catch (_error) { }
    try {
      video.removeAttribute('src');
      if (typeof video.load === 'function') video.load();
    } catch (_error) { }
    if (removeElement !== false && video.parentNode) video.parentNode.removeChild(video);
  }
  if (homeDashboardVideoObjectUrl) {
    try { URL.revokeObjectURL(homeDashboardVideoObjectUrl); } catch (_error) { }
    homeDashboardVideoObjectUrl = '';
  }
  homeDashboardVideoSourceUrl = '';
}

async function homeDashboardAttachVideo() {
  var meta = homeDashboardReadVideoMeta();
  if (!meta || !homeDashboardVideoShouldPlay() || homeDashboardVideoDecodeFailed) {
    homeDashboardReleaseVideoSource(true);
    return;
  }
  var card = document.querySelector('#empty-home .daily-review-card');
  if (!card) return;
  var currentMedia = card.querySelector('.home-dashboard-media, .home-dashboard-video');
  if (currentMedia && homeDashboardVideoSourceUrl) {
    if (typeof currentMedia.play === 'function') currentMedia.play().catch(function () { });
    return;
  }
  if (homeDashboardVideoAttachBusy) return;

  homeDashboardVideoAttachBusy = true;
  homeDashboardReleaseVideoSource(true);
  var token = homeDashboardVideoLoadToken;
  var shouldRetry = false;
  try {
    var objectUrl = '';
    var sourceUrl = '';
    if (meta.wallpaperProjectId) {
      if (typeof loadWallpaperEngineLibrary === 'function') await loadWallpaperEngineLibrary(false, false);
      var project = typeof wallpaperEngineProjectById === 'function' ? wallpaperEngineProjectById(meta.wallpaperProjectId) : null;
      if (!project || !project.playable || String(project.mediaType || '').toLowerCase() !== 'video') {
        throw new Error('WALLPAPER_PROJECT_UNAVAILABLE');
      }
      sourceUrl = wallpaperEngineMediaUrl(project, 'media');
    } else {
      var record = await homeDashboardGetVideoBlob();
      var blob = record && record.blob;
      if (!blob) {
        localStorage.removeItem(HOME_DASHBOARD_VIDEO_META_KEY);
        homeDashboardRenderVideoActions();
        return;
      }
      objectUrl = URL.createObjectURL(blob);
      sourceUrl = objectUrl;
    }
    if (token !== homeDashboardVideoLoadToken || !homeDashboardVideoShouldPlay()) {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      shouldRetry = homeDashboardVideoShouldPlay();
      return;
    }
    var video = document.createElement(meta.kind === 'image' ? 'img' : 'video');
    video.className = 'home-dashboard-media home-dashboard-video';
    video.setAttribute('aria-hidden', 'true');
    video.style.objectPosition = Number(meta.cropX == null ? 50 : meta.cropX) + '% ' + Number(meta.cropY == null ? 50 : meta.cropY) + '%';
    video.style.transformOrigin = video.style.objectPosition;
    video.style.transform = 'scale(' + Math.max(1, Number(meta.cropScale) || 1) + ')';
    if (meta.kind !== 'image') {
      video.muted = true;
      video.defaultMuted = true;
      video.loop = true;
      video.playsInline = true;
      video.setAttribute('playsinline', '');
      video.preload = 'metadata';
    }
    video.src = sourceUrl;
    video.addEventListener('error', function () {
      if (token !== homeDashboardVideoLoadToken || !video.getAttribute('src')) return;
      homeDashboardVideoDecodeFailed = true;
      homeDashboardReleaseVideoSource(true);
      homeDashboardNotify(meta.kind === 'image' ? '图片读取失败，请重新选择' : '视频无法解码，建议使用 H.264 编码的 MP4');
    }, { once: true });
    homeDashboardVideoObjectUrl = objectUrl;
    homeDashboardVideoSourceUrl = sourceUrl;
    card.insertBefore(video, card.firstChild);
    if (typeof video.play === 'function') video.play().catch(function () { });
  } catch (error) {
    console.warn('[HomeDashboardVideo]', error);
    homeDashboardReleaseVideoSource(true);
    homeDashboardNotify('首页卡片素材读取失败，请重新选择');
  } finally {
    homeDashboardVideoAttachBusy = false;
    if (shouldRetry && !homeDashboardVideoDecodeFailed) {
      setTimeout(function () { homeDashboardUpdateVideoPower(); }, 0);
    }
  }
}

function homeDashboardRenderVideoActions() {
  var hasVideo = !!homeDashboardReadVideoMeta();
  var choose = document.getElementById('home-dashboard-video-choose');
  var clear = document.getElementById('home-dashboard-video-clear');
  if (choose) {
    choose.textContent = 'Wallpaper';
    choose.setAttribute('onclick', 'openHomeWallpaperLibrary()');
    choose.title = '打开首页卡片专用壁纸库';
  }
  if (clear) {
    clear.hidden = !hasVideo;
    clear.textContent = '移除壁纸';
    clear.title = '移除当前首页卡片图片或视频';
  }
}

function homeDashboardUpdateVideoPower() {
  if (!homeDashboardVideoShouldPlay() || !homeDashboardReadVideoMeta()) {
    homeDashboardReleaseVideoSource(true);
    return;
  }
  var media = document.querySelector('#empty-home .home-dashboard-media, #empty-home .home-dashboard-video');
  if (media && homeDashboardVideoSourceUrl) {
    if (typeof media.play === 'function') media.play().catch(function () { });
    return;
  }
  homeDashboardAttachVideo();
}

function openHomeDashboardVideoPicker() {
  var input = document.getElementById('home-dashboard-video-input');
  if (input) input.click();
}

async function handleHomeDashboardVideoFile(file) {
  var kind = homeDashboardMediaKind(file);
  if (!kind) {
    homeDashboardNotify('请选择图片或视频文件');
    return;
  }
  if (Number(file.size) > (kind === 'image' ? 40 * 1024 * 1024 : HOME_DASHBOARD_VIDEO_MAX_BYTES)) {
    homeDashboardNotify(kind === 'image' ? '图片不能超过 40 MB' : '视频不能超过 300 MB');
    return;
  }
  openHomeWallpaperCropForBlob(file, String(file.name || ('home.' + kind)), String(file.type || ''), kind);
}

function homeWallpaperCardAspect() {
  var card = document.querySelector('#empty-home .daily-review-card');
  var rect = card && card.getBoundingClientRect();
  return rect && rect.width > 0 && rect.height > 0 ? rect.width / rect.height : 0.72;
}

function homeWallpaperCropValues() {
  return {
    scale: Math.max(1, Number(document.getElementById('home-wallpaper-crop-scale') && document.getElementById('home-wallpaper-crop-scale').value || 100) / 100),
    x: Number(document.getElementById('home-wallpaper-crop-x') && document.getElementById('home-wallpaper-crop-x').value || 50),
    y: Number(document.getElementById('home-wallpaper-crop-y') && document.getElementById('home-wallpaper-crop-y').value || 50),
  };
}

function updateHomeWallpaperCropPreview() {
  var media = document.querySelector('#home-wallpaper-crop-frame .home-wallpaper-crop-media');
  if (!media) return;
  var values = homeWallpaperCropValues();
  media.style.objectPosition = values.x + '% ' + values.y + '%';
  media.style.transformOrigin = values.x + '% ' + values.y + '%';
  media.style.transform = 'scale(' + values.scale + ')';
}

function openHomeWallpaperCropForBlob(blob, name, type, kind) {
  closeHomeWallpaperLibrary();
  if (homeWallpaperCropObjectUrl) URL.revokeObjectURL(homeWallpaperCropObjectUrl);
  homeWallpaperCropObjectUrl = URL.createObjectURL(blob);
  homeWallpaperCropDraft = { blob: blob, name: name, type: type, kind: kind || homeDashboardMediaKind({ name: name, type: type }) };
  var frame = document.getElementById('home-wallpaper-crop-frame');
  var modal = document.getElementById('home-wallpaper-crop-modal');
  var scale = document.getElementById('home-wallpaper-crop-scale');
  var x = document.getElementById('home-wallpaper-crop-x');
  var y = document.getElementById('home-wallpaper-crop-y');
  if (scale) scale.value = '100';
  if (x) x.value = '50';
  if (y) y.value = '50';
  if (frame) {
    frame.style.aspectRatio = String(homeWallpaperCardAspect());
    frame.innerHTML = homeWallpaperCropDraft.kind === 'image'
      ? '<img class="home-wallpaper-crop-media" alt="裁剪预览">'
      : '<video class="home-wallpaper-crop-media" muted loop autoplay playsinline></video>';
    var media = frame.firstElementChild;
    media.src = homeWallpaperCropObjectUrl;
    media.addEventListener('error', function () {
      homeDashboardNotify(homeWallpaperCropDraft && homeWallpaperCropDraft.kind === 'image' ? '图片无法读取，请换一张图片或重新导入' : '视频无法读取，请换一个文件或重新导入');
    }, { once: true });
    if (typeof media.play === 'function') media.play().catch(function () {});
  }
  [scale, x, y].forEach(function (input) {
    if (input && !input._homeCropBound) { input._homeCropBound = true; input.addEventListener('input', updateHomeWallpaperCropPreview); }
  });
  if (modal) { modal.setAttribute('aria-hidden', 'false'); openGsapModal(modal); }
  updateHomeWallpaperCropPreview();
}

function openHomeWallpaperCropForSource(sourceUrl, name, type, kind, project) {
  closeHomeWallpaperLibrary();
  if (homeWallpaperCropObjectUrl) {
    URL.revokeObjectURL(homeWallpaperCropObjectUrl);
    homeWallpaperCropObjectUrl = '';
  }
  homeWallpaperCropDraft = {
    blob: null,
    sourceUrl: String(sourceUrl || ''),
    name: name,
    type: type,
    kind: kind,
    wallpaperProjectId: String(project && project.id || ''),
    wallpaperProjectUpdatedAt: Number(project && project.updatedAt) || 0,
  };
  var frame = document.getElementById('home-wallpaper-crop-frame');
  var modal = document.getElementById('home-wallpaper-crop-modal');
  var scale = document.getElementById('home-wallpaper-crop-scale');
  var x = document.getElementById('home-wallpaper-crop-x');
  var y = document.getElementById('home-wallpaper-crop-y');
  if (scale) scale.value = '100';
  if (x) x.value = '50';
  if (y) y.value = '50';
  if (frame) {
    frame.style.aspectRatio = String(homeWallpaperCardAspect());
    frame.innerHTML = kind === 'image'
      ? '<img class="home-wallpaper-crop-media" alt="裁剪预览">'
      : '<video class="home-wallpaper-crop-media" muted loop autoplay playsinline preload="metadata"></video>';
    var media = frame.firstElementChild;
    media.src = homeWallpaperCropDraft.sourceUrl;
    media.addEventListener('error', function () {
      homeDashboardNotify(homeWallpaperCropDraft && homeWallpaperCropDraft.kind === 'image' ? '图片无法读取，请尝试导入本地图片' : '视频无法读取，请尝试导入本地视频');
    }, { once: true });
    if (typeof media.play === 'function') media.play().catch(function () {});
  }
  [scale, x, y].forEach(function (input) {
    if (input && !input._homeCropBound) { input._homeCropBound = true; input.addEventListener('input', updateHomeWallpaperCropPreview); }
  });
  if (modal) { modal.setAttribute('aria-hidden', 'false'); openGsapModal(modal); }
  updateHomeWallpaperCropPreview();
}

function closeHomeWallpaperCrop() {
  var modal = document.getElementById('home-wallpaper-crop-modal');
  if (modal) modal.setAttribute('aria-hidden', 'true');
  closeGsapModal(modal);
  if (homeWallpaperCropObjectUrl) { URL.revokeObjectURL(homeWallpaperCropObjectUrl); homeWallpaperCropObjectUrl = ''; }
  homeWallpaperCropDraft = null;
}

function homeWallpaperLoadImageForCrop(source) {
  return new Promise(function (resolve, reject) {
    var isBlob = typeof Blob !== 'undefined' && source instanceof Blob;
    var url = isBlob ? URL.createObjectURL(source) : String(source || '');
    var image = new Image();
    image.decoding = 'async';
    image.onload = function () { resolve({ image: image, url: url, revoke: isBlob }); };
    image.onerror = function () {
      if (isBlob) URL.revokeObjectURL(url);
      reject(new Error('IMAGE_DECODE_FAILED'));
    };
    image.src = url;
  });
}

async function homeWallpaperCropImageBlob(draft, values, aspect) {
  if (!draft || (!draft.blob && !draft.sourceUrl)) throw new Error('IMAGE_SOURCE_MISSING');
  var source = null;
  var sourceUrl = '';
  var revokeSourceUrl = false;
  var closeSource = function () {};
  if (draft.blob && typeof createImageBitmap === 'function') {
    try {
      source = await createImageBitmap(draft.blob, { imageOrientation: 'from-image' });
      closeSource = function () { if (source && typeof source.close === 'function') source.close(); };
    } catch (_bitmapError) { }
  }
  if (!source) {
    var loaded = await homeWallpaperLoadImageForCrop(draft.blob || draft.sourceUrl);
    source = loaded.image;
    sourceUrl = loaded.url;
    revokeSourceUrl = !!loaded.revoke;
    closeSource = function () { if (sourceUrl && revokeSourceUrl) URL.revokeObjectURL(sourceUrl); };
  }
  var sourceWidth = Number(source.naturalWidth || source.width) || 0;
  var sourceHeight = Number(source.naturalHeight || source.height) || 0;
  if (!sourceWidth || !sourceHeight) {
    closeSource();
    throw new Error('IMAGE_SIZE_INVALID');
  }
  var sourceAspect = sourceWidth / sourceHeight;
  var baseWidth = sourceAspect > aspect ? sourceHeight * aspect : sourceWidth;
  var baseHeight = sourceAspect > aspect ? sourceHeight : sourceWidth / aspect;
  var cropWidth = baseWidth / values.scale;
  var cropHeight = baseHeight / values.scale;
  var sx = (sourceWidth - cropWidth) * (values.x / 100);
  var sy = (sourceHeight - cropHeight) * (values.y / 100);
  var outWidth = 1080;
  var outHeight = Math.max(1, Math.round(outWidth / aspect));
  var canvas = document.createElement('canvas');
  canvas.width = outWidth;
  canvas.height = outHeight;
  var context = canvas.getContext('2d', { alpha: false });
  if (!context) {
    closeSource();
    throw new Error('CANVAS_CONTEXT_UNAVAILABLE');
  }
  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = 'high';
  context.drawImage(source, sx, sy, cropWidth, cropHeight, 0, 0, outWidth, outHeight);
  closeSource();
  return new Promise(function (resolve, reject) {
    canvas.toBlob(function (result) { if (result) resolve(result); else reject(new Error('IMAGE_CROP_FAILED')); }, 'image/webp', .92);
  });
}

async function confirmHomeWallpaperCrop() {
  var draft = homeWallpaperCropDraft;
  if (!draft) return;
  var button = document.getElementById('home-wallpaper-crop-confirm');
  if (button) { button.disabled = true; button.textContent = '正在导入…'; }
  try {
    var values = homeWallpaperCropValues();
    var aspect = homeWallpaperCardAspect();
    var isWallpaperReference = draft.kind === 'video' && !!draft.wallpaperProjectId;
    var storedBlob = isWallpaperReference ? null : (draft.kind === 'image' ? await homeWallpaperCropImageBlob(draft, values, aspect) : draft.blob);
    var meta = {
      version: isWallpaperReference ? 3 : 2, kind: draft.kind, name: draft.name, type: draft.kind === 'image' ? 'image/webp' : draft.type,
      size: storedBlob ? (Number(storedBlob.size) || 0) : 0, savedAt: Date.now(), cardAspect: aspect,
      cropScale: draft.kind === 'image' ? 1 : values.scale, cropX: draft.kind === 'image' ? 50 : values.x, cropY: draft.kind === 'image' ? 50 : values.y,
    };
    if (isWallpaperReference) {
      meta.wallpaperProjectId = draft.wallpaperProjectId;
      meta.wallpaperProjectUpdatedAt = draft.wallpaperProjectUpdatedAt;
      await homeDashboardDeleteVideoBlob();
    } else {
      await homeDashboardPutVideoBlob(storedBlob, meta);
    }
    localStorage.setItem(HOME_DASHBOARD_VIDEO_META_KEY, JSON.stringify(meta));
    homeDashboardVideoDecodeFailed = false;
    homeDashboardReleaseVideoSource(true);
    homeDashboardRenderVideoActions();
    homeDashboardUpdateVideoPower();
    closeHomeWallpaperCrop();
    homeDashboardNotify('已按首页卡片比例裁剪并导入');
  } catch (error) {
    console.warn('[HomeDashboardMediaSave]', error);
    homeDashboardNotify('首页卡片素材导入失败');
  } finally {
    if (button) { button.disabled = false; button.textContent = '确认裁剪并导入'; }
  }
}

function renderHomeWallpaperProjects() {
  var grid = document.getElementById('home-wallpaper-project-grid');
  var status = document.getElementById('home-wallpaper-library-status');
  if (!grid) return;
  var search = String(document.getElementById('home-wallpaper-search') && document.getElementById('home-wallpaper-search').value || '').trim().toLowerCase();
  homeWallpaperProjectItems = (typeof wallpaperEngineProjects !== 'undefined' && Array.isArray(wallpaperEngineProjects) ? wallpaperEngineProjects : []).filter(function (item) {
    if (!item || !item.hasPreview) return false;
    if (typeof hiddenWallpaperEngineIds !== 'undefined' && hiddenWallpaperEngineIds.has(item.id)) return false;
    return !search || String((item.title || '') + ' ' + (item.projectType || '') + ' ' + (item.sourceLabel || '')).toLowerCase().indexOf(search) >= 0;
  }).sort(function (a, b) {
    var af = typeof favoriteWallpaperEngineIds !== 'undefined' && favoriteWallpaperEngineIds.has(a.id) ? 1 : 0;
    var bf = typeof favoriteWallpaperEngineIds !== 'undefined' && favoriteWallpaperEngineIds.has(b.id) ? 1 : 0;
    return bf - af || String(a.title || '').localeCompare(String(b.title || ''), 'zh-CN');
  }).slice(0, 80);
  if (status) status.textContent = homeWallpaperProjectItems.length ? ('识别到 ' + homeWallpaperProjectItems.length + ' 个可取景项目；Scene 项目导入静态预览，Video 项目导入动态画面。') : '没有识别到 Wallpaper Engine 项目，也可以直接导入本地视频或图片。';
  grid.innerHTML = homeWallpaperProjectItems.length ? homeWallpaperProjectItems.map(function (item, index) {
    var preview = typeof wallpaperEngineMediaUrl === 'function' ? wallpaperEngineMediaUrl(item, 'preview') : '';
    var favorite = typeof favoriteWallpaperEngineIds !== 'undefined' && favoriteWallpaperEngineIds.has(item.id);
    return '<article class="home-wallpaper-project' + (favorite ? ' favorite' : '') + '" tabindex="0" role="button" onclick="selectHomeWallpaperProject(' + index + ')" onkeydown="if(event.key===\'Enter\')selectHomeWallpaperProject(' + index + ')">' +
      '<img src="' + escHtml(preview) + '" alt="" loading="lazy">' +
      '<button class="home-wallpaper-project-star' + (favorite ? ' active' : '') + '" type="button" title="星标并置顶" onclick="event.stopPropagation();homeToggleFavoriteWallpaperItem(' + index + ')">' + (favorite ? '★' : '☆') + '</button>' +
      '<button class="home-wallpaper-project-hide" type="button" title="从列表隐藏" onclick="event.stopPropagation();homeHideWallpaperItem(' + index + ')">×</button>' +
      '<span><b>' + escHtml(item.title || 'Wallpaper') + '</b><small>' + escHtml(item.projectType || 'Wallpaper Engine') + ' · 点击后裁剪</small></span></article>';
  }).join('') : '<div class="home-wallpaper-project-empty">请选择“导入视频 / 图片”，或先在本机安装 Wallpaper Engine 项目。</div>';
}

async function homeChooseWallpaperEngineProjectFile() {
  if (typeof chooseWallpaperEngineProjectFile === 'function') await chooseWallpaperEngineProjectFile();
  await refreshHomeWallpaperProjects(false);
}
async function homeChooseWallpaperEngineDirectory() {
  if (typeof chooseWallpaperEngineDirectory === 'function') await chooseWallpaperEngineDirectory();
  await refreshHomeWallpaperProjects(false);
}
function homeToggleFavoriteWallpaperItem(index) {
  var item = homeWallpaperProjectItems[Number(index)];
  if (item && typeof toggleFavoriteWallpaperEngineItem === 'function') toggleFavoriteWallpaperEngineItem(item.id);
  renderHomeWallpaperProjects();
}
function homeHideWallpaperItem(index) {
  var item = homeWallpaperProjectItems[Number(index)];
  if (item && typeof hideWallpaperEngineItem === 'function') hideWallpaperEngineItem(item.id);
  renderHomeWallpaperProjects();
}
function homeRestoreHiddenWallpaperItems() {
  if (typeof restoreHiddenWallpaperEngineItems === 'function') restoreHiddenWallpaperEngineItems();
  renderHomeWallpaperProjects();
}

async function refreshHomeWallpaperProjects(force) {
  var status = document.getElementById('home-wallpaper-library-status');
  if (status) status.textContent = '正在识别本机 Wallpaper Engine 项目…';
  try {
    if (typeof loadWallpaperEngineLibrary === 'function') await loadWallpaperEngineLibrary(!!force, false);
  } catch (_) {}
  renderHomeWallpaperProjects();
}

async function openHomeWallpaperLibrary() {
  var modal = document.getElementById('home-wallpaper-library-modal');
  if (modal) { modal.setAttribute('aria-hidden', 'false'); openGsapModal(modal); }
  await refreshHomeWallpaperProjects(false);
}

function closeHomeWallpaperLibrary() {
  var modal = document.getElementById('home-wallpaper-library-modal');
  if (modal) modal.setAttribute('aria-hidden', 'true');
  closeGsapModal(modal);
}

async function selectHomeWallpaperProject(index) {
  var item = homeWallpaperProjectItems[Number(index)];
  if (!item) return;
  var status = document.getElementById('home-wallpaper-library-status');
  if (status) status.textContent = '正在读取“' + (item.title || 'Wallpaper') + '”…';
  try {
    var useAsset = item.playable && String(item.mediaType || item.projectType || '').toLowerCase() === 'video';
    var url = wallpaperEngineMediaUrl(item, useAsset ? 'media' : (item.playable && String(item.mediaType || '').toLowerCase() === 'image' ? 'media' : 'preview'));
    var kind = useAsset ? 'video' : 'image';
    if (kind === 'image' && window.desktopWindow && typeof window.desktopWindow.readWallpaperEngineProjectAsset === 'function') {
      var asset = await window.desktopWindow.readWallpaperEngineProjectAsset(item.id, 'preview');
      if (!asset || asset.ok !== true || !asset.bytes) throw new Error(asset && asset.error || 'WALLPAPER_PREVIEW_READ_FAILED');
      var imageBlob = new Blob([asset.bytes], { type: String(asset.type || 'image/jpeg') });
      openHomeWallpaperCropForBlob(
        imageBlob,
        String(item.title || asset.name || 'Wallpaper') + '.jpg',
        imageBlob.type,
        'image'
      );
      return;
    }
    openHomeWallpaperCropForSource(
      url,
      String(item.title || 'Wallpaper') + (kind === 'video' ? '.mp4' : '.jpg'),
      kind === 'video' ? 'video/mp4' : 'image/jpeg',
      kind,
      item
    );
  } catch (error) {
    if (status) status.textContent = '读取失败，请尝试本地导入该项目的视频或图片。';
  }
}

async function clearHomeDashboardVideo() {
  localStorage.removeItem(HOME_DASHBOARD_VIDEO_META_KEY);
  homeDashboardVideoDecodeFailed = false;
  homeDashboardReleaseVideoSource(true);
  homeDashboardRenderVideoActions();
  try {
    await homeDashboardDeleteVideoBlob();
  } catch (error) {
    console.warn('[HomeDashboardVideoDelete]', error);
  }
  homeDashboardNotify('已恢复主页默认动画');
}

function bindHomeDashboardVideoControls() {
  if (homeDashboardVideoControlsBound) return;
  homeDashboardVideoControlsBound = true;
  var input = document.getElementById('home-dashboard-video-input');
  if (input) {
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      input.value = '';
      if (file) handleHomeDashboardVideoFile(file);
    });
  }
  if (window.MutationObserver && document.body) {
    homeDashboardVideoPowerObserver = new MutationObserver(function () {
      homeDashboardUpdateVideoPower();
    });
    homeDashboardVideoPowerObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }
  window.addEventListener('pagehide', function () { homeDashboardReleaseVideoSource(true); });
}

function renderHomeDashboardHero() {
  var hero = document.querySelector('#empty-home .home-hero');
  if (!hero) return;
  var review = homeDashboardSelectedReview();
  var fingerprint = homeDashboardDayNumber() + '|' + homeDashboardReviewOffset + '|' + review.text + '|' + review.source;
  if (!hero.querySelector('.daily-review-card')) {
    hero.innerHTML = '<div class="daily-review-card">' +
      '<div id="daily-review-date" class="daily-review-date"></div>' +
      '<div id="daily-review-time" class="daily-review-time">--:--</div>' +
      '<div class="daily-review-actions">' +
      '<button id="home-dashboard-video-choose" type="button" onclick="openHomeWallpaperLibrary()">Wallpaper</button>' +
      '<button id="home-dashboard-video-clear" type="button" onclick="clearHomeDashboardVideo()" hidden>移除壁纸</button>' +
      '<button type="button" onclick="openHomePlayerConsole()">展开播放器控制台</button>' +
      '</div></div>' +
      '<input id="home-dashboard-video-input" type="file" accept="image/*,video/*,.mp4,.webm,.mov,.mkv" hidden aria-hidden="true">';
    homeDashboardVideoControlsBound = false;
    bindHomeDashboardVideoControls();
  }
  if (fingerprint !== homeDashboardHeroFingerprint) homeDashboardHeroFingerprint = fingerprint;
  homeDashboardRenderVideoActions();
  homeDashboardUpdateVideoPower();
  homeDashboardUpdateClock();
}

function homeDashboardNextReview() {
  homeDashboardReviewOffset += 1;
  renderHomeDashboardHero();
}

function homeDashboardCurrentSong() {
  try {
    return typeof currentCoverSong === 'function' ? currentCoverSong() : null;
  } catch (_error) {
    return null;
  }
}

function homeDashboardSubtitle(song) {
  if (!song) return '';
  try {
    return song.artist || song.singer || song.album || songSourceLabel(song) || '';
  } catch (_error) {
    return song.artist || song.singer || song.source || '';
  }
}

function homeDashboardSongCover(song, size) {
  if (!song) return '';
  try {
    return songCoverSrc(song, size || 320) || song.cover || song.picUrl || '';
  } catch (_error) {
    return song.cover || song.picUrl || '';
  }
}

function homeDashboardLocalSongs() {
  var pool = [];
  if (Array.isArray(playQueue)) pool = pool.concat(playQueue);
  if (Array.isArray(playlist)) pool = pool.concat(playlist);
  if (Array.isArray(userPlaylists)) {
    userPlaylists.forEach(function (item) {
      if (item && Array.isArray(item.songs)) pool = pool.concat(item.songs);
    });
  }
  var seen = Object.create(null);
  return pool.filter(function (song) {
    if (!song || song.type !== 'local') return false;
    var key = '';
    try { key = queueItemKey(song); } catch (_error) { }
    key = key || song.localPath || song.id || ((song.name || song.title || '') + '|' + (song.artist || ''));
    if (!key || seen[key]) return false;
    seen[key] = true;
    return true;
  });
}

function homeDashboardSetStableBackgroundImage(element, src) {
  if (!element) return;
  src = String(src || '');
  if (element.__homeDashboardRequestedBackground === src) return;
  element.__homeDashboardRequestedBackground = src;
  if (!src) {
    element.__homeDashboardBackground = '';
    element.style.backgroundImage = '';
    return;
  }
  var image = new Image();
  image.decoding = 'async';
  function commit() {
    if (!element.isConnected || element.__homeDashboardRequestedBackground !== src) return;
    element.__homeDashboardBackground = src;
    element.style.backgroundImage = 'url("' + cssImageUrl(src) + '")';
  }
  image.onload = function () {
    if (typeof image.decode === 'function') image.decode().catch(function () { }).then(commit);
    else commit();
  };
  image.onerror = function () { };
  image.src = src;
}

function homeDashboardCardHtml(card) {
  var cover = card.cover || homeDashboardGeneratedCover(card.title, card.label, card.tone);
  var artStyle = cover ? ' style="background-image:url(&quot;' + escHtml(cssImageUrl(cover)) + '&quot;)"' : '';
  return '<button class="home-card ' + escHtml(card.className || '') + '" data-home-tone="' + escHtml(card.tone || 'playlist') + '"' +
    ' type="button" onclick="' + card.action + '">' +
    '<div class="home-card-label">' + escHtml(card.label || '') + '</div>' +
    '<div class="home-card-title">' + escHtml(card.title || '') + '</div>' +
    '<div class="home-card-sub">' + escHtml(card.sub || '') + '</div>' +
    '<div class="home-card-art has-cover"' + artStyle + '></div>' +
    '</button>';
}

function homeDashboardPatchCard(button, card) {
  if (!button || !card) return;
  var className = 'home-card' + (card.className ? ' ' + card.className : '');
  var displayCover = card.cover || homeDashboardGeneratedCover(card.title, card.label, card.tone);
  if (button.className !== className) button.className = className;
  if (button.getAttribute('data-home-tone') !== card.tone) button.setAttribute('data-home-tone', card.tone);
  if (button.getAttribute('onclick') !== card.action) button.setAttribute('onclick', card.action);
  var label = button.querySelector('.home-card-label');
  var title = button.querySelector('.home-card-title');
  var sub = button.querySelector('.home-card-sub');
  var art = button.querySelector('.home-card-art');
  if (label && label.textContent !== card.label) label.textContent = card.label;
  if (title && title.textContent !== card.title) title.textContent = card.title;
  if (sub && sub.textContent !== card.sub) sub.textContent = card.sub;
  if (art) {
    art.className = 'home-card-art' + (displayCover ? ' has-cover' : '');
    homeDashboardSetStableBackgroundImage(art, displayCover);
  }
}

function renderHomeDashboardQuickCards() {
  var grid = document.querySelector('#empty-home .home-grid');
  if (!grid) return;
  var summary = typeof homeListenSummary === 'function' ? homeListenSummary() : {};
  var recent = summary && summary.recent || null;
  var current = homeDashboardCurrentSong();
  var daily = homeDiscoverState && homeDiscoverState.songs && homeDiscoverState.songs[0] || null;
  var continueItem = current || recent;
  var localSongs = homeDashboardLocalSongs();
  var localCount = localSongs.length;
  var accountPlaylistCount = homeDiscoverState && Array.isArray(homeDiscoverState.playlists) ? homeDiscoverState.playlists.length : 0;
  var ownPlaylistCount = Array.isArray(userPlaylists) ? userPlaylists.length : 0;
  var libraryCount = localCount + accountPlaylistCount + ownPlaylistCount;
  var cards = [
    {
      label: 'CONTINUE',
      title: continueItem && (continueItem.name || continueItem.title) || '开始听歌',
      sub: continueItem ? (homeDashboardSubtitle(continueItem) || recent && (recent.artist || recent.source) || '继续当前队列') : '从音乐库或每日推荐开始',
      cover: homeDashboardSongCover(current, 360) || recent && recent.cover || '',
      action: 'resumeHomeDashboardPlayback()',
      tone: 'search',
      className: 'home-card-featured',
    },
    {
      label: 'LIBRARY',
      title: '音乐库',
      sub: libraryCount ? (libraryCount + ' 项内容 · 本地音乐与歌单') : 'MusicFree 音源与本地音乐',
      cover: localSongs[0] ? homeDashboardSongCover(localSongs[0], 260) : '',
      action: 'openHomeDashboardLibrary()',
      tone: 'library',
      className: 'home-card-quick',
    },
    {
      label: 'DAILY MIX',
      title: '每日推荐',
      sub: daily ? ((daily.name || daily.title || '今日歌曲') + (homeDashboardSubtitle(daily) ? ' · ' + homeDashboardSubtitle(daily) : '')) : '使用当前 Mineradio 推荐数据',
      cover: homeDashboardSongCover(daily, 260),
      action: 'openHomeDailyRecommendations()',
      tone: 'mix',
      className: 'home-card-quick',
    },
    {
      label: 'RECENT',
      title: '最近播放',
      sub: recent ? ((recent.name || '最近一首') + (recent.artist ? ' · ' + recent.artist : '')) : '播放过的歌曲会出现在这里',
      cover: recent && recent.cover || '',
      action: 'openHomeRecentHistory()',
      tone: 'playlist',
      className: 'home-card-quick',
    },
  ];
  var fingerprint = cards.map(function (card) {
    return [card.title, card.sub, card.cover, card.action].join('|');
  }).join('||');
  if (fingerprint === homeDashboardQuickFingerprint && grid.classList.contains('home-quick-grid')) return;
  homeDashboardQuickFingerprint = fingerprint;
  grid.classList.add('home-quick-grid');
  var existingCards = Array.prototype.slice.call(grid.children).filter(function (node) {
    return node && node.classList && node.classList.contains('home-card');
  });
  if (existingCards.length !== cards.length) {
    grid.innerHTML = cards.map(homeDashboardCardHtml).join('');
    existingCards = Array.prototype.slice.call(grid.querySelectorAll('.home-card'));
  }
  cards.forEach(function (card, index) {
    homeDashboardPatchCard(existingCards[index], card);
  });
}

function resumeHomeDashboardPlayback() {
  homeForcedOpen = false;
  homeSuppressed = false;
  if (typeof setHomeControlsLocked === 'function') setHomeControlsLocked(false);
  if (playQueue && playQueue.length && currentIdx >= 0 && playQueue[currentIdx]) {
    if (typeof forcePlaybackControlsInteractive === 'function') forcePlaybackControlsInteractive();
    if (typeof updateEmptyHomeVisibility === 'function') updateEmptyHomeVisibility();
    if (playing || audio && !audio.paused) return;
    if (typeof togglePlay === 'function') {
      Promise.resolve(togglePlay()).catch(function (error) { console.warn('[HomeDashboardResume]', error); });
    }
    return;
  }
  var recent = typeof homeListenSummary === 'function' ? homeListenSummary().recent : null;
  if (recent && typeof playHomeRecent === 'function') {
    Promise.resolve(playHomeRecent(recent)).catch(function (error) { console.warn('[HomeDashboardRecent]', error); });
    return;
  }
  if (typeof playHomeDaily === 'function') playHomeDaily();
}

function homeDashboardDayKey(timestamp) {
  var date = new Date(Number(timestamp) || Date.now());
  return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0');
}

function homeDashboardTodayListenMetrics() {
  var now = Date.now();
  var today = new Date(now);
  today.setHours(0, 0, 0, 0);
  var todayStart = today.getTime();
  var history = listenStatsState && Array.isArray(listenStatsState.history) ? listenStatsState.history : [];
  var records = history.filter(function (record) {
    return record && Number(record.playedAt) >= todayStart;
  });
  var keys = Object.create(null);
  var artists = Object.create(null);
  var listenMs = 0;
  records.forEach(function (record) {
    var key = String(record.key || record.id || (record.name || '') + '|' + (record.artist || ''));
    if (key) keys[key] = true;
    listenMs += Math.max(0, Number(record.listenMs) || 0);
    String(record.artist || '').split(/\s*\/\s*|\s*,\s*|、|&/).forEach(function (name) {
      name = name.trim();
      if (!name) return;
      artists[name] = (artists[name] || 0) + Math.max(1, Number(record.listenMs) || 1);
    });
  });
  if (listenSession && Number(listenSession.startedAt) >= todayStart) {
    listenMs += Math.max(0, Number(listenSession.listenMs) || 0);
    if (listenSession.key) keys[listenSession.key] = true;
  }
  var topArtist = Object.keys(artists).sort(function (a, b) { return artists[b] - artists[a]; })[0] || '';
  var dayMap = Object.create(null);
  history.forEach(function (record) {
    if (record && record.playedAt) dayMap[homeDashboardDayKey(record.playedAt)] = true;
  });
  if (records.length || listenSession) dayMap[homeDashboardDayKey(now)] = true;
  var streak = 0;
  var cursor = new Date(todayStart);
  if (!dayMap[homeDashboardDayKey(cursor.getTime())]) cursor.setDate(cursor.getDate() - 1);
  while (dayMap[homeDashboardDayKey(cursor.getTime())]) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return {
    listenMs: listenMs,
    songCount: Object.keys(keys).length,
    topArtist: topArtist,
    streak: streak,
  };
}

function homeDashboardListenDurationText(milliseconds) {
  var minutes = Math.floor(Math.max(0, Number(milliseconds) || 0) / 60000);
  if (minutes < 60) return minutes + ' 分钟';
  var hours = Math.floor(minutes / 60);
  var rest = minutes % 60;
  return hours + ' 小时' + (rest ? rest + ' 分' : '');
}

function homeDashboardNextQueueInfo() {
  if (playQueue && playQueue.length) {
    var index = currentIdx >= 0 ? (currentIdx + 1) % playQueue.length : 0;
    return { song: playQueue[index], index: index, queued: true };
  }
  var discoverSong = homeDiscoverState && homeDiscoverState.songs && homeDiscoverState.songs[0] || null;
  var localSong = homeDashboardLocalSongs()[0] || null;
  return { song: discoverSong || localSong || null, index: 0, queued: false };
}

function homeDashboardSongKey(song) {
  if (!song) return '';
  try {
    var queueKey = typeof queueItemKey === 'function' ? queueItemKey(song) : '';
    if (queueKey) return String(queueKey);
  } catch (_error) { }
  var provider = song.provider || song.source || song.type || '';
  var id = song.id || song.mid || song.songmid || song.mediaMid || song.localPath || song.url || '';
  if (id) return provider + '|' + id;
  return provider + '|' + (song.name || song.title || '') + '|' + homeDashboardSubtitle(song);
}

function homeDashboardDiscoverySongs() {
  var candidates = [];
  var seen = Object.create(null);
  function addSongs(songs) {
    (Array.isArray(songs) ? songs : []).forEach(function (song) {
      if (!song) return;
      var key = homeDashboardSongKey(song);
      if (!key || seen[key]) return;
      seen[key] = true;
      candidates.push(song);
    });
  }

  addSongs(homeDiscoverState && homeDiscoverState.songs);
  addSongs(playQueue);
  if (Array.isArray(userPlaylists)) {
    userPlaylists.forEach(function (item) { addSongs(item && item.songs); });
  }
  addSongs(playlist);
  addSongs(homeDashboardLocalSongs());

  if (candidates.length <= 3) return candidates.slice();
  var day = homeDashboardDayNumber();
  var step = Math.max(1, Math.floor(candidates.length / 3));
  var picked = [];
  var pickedKeys = Object.create(null);
  for (var index = 0; index < candidates.length && picked.length < 3; index += 1) {
    var candidate = candidates[(day * 17 + index * step + index * 7) % candidates.length];
    var candidateKey = homeDashboardSongKey(candidate);
    if (!candidateKey || pickedKeys[candidateKey]) continue;
    pickedKeys[candidateKey] = true;
    picked.push(candidate);
  }
  return picked;
}

function renderHomeDashboardDiscovery() {
  var root = document.getElementById('home-discovery-list');
  if (!root) return;
  homeDashboardDiscoveryCache = homeDashboardDiscoverySongs();
  var fingerprint = homeDashboardDiscoveryCache.map(function (song) {
    return [homeDashboardSongKey(song), song.name || song.title || '', homeDashboardSubtitle(song), homeDashboardSongCover(song, 180)].join('|');
  }).join('||');
  if (!fingerprint) fingerprint = 'empty';
  if (fingerprint === homeDashboardDiscoveryFingerprint) return;
  homeDashboardDiscoveryFingerprint = fingerprint;
  root.classList.toggle('is-empty', !homeDashboardDiscoveryCache.length);
  if (!homeDashboardDiscoveryCache.length) {
    root.innerHTML = '<button class="home-discovery-empty" type="button" onclick="openHomeDashboardLibrary()">' +
      '<strong>等待你的音乐</strong><span>搜索 MusicFree 音源或导入本地音乐后生成推荐</span></button>';
    return;
  }
  root.innerHTML = homeDashboardDiscoveryCache.map(function (song, index) {
    var cover = homeDashboardSongCover(song, 180);
    var coverStyle = cover ? ' style="background-image:url(&quot;' + escHtml(cssImageUrl(cover)) + '&quot;)"' : '';
    return '<button class="home-discovery-song" type="button" onclick="playHomeDashboardDiscoverySong(' + index + ')">' +
      '<span class="home-discovery-cover"' + coverStyle + '></span>' +
      '<span class="home-discovery-song-copy"><span class="home-discovery-song-name">' + escHtml(song.name || song.title || '未知歌曲') + '</span>' +
      '<span class="home-discovery-song-artist">' + escHtml(homeDashboardSubtitle(song) || 'Mineradio 推荐') + '</span></span></button>';
  }).join('');
}

function playHomeDashboardDiscoverySong(index) {
  if (!homeDashboardDiscoveryCache.length) homeDashboardDiscoveryCache = homeDashboardDiscoverySongs();
  if (!homeDashboardDiscoveryCache.length) {
    openHomeDashboardLibrary();
    return;
  }
  playQueue = homeDashboardDiscoveryCache.map(function (song) { return cloneSong(song); });
  currentIdx = Math.max(0, Math.min(playQueue.length - 1, Number(index) || 0));
  homeForcedOpen = false;
  homeSuppressed = false;
  if (typeof setHomeControlsLocked === 'function') setHomeControlsLocked(false);
  if (typeof safeRenderQueuePanel === 'function') safeRenderQueuePanel('home-dashboard-discovery', { scrollCurrent: true });
  if (typeof safeShelfRebuild === 'function') safeShelfRebuild('home-dashboard-discovery', true);
  if (typeof forcePlaybackControlsInteractive === 'function') forcePlaybackControlsInteractive();
  Promise.resolve(playQueueAt(currentIdx, {
    manual: true,
    context: { type: 'home-discovery', playlistName: '为你挑选' },
  })).catch(function (error) { console.warn('[HomeDashboardDiscovery]', error); });
}

function renderHomeInsightDock() {
  if (!document.getElementById('home-insight-dock')) return;
  var metrics = homeDashboardTodayListenMetrics();
  var time = document.getElementById('home-today-time');
  var count = document.getElementById('home-today-count');
  var artist = document.getElementById('home-today-artist');
  var streak = document.getElementById('home-today-streak');
  if (time) time.textContent = homeDashboardListenDurationText(metrics.listenMs);
  if (count) count.textContent = metrics.songCount + ' 首';
  if (artist) artist.textContent = metrics.topArtist || '等待记录';
  if (streak) streak.textContent = metrics.streak ? ('连续聆听 ' + metrics.streak + ' 天') : '开始播放后生成';

  var next = homeDashboardNextQueueInfo();
  var song = next.song;
  var title = document.getElementById('home-next-title');
  var sub = document.getElementById('home-next-sub');
  var cover = document.getElementById('home-next-cover');
  var card = document.getElementById('home-next-card');
  if (title) title.textContent = song ? (song.name || song.title || '未知歌曲') : '队列里还没有歌曲';
  if (sub) sub.textContent = song ? (homeDashboardSubtitle(song) || '点击播放') : '点击打开音乐库';
  var coverUrl = homeDashboardSongCover(song, 220);
  if (cover) homeDashboardSetStableBackgroundImage(cover, coverUrl);
  if (card) card.setAttribute('aria-label', song ? ('播放下一首：' + (song.name || song.title || '未知歌曲')) : '打开音乐库');
  renderHomeDashboardDiscovery();
}

function playHomeNextFromDock() {
  var next = homeDashboardNextQueueInfo();
  if (next.song && next.queued) {
    homeForcedOpen = false;
    homeSuppressed = false;
    if (typeof setHomeControlsLocked === 'function') setHomeControlsLocked(false);
    if (typeof forcePlaybackControlsInteractive === 'function') forcePlaybackControlsInteractive();
    Promise.resolve(playQueueAt(next.index, {
      manual: true,
      context: { type: 'home-next', playlistName: '接下来播放' },
    })).catch(function (error) { console.warn('[HomeDashboardNext]', error); });
    return;
  }
  if (next.song) {
    playQueue = [cloneSong(next.song)];
    currentIdx = 0;
    if (typeof safeRenderQueuePanel === 'function') safeRenderQueuePanel('home-dashboard-next');
    if (typeof safeShelfRebuild === 'function') safeShelfRebuild('home-dashboard-next', true);
    if (typeof forcePlaybackControlsInteractive === 'function') forcePlaybackControlsInteractive();
    Promise.resolve(playQueueAt(0, {
      manual: true,
      context: { type: 'home-next', playlistName: '首页推荐' },
    })).catch(function (error) { console.warn('[HomeDashboardStart]', error); });
    return;
  }
  openHomeDashboardLibrary();
}

function openHomeDashboardLibrary() {
  homeForcedOpen = false;
  homeSuppressed = false;
  if (typeof setHomeControlsLocked === 'function') setHomeControlsLocked(false);
  if (typeof updateEmptyHomeVisibility === 'function') updateEmptyHomeVisibility();
  if (typeof closePlaylistPanel === 'function') closePlaylistPanel();
  if (typeof openMusicLibrary === 'function') openMusicLibrary();
}

async function openHomeDailyRecommendations() {
  showLoading();
  try {
    var queries = ['今日热歌', '热门歌曲', '新歌'];
    var responses = await Promise.all(queries.map(function (query) {
      return apiJson('/api/musicfree/search?keywords=' + encodeURIComponent(query) + '&limit=100&offset=0', { timeoutMs: 26000 }).catch(function () { return { songs: [] }; });
    }));
    var seen = Object.create(null);
    var tracks = [];
    responses.forEach(function (response) {
      (response && Array.isArray(response.songs) ? response.songs : []).forEach(function (song) {
        var key = homeMusicFreeMatchText((song.name || song.title || '') + '|' + (song.artist || ''));
        if (!key || seen[key] || tracks.length >= 60) return;
        seen[key] = true;
        tracks.push(song);
      });
    });
    if (!tracks.length) throw new Error('当前音源没有返回每日热门歌曲');
    openUnifiedPlaylistDetail({
      playlist: { id: 'musicfree-daily-' + homeDashboardDayKey(Date.now()), name: '每日推荐', provider: 'musicfree', cover: tracks[0] && tracks[0].cover || '' },
      tracks: tracks,
      kind: 'musicfree'
    });
  } catch (error) {
    homeDashboardNotify(error && error.message || '每日推荐加载失败');
  } finally { hideLoading(); }
}

function openHomeRecentHistory() {
  var history = listenStatsState && Array.isArray(listenStatsState.history) ? listenStatsState.history : [];
  var tracks = history.map(function (record) {
    var song = typeof songFromListenRecord === 'function' ? songFromListenRecord(record) : null;
    if (!song) return null;
    song.cover = record.cover || song.cover || '';
    song.duration = record.listenMs || 0;
    song.playedAt = record.playedAt || 0;
    return song;
  }).filter(Boolean);
  if (!tracks.length) { homeDashboardNotify('还没有播放记录'); return; }
  openUnifiedPlaylistDetail({
    playlist: { id: 'recent-history', name: '最近播放', provider: 'musicfree', cover: tracks[0] && tracks[0].cover || '' },
    tracks: tracks,
    kind: 'history'
  });
}

function openHomeDashboardCharts() {
  openHomePlatformRecommendations('netease', 'songs');
}

function homePlatformRecommendationSourceLabel(source) {
  return {
    netease: '网易云',
    qishui: '汽水',
    qq: 'QQ 音乐',
    kugou: '酷狗音乐',
    spotify: 'Spotify',
  }[source] || '当前平台';
}

function homePlatformRecommendationFeedConfig(source) {
  return {
    qq: {
      endpoint: '/api/qq/recommendations?limit=12',
      sectionTitle: 'QQ 音乐热歌榜',
      cardLabel: 'QQ 音乐公开热歌榜',
      readyText: '来自 QQ 音乐公开榜单接口',
      playlistName: 'QQ 音乐热歌榜',
    },
    qishui: {
      endpoint: '/api/qishui/feed?limit=12',
      sectionTitle: '推荐 Feed',
      cardLabel: '汽水推荐 Feed',
      readyText: '来自汽水推荐 Feed',
      playlistName: '汽水推荐 Feed',
    },
    kugou: {
      endpoint: '/api/kugou/recommendations?limit=12',
      sectionTitle: '推荐 FM',
      cardLabel: '酷狗推荐 FM',
      readyText: '来自酷狗 FM 推荐',
      playlistName: '酷狗推荐 FM',
    },
    spotify: {
      endpoint: '/api/spotify/recommendations?limit=12',
      sectionTitle: '个性化推荐',
      cardLabel: 'Spotify 推荐',
      readyText: '来自 Spotify 个性化推荐',
      playlistName: 'Spotify 个性化推荐',
    },
  }[source] || null;
}

function homePlatformRecommendationCard(kind, index, item, label) {
  item = item || {};
  var title = item.name || item.title || '未命名内容';
  var sub = '';
  if (kind === 'netease-playlist') sub = (item.trackCount ? item.trackCount + ' 首' : '推荐歌单') + (item.playCount ? ' · ' + compactHomeCount(item.playCount) + ' 播放' : '');
  else sub = homeDashboardSubtitle(item) || label;
  var cover = item.cover || item.picUrl || homeDashboardSongCover(item, 180) || '';
  var coverStyle = cover ? ' style="background-image:url(&quot;' + escHtml(cssImageUrl(cover)) + '&quot;)"' : '';
  return '<button class="home-platform-recommend-card" type="button" data-home-recommend-kind="' + kind + '" data-home-recommend-index="' + index + '">' +
    '<span class="home-platform-recommend-cover"' + coverStyle + '></span>' +
    '<span class="home-platform-recommend-copy"><span class="home-platform-recommend-label">' + escHtml(label) + '</span>' +
    '<strong>' + escHtml(title) + '</strong><small>' + escHtml(sub) + '</small></span>' +
    '<span class="home-platform-recommend-arrow" aria-hidden="true">›</span></button>';
}

function homePlatformRecommendationDailyRange(total, columns, scrollTop, viewportHeight, gridOffsetTop) {
  total = Math.max(0, Number(total) || 0);
  columns = Math.max(1, Number(columns) || 1);
  var totalRows = Math.ceil(total / columns);
  if (!totalRows) return { start: 0, end: 0, topRows: 0, bottomRows: 0 };
  var localScrollTop = Math.max(0, (Number(scrollTop) || 0) - (Number(gridOffsetTop) || 0));
  var firstVisibleRow = Math.floor(localScrollTop / HOME_PLATFORM_DAILY_ROW_HEIGHT);
  var visibleRows = Math.max(1, Math.ceil((Number(viewportHeight) || 500) / HOME_PLATFORM_DAILY_ROW_HEIGHT));
  var maxRows = Math.max(1, Math.floor(HOME_PLATFORM_DAILY_MAX_RENDERED_CARDS / columns));
  var startRow = Math.max(0, firstVisibleRow - HOME_PLATFORM_DAILY_OVERSCAN_ROWS);
  var renderRows = Math.min(maxRows, visibleRows + HOME_PLATFORM_DAILY_OVERSCAN_ROWS * 2);
  var endRow = Math.min(totalRows, startRow + renderRows);
  if (endRow === totalRows) startRow = Math.max(0, endRow - renderRows);
  return {
    start: startRow * columns,
    end: Math.min(total, endRow * columns),
    topRows: startRow,
    bottomRows: Math.max(0, totalRows - endRow),
  };
}

function homePlatformRecommendationGridColumns(grid) {
  if (!grid) return 1;
  try {
    var template = window.getComputedStyle(grid).gridTemplateColumns;
    var columns = String(template || '').trim().split(/\s+/).filter(Boolean).length;
    if (columns > 0) return columns;
  } catch (_error) { }
  return grid.clientWidth > 560 ? 2 : 1;
}

function homePlatformRecommendationSpacer(rows, position) {
  if (!rows) return '';
  var height = Math.max(0, rows * HOME_PLATFORM_DAILY_ROW_HEIGHT - 8);
  return '<span class="home-platform-recommend-spacer" data-home-recommend-spacer="' + position +
    '" aria-hidden="true" style="grid-column:1/-1;height:' + height + 'px"></span>';
}

function renderHomePlatformDailyWindow(force) {
  if (homePlatformRecommendationState.source !== 'netease') return;
  var list = document.getElementById('home-platform-recommend-list');
  var grid = document.getElementById('home-platform-daily-grid');
  if (!list || !grid) return;
  var songs = Array.isArray(homeDiscoverState.songs) ? homeDiscoverState.songs : [];
  var columns = homePlatformRecommendationGridColumns(grid);
  var range = homePlatformRecommendationDailyRange(
    songs.length,
    columns,
    list.scrollTop,
    list.clientHeight,
    grid.offsetTop
  );
  var signature = songs.length + '|' + columns + '|' + range.start + '|' + range.end;
  if (!force && grid.getAttribute('data-render-window') === signature) return;
  var html = [homePlatformRecommendationSpacer(range.topRows, 'top')];
  for (var index = range.start; index < range.end; index += 1) {
    html.push(homePlatformRecommendationCard('netease-song', index, songs[index], '网易云每日推荐'));
  }
  html.push(homePlatformRecommendationSpacer(range.bottomRows, 'bottom'));
  grid.innerHTML = html.join('');
  grid.setAttribute('data-render-window', signature);
  grid.setAttribute('aria-label', '全部每日推荐，共 ' + songs.length + ' 首');
  var count = document.getElementById('home-platform-daily-count');
  if (count) {
    count.textContent = songs.length
      ? ' · ' + (range.start + 1) + '–' + range.end + ' / ' + songs.length
      : '';
  }
}

function scheduleHomePlatformDailyWindowRender() {
  if (homePlatformRecommendationDailyRenderRaf) return;
  var run = function () {
    homePlatformRecommendationDailyRenderRaf = 0;
    renderHomePlatformDailyWindow(false);
  };
  if (typeof requestAnimationFrame === 'function') {
    homePlatformRecommendationDailyRenderRaf = requestAnimationFrame(run);
  } else {
    homePlatformRecommendationDailyRenderRaf = setTimeout(run, 16);
  }
}

function homePlatformRecommendationEmptyHtml(source, message) {
  return '<div class="home-platform-recommend-empty"><strong>' + escHtml(homePlatformRecommendationSourceLabel(source)) + ' 暂无可用推荐</strong>' +
    '<span>' + escHtml(message || '当前版本没有可验证的平台推荐接口，未使用关键词搜索替代。') + '</span></div>';
}

function renderHomePlatformRecommendations() {
  var mask = document.getElementById('home-platform-recommend-mask');
  var list = document.getElementById('home-platform-recommend-list');
  var status = document.getElementById('home-platform-recommend-status');
  if (!mask || !list || !status) return;
  var source = homePlatformRecommendationState.source;
  var tabs = document.querySelectorAll('[data-home-recommend-source]');
  Array.prototype.forEach.call(tabs, function (tab) {
    var selected = tab.getAttribute('data-home-recommend-source') === source;
    tab.setAttribute('aria-selected', selected ? 'true' : 'false');
    tab.classList.toggle('active', selected);
  });
  status.classList.remove('is-error');

  var publicType = homePlatformRecommendationState.contentType === 'playlists' ? 'playlists' : 'songs';
  var publicState = homePlatformRecommendationState.publicFeeds[publicType][source] || { loading: true, loaded: false, items: [], error: '', message: '' };
  var modalTitle = document.getElementById('home-platform-recommend-title');
  var modalDescription = modalTitle && modalTitle.parentElement && modalTitle.parentElement.querySelector('p');
  if (modalTitle) modalTitle.textContent = publicType === 'songs' ? '音乐发现' : '推荐歌单';
  if (modalDescription) modalDescription.textContent = publicType === 'songs'
    ? '歌曲由当前平台公开接口推荐，播放由 MusicFree 音源解析。'
    : '歌单由当前平台公开接口推荐，曲目播放由 MusicFree 音源解析。';
  if (publicState.loading) {
    status.textContent = '正在读取' + homePlatformRecommendationSourceLabel(source) + (publicType === 'songs' ? '推荐歌曲…' : '推荐歌单…');
    list.innerHTML = '<div class="home-platform-recommend-loading">正在同步平台公开内容</div>';
    return;
  }
  if (publicState.items.length) {
    status.textContent = '已读取 ' + publicState.items.length + (publicType === 'songs' ? ' 首歌曲 · 点击后由 MusicFree 播放' : ' 个歌单 · 点击查看歌曲');
    list.innerHTML = '<section><h3>' + (publicType === 'songs' ? '平台推荐歌曲' : '平台推荐歌单') + '</h3><div class="home-platform-recommend-grid">' + publicState.items.map(function (item, index) {
      return homePlatformRecommendationCard(source + '-' + (publicType === 'songs' ? 'public-song' : 'public-playlist'), index, item,
        homePlatformRecommendationSourceLabel(source) + (publicType === 'songs' ? ' 推荐歌曲' : ' 推荐歌单'));
    }).join('') + '</div></section>';
    return;
  }
  status.textContent = homePlatformRecommendationSourceLabel(source) + '公开内容暂不可用';
  status.classList.toggle('is-error', !!publicState.error);
  list.innerHTML = homePlatformRecommendationEmptyHtml(source, publicState.message || '平台公开接口本次没有返回内容，请稍后刷新。');
  return;

  if (source === 'netease') {
    if (homeDiscoverState.loading || homePlatformRecommendationState.neteaseLoading) {
      status.textContent = '正在读取网易云平台推荐…';
      list.innerHTML = '<div class="home-platform-recommend-loading">正在同步推荐内容</div>';
      return;
    }
    var sections = [];
    var playlists = Array.isArray(homeDiscoverState.playlists) ? homeDiscoverState.playlists.slice(0, 6) : [];
    var songs = Array.isArray(homeDiscoverState.songs) ? homeDiscoverState.songs : [];
    if (playlists.length) {
      sections.push('<section><h3>推荐歌单</h3><div class="home-platform-recommend-grid">' + playlists.map(function (item, index) {
        return homePlatformRecommendationCard('netease-playlist', index, item, '网易云推荐歌单');
      }).join('') + '</div></section>');
    }
    if (songs.length) {
      sections.push('<section><h3>每日推荐<span id="home-platform-daily-count"></span></h3>' +
        '<div id="home-platform-daily-grid" class="home-platform-recommend-grid" role="list" aria-label="全部每日推荐"></div></section>');
    }
    if (sections.length) {
      status.textContent = songs.length
        ? '已读取全部 ' + songs.length + ' 首每日推荐；滚动时仅渲染视窗附近歌曲'
        : '来自网易云推荐歌单';
      list.innerHTML = sections.join('');
      if (songs.length) renderHomePlatformDailyWindow(true);
    } else {
      status.textContent = homeDiscoverState.error ? '网易云推荐读取失败' : '网易云暂未返回推荐内容';
      status.classList.toggle('is-error', !!homeDiscoverState.error);
      list.innerHTML = homePlatformRecommendationEmptyHtml('netease', homeDiscoverState.loggedIn
        ? '平台本次没有返回推荐内容，未使用搜索结果补位。'
        : '当前未生成平台推荐，可直接搜索 MusicFree 音源。');
    }
    return;
  }

  var feedConfig = homePlatformRecommendationFeedConfig(source);
  var feedState = homePlatformRecommendationState.feeds[source];
  if (feedConfig && feedState) {
    var sourceLabel = homePlatformRecommendationSourceLabel(source);
    if (feedState.loading) {
      status.textContent = '正在读取' + sourceLabel + '平台推荐…';
      list.innerHTML = '<div class="home-platform-recommend-loading">正在同步推荐内容</div>';
      return;
    }
    if (feedState.songs.length) {
      var sectionTitle = feedConfig.sectionTitle;
      var cardLabel = feedConfig.cardLabel;
      var readyText = feedConfig.readyText;
      if (source === 'qishui' && feedState.fallback) {
        sectionTitle = '你的音乐';
        cardLabel = '汽水喜欢 / 最近播放';
        readyText = '汽水推荐 Feed 暂不可用，当前显示你的喜欢与最近播放';
      } else if (source === 'spotify' && feedState.mode === 'liked-affinity') {
        sectionTitle = '你的喜欢';
        cardLabel = 'Spotify 喜欢的歌曲';
        readyText = '来自 Spotify Web API 的喜欢歌曲';
      } else if (source === 'spotify' && feedState.mode === 'personal-top') {
        sectionTitle = '你的常听';
        cardLabel = 'Spotify 常听歌曲';
        readyText = '来自 Spotify Web API 的个人常听';
      }
      status.textContent = readyText;
      list.innerHTML = '<section><h3>' + escHtml(sectionTitle) + '</h3><div class="home-platform-recommend-grid">' + feedState.songs.map(function (item, index) {
        return homePlatformRecommendationCard(source + '-song', index, item, cardLabel);
      }).join('') + '</div></section>';
    } else {
      var authRequired = /(?:AUTH|LOGIN)_REQUIRED|NOT_CONFIGURED/i.test(feedState.error);
      var feedFailed = !!feedState.error && !authRequired;
      status.textContent = feedFailed ? sourceLabel + '推荐读取失败' : sourceLabel + '暂未返回推荐内容';
      status.classList.toggle('is-error', feedFailed);
      list.innerHTML = homePlatformRecommendationEmptyHtml(source, feedState.message || (feedFailed
        ? '推荐接口当前不可用，未使用关键词搜索补位。'
        : (authRequired
          ? sourceLabel + '原生个性推荐接口需要平台授权；当前版本已移除网络登录，因此不会伪造推荐内容。'
          : sourceLabel + '原生接口本次没有返回推荐内容，未使用关键词搜索替代。')));
    }
    return;
  }

  status.textContent = homePlatformRecommendationSourceLabel(source) + ' 暂无平台推荐接口';
  list.innerHTML = homePlatformRecommendationEmptyHtml(source);
}

async function loadHomePlatformNeteaseRecommendations(force) {
  if (homePlatformRecommendationState.neteaseLoading) return;
  homePlatformRecommendationState.neteaseLoading = true;
  renderHomePlatformRecommendations();
  try {
    if (homeDiscoverState.loading && typeof waitForHomeDiscoverIdle === 'function') await waitForHomeDiscoverIdle(2600);
    if (force || !homeDiscoverState.loaded) await loadHomeDiscover(!!force);
    if (homeDiscoverState.loading && typeof waitForHomeDiscoverIdle === 'function') await waitForHomeDiscoverIdle(2600);
    if (force || !Array.isArray(homeDiscoverState.podcasts) || !homeDiscoverState.podcasts.length) {
      var podcastData = await apiJson('/api/podcast/hot?limit=8&t=' + Date.now(), { timeoutMs: 12000 });
      var hotPodcasts = podcastData && Array.isArray(podcastData.podcasts) ? podcastData.podcasts : [];
      if (hotPodcasts.length) homeDiscoverState.podcasts = hotPodcasts;
    }
  } catch (error) {
    console.warn('[HomePlatformNetease]', error);
  } finally {
    homePlatformRecommendationState.neteaseLoading = false;
    renderHomePlatformRecommendations();
  }
}

async function loadHomePlatformQishuiRecommendations(force) {
  return loadHomePlatformFeedRecommendations('qishui', force);
}

async function loadHomePlatformFeedRecommendations(source, force) {
  var config = homePlatformRecommendationFeedConfig(source);
  var feedState = homePlatformRecommendationState.feeds[source];
  if (!config || !feedState || feedState.loading) return;
  if (feedState.loaded && !force) return;
  feedState.loading = true;
  feedState.error = '';
  feedState.message = '';
  renderHomePlatformRecommendations();
  try {
    var separator = config.endpoint.indexOf('?') >= 0 ? '&' : '?';
    var data = await apiJson(config.endpoint + separator + 't=' + Date.now(), { timeoutMs: 14000 });
    var rawSongs = data && (data.songs || data.tracks || data.items || data.recommendations);
    feedState.songs = (Array.isArray(rawSongs) ? rawSongs : []).map(cloneSong);
    feedState.error = data && data.error ? String(data.error) : '';
    feedState.message = data && data.message ? String(data.message) : '';
    feedState.mode = data && data.mode ? String(data.mode) : '';
    feedState.source = data && data.source ? String(data.source) : '';
    feedState.fallback = !!(data && data.fallback);
    feedState.provenance = data && data.provenance ? String(data.provenance) : '';
    feedState.loaded = true;
  } catch (error) {
    console.warn('[HomePlatformFeed:' + source + ']', error);
    feedState.songs = [];
    feedState.error = String(error && error.message || 'PLATFORM_FEED_FAILED');
    feedState.message = '';
    feedState.loaded = true;
  } finally {
    feedState.loading = false;
    renderHomePlatformRecommendations();
  }
}

async function loadHomePlatformRecommendations(source, force) {
  homePlatformRecommendationState.source = source || 'netease';
  renderHomePlatformRecommendations();
  try {
    await loadHomePlatformPublicRecommendations(homePlatformRecommendationState.source, force);
  } catch (error) {
    console.warn('[HomePlatformRecommendations]', error);
  }
  renderHomePlatformRecommendations();
}

async function loadHomePlatformPublicRecommendations(source, force) {
  var type = homePlatformRecommendationState.contentType === 'playlists' ? 'playlists' : 'songs';
  var bucket = homePlatformRecommendationState.publicFeeds[type];
  var state = bucket[source];
  if (!state) state = bucket[source] = { loading: false, loaded: false, items: [], error: '', message: '', page: 0, seen: Object.create(null) };
  if (state.loading || (state.loaded && !force)) return;
  state.loading = true;
  if (force) state.page = Math.max(0, Number(state.page) || 0) + 1;
  state.error = '';
  state.message = '';
  renderHomePlatformRecommendations();
  try {
    var data = await apiJson('/api/platform/recommendations?provider=' + encodeURIComponent(source) + '&type=' + type + '&limit=12&page=' + encodeURIComponent(state.page || 0) + '&t=' + Date.now(), { timeoutMs: 20000 });
    var items = data && (data.items || (type === 'songs' ? data.songs : data.playlists));
    var fresh = (Array.isArray(items) ? items : []).filter(function (item) {
      var key = String(item && (item.id || item.mid || item.hash || item.uri) || '') || homeMusicFreeMatchText((item && (item.name || item.title) || '') + '|' + (item && item.artist || ''));
      if (!key || state.seen[key]) return false;
      state.seen[key] = true;
      return true;
    });
    if (!fresh.length && state.page > 0) {
      state.page = 0;
      state.seen = Object.create(null);
      data = await apiJson('/api/platform/recommendations?provider=' + encodeURIComponent(source) + '&type=' + type + '&limit=12&page=0&t=' + Date.now(), { timeoutMs: 20000 });
      items = data && (data.items || (type === 'songs' ? data.songs : data.playlists));
      fresh = (Array.isArray(items) ? items : []).filter(function (item) {
        var key = String(item && (item.id || item.mid || item.hash || item.uri) || '') || homeMusicFreeMatchText((item && (item.name || item.title) || '') + '|' + (item && item.artist || ''));
        if (!key || state.seen[key]) return false;
        state.seen[key] = true;
        return true;
      });
    }
    state.items = fresh.map(function (item) { return cloneSong(item); });
    state.error = data && data.error ? String(data.error) : '';
    state.message = data && data.message ? String(data.message) : '';
    state.loaded = true;
  } catch (error) {
    state.items = [];
    state.error = String(error && error.message || 'PLATFORM_PUBLIC_FAILED');
    state.message = '平台公开接口读取失败，请稍后刷新。';
    state.loaded = true;
  } finally {
    state.loading = false;
    renderHomePlatformRecommendations();
  }
}

function homeMusicFreeMatchText(value) {
  return String(value || '').toLowerCase().replace(/[\s·・•,，.。'"“”‘’()（）\[\]【】\-_]+/g, '');
}

function homeMusicFreePluginAvailable(pluginId) {
  var wanted = String(pluginId || '').trim();
  if (!wanted) return false;
  var plugins = typeof musicFreeSourcePlugins !== 'undefined' && Array.isArray(musicFreeSourcePlugins)
    ? musicFreeSourcePlugins : [];
  return plugins.some(function (plugin) {
    return plugin && String(plugin.id || '') === wanted && plugin.loaded !== false && plugin.enabled !== false && plugin.playable !== false;
  });
}

var HOME_MUSICFREE_RESOLVE_CACHE_TTL_MS = 10 * 60 * 1000;
var homeMusicFreeResolveCache = new Map();

async function resolveHomeRecommendationWithMusicFree(song) {
  if (!song) return song;
  if (song.musicFreePluginId && homeMusicFreePluginAvailable(song.musicFreePluginId)) return song;
  var title = String(song.name || song.title || '').trim();
  var artist = String(song.artist || '').trim();
  if (!title) throw new Error('推荐歌曲缺少名称');
  var resolveCacheKey = homeMusicFreeMatchText(title) + '|' + homeMusicFreeMatchText(artist);
  var cachedResolution = homeMusicFreeResolveCache.get(resolveCacheKey);
  if (cachedResolution && cachedResolution.song && Date.now() - cachedResolution.createdAt < HOME_MUSICFREE_RESOLVE_CACHE_TTL_MS) return cloneSong(cachedResolution.song);
  if (cachedResolution) homeMusicFreeResolveCache.delete(resolveCacheKey);
  var data = await apiJson('/api/musicfree/search?keywords=' + encodeURIComponent([title, artist].filter(Boolean).join(' ')) + '&limit=100&offset=0', { timeoutMs: 26000 });
  var rows = data && Array.isArray(data.songs) ? data.songs : [];
  var titleKey = homeMusicFreeMatchText(title);
  var artistKey = homeMusicFreeMatchText(artist);
  var ranked = [];
  rows.forEach(function (item) {
    var itemTitle = homeMusicFreeMatchText(item && (item.name || item.title));
    var itemArtist = homeMusicFreeMatchText(item && item.artist);
    var score = itemTitle === titleKey ? 100 : (itemTitle.indexOf(titleKey) >= 0 || titleKey.indexOf(itemTitle) >= 0 ? 60 : 0);
    if (artistKey && itemArtist) score += itemArtist === artistKey ? 45 : (itemArtist.indexOf(artistKey) >= 0 || artistKey.indexOf(itemArtist) >= 0 ? 25 : 0);
    if (score >= 60) ranked.push({ song: item, score: score });
  });
  if (!ranked.length && artist) {
    var titleOnly = await apiJson('/api/musicfree/search?keywords=' + encodeURIComponent(title) + '&limit=100&offset=0', { timeoutMs: 26000 });
    (titleOnly && Array.isArray(titleOnly.songs) ? titleOnly.songs : []).forEach(function (item) {
      var itemTitle = homeMusicFreeMatchText(item && (item.name || item.title));
      var itemArtist = homeMusicFreeMatchText(item && item.artist);
      var score = itemTitle === titleKey ? 100 : (itemTitle.indexOf(titleKey) >= 0 || titleKey.indexOf(itemTitle) >= 0 ? 60 : 0);
      if (artistKey && itemArtist) score += itemArtist === artistKey ? 45 : (itemArtist.indexOf(artistKey) >= 0 || artistKey.indexOf(itemArtist) >= 0 ? 25 : 0);
      if (score >= 60) ranked.push({ song: item, score: score });
    });
  }
  ranked.sort(function (a, b) { return b.score - a.score; });
  var best = ranked[0] && ranked[0].song;
  if (!best) throw new Error('当前 MusicFree 音源没有匹配到“' + title + '”');
  best.musicFreeAlternates = ranked.slice(1, 8).map(function (entry) { return entry.song; });
  best.recommendationOrigin = { provider: song.provider || song.source || '', id: song.id || '', name: title };
  homeMusicFreeResolveCache.set(resolveCacheKey, { song: cloneSong(best), createdAt: Date.now() });
  if (homeMusicFreeResolveCache.size > 240) homeMusicFreeResolveCache.delete(homeMusicFreeResolveCache.keys().next().value);
  return best;
}

async function playHomePlatformPublicSong(source, index) {
  var state = homePlatformRecommendationState.publicFeeds.songs[source];
  var original = state && state.items && state.items[index];
  if (!original) return;
  showToast('正在用 MusicFree 音源匹配歌曲…');
  try {
    var resolved = await resolveHomeRecommendationWithMusicFree(original);
    playQueue = [cloneSong(resolved)];
    currentIdx = 0;
    safeRenderQueuePanel('home-platform-musicfree-play', { scrollCurrent: true });
    safeShelfRebuild('home-platform-musicfree-play', true);
    forcePlaybackControlsInteractive();
    await playQueueAt(0, { manual: true, context: { type: 'platform-public-song', playlistName: homePlatformRecommendationSourceLabel(source) + ' 推荐歌曲' } });
  } catch (error) { showToast(error && error.message || 'MusicFree 音源匹配失败'); }
}

async function openHomePlatformPublicPlaylist(source, index) {
  var state = homePlatformRecommendationState.publicFeeds.playlists[source];
  var playlist = state && state.items && state.items[index];
  if (!playlist || !playlist.id) return;
  showLoading();
  try {
    var data = await apiJson('/api/platform/playlist/tracks?provider=' + encodeURIComponent(source) + '&id=' + encodeURIComponent(playlist.id) + '&limit=80', { timeoutMs: 22000 });
    var tracks = data && Array.isArray(data.tracks) ? data.tracks : [];
    if (!tracks.length) throw new Error('这个平台歌单暂时没有歌曲');
    tracks.forEach(function (song) { if (song) song._resolveWithMusicFree = true; });
    if (typeof openUnifiedPlaylistDetail === 'function') {
      openUnifiedPlaylistDetail({ playlist: playlist, tracks: tracks, kind: 'platform' });
    }
  } catch (error) { showToast(error && error.message || '平台歌单读取失败'); }
  finally { hideLoading(); }
}

function playHomePlatformFeedSong(source, index) {
  var config = homePlatformRecommendationFeedConfig(source);
  var feedState = homePlatformRecommendationState.feeds[source];
  var songs = feedState && feedState.songs || [];
  if (!config || !songs.length) return;
  playQueue = songs.map(cloneSong);
  currentIdx = Math.max(0, Math.min(playQueue.length - 1, Number(index) || 0));
  homeForcedOpen = false;
  homeSuppressed = false;
  if (typeof setHomeControlsLocked === 'function') setHomeControlsLocked(false);
  if (typeof safeRenderQueuePanel === 'function') safeRenderQueuePanel('home-platform-' + source, { scrollCurrent: true });
  if (typeof safeShelfRebuild === 'function') safeShelfRebuild('home-platform-' + source, true);
  if (typeof forcePlaybackControlsInteractive === 'function') forcePlaybackControlsInteractive();
  Promise.resolve(playQueueAt(currentIdx, {
    manual: true,
    context: { type: 'home-platform-recommendation', playlistName: config.playlistName },
  })).catch(function (error) { console.warn('[HomePlatformFeedPlay:' + source + ']', error); });
}

function closeHomePlatformRecommendations() {
  var mask = document.getElementById('home-platform-recommend-mask');
  if (!mask) return;
  mask.classList.remove('show');
  mask.setAttribute('aria-hidden', 'true');
  homePlatformRecommendationState.open = false;
  var focusTarget = homePlatformRecommendationState.previousFocus;
  homePlatformRecommendationState.previousFocus = null;
  if (focusTarget && typeof focusTarget.focus === 'function') {
    setTimeout(function () { focusTarget.focus(); }, 0);
  }
}

function bindHomePlatformRecommendationControls() {
  if (homePlatformRecommendationControlsBound) return;
  homePlatformRecommendationControlsBound = true;
  var mask = document.getElementById('home-platform-recommend-mask');
  var tabs = document.getElementById('home-platform-recommend-tabs');
  var list = document.getElementById('home-platform-recommend-list');
  var close = document.getElementById('home-platform-recommend-close');
  var done = document.getElementById('home-platform-recommend-done');
  var refresh = document.getElementById('home-platform-recommend-refresh');
  if (tabs) tabs.addEventListener('click', function (event) {
    var tab = event.target.closest('[data-home-recommend-source]');
    if (!tab || !tabs.contains(tab)) return;
    loadHomePlatformRecommendations(tab.getAttribute('data-home-recommend-source'), false);
  });
  if (list) list.addEventListener('click', function (event) {
    var card = event.target.closest('[data-home-recommend-kind]');
    if (!card || !list.contains(card)) return;
    var kind = card.getAttribute('data-home-recommend-kind');
    var index = Number(card.getAttribute('data-home-recommend-index')) || 0;
    closeHomePlatformRecommendations();
    if (/^(netease|qq|qishui|kugou|spotify)-public-playlist$/.test(kind)) openHomePlatformPublicPlaylist(kind.replace(/-public-playlist$/, ''), index);
    else if (/^(netease|qq|qishui|kugou|spotify)-public-song$/.test(kind)) playHomePlatformPublicSong(kind.replace(/-public-song$/, ''), index);
    else if (kind === 'netease-playlist' && typeof openHomePlaylist === 'function') openHomePlaylist(index);
    else if (kind === 'netease-song' && typeof playHomeSong === 'function') playHomeSong(index);
    else if (/^(qq|qishui|kugou|spotify)-song$/.test(kind)) playHomePlatformFeedSong(kind.replace(/-song$/, ''), index);
  });
  if (list) list.addEventListener('scroll', scheduleHomePlatformDailyWindowRender, { passive: true });
  window.addEventListener('resize', scheduleHomePlatformDailyWindowRender, { passive: true });
  if (close) close.addEventListener('click', closeHomePlatformRecommendations);
  if (done) done.addEventListener('click', closeHomePlatformRecommendations);
  if (refresh) refresh.addEventListener('click', function () {
    loadHomePlatformRecommendations(homePlatformRecommendationState.source, true);
  });
  if (mask) mask.addEventListener('click', function (event) {
    if (event.target === mask) closeHomePlatformRecommendations();
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && homePlatformRecommendationState.open) closeHomePlatformRecommendations();
  });
}

function openHomePlatformRecommendations(preferredSource, contentType) {
  bindHomePlatformRecommendationControls();
  var mask = document.getElementById('home-platform-recommend-mask');
  if (!mask) return;
  homePlatformRecommendationState.previousFocus = document.activeElement;
  homePlatformRecommendationState.open = true;
  homePlatformRecommendationState.contentType = contentType === 'playlists' ? 'playlists' : 'songs';
  mask.classList.add('show');
  mask.setAttribute('aria-hidden', 'false');
  var defaultSource = loginStatus && loginStatus.loggedIn
    ? 'netease'
    : (qishuiLoginStatus && (qishuiLoginStatus.loggedIn || qishuiLoginStatus.configured)
      ? 'qishui'
      : (kugouLoginStatus && kugouLoginStatus.loggedIn
        ? 'kugou'
        : (spotifyLoginStatus && (spotifyLoginStatus.loggedIn || spotifyLoginStatus.configured) ? 'spotify' : 'netease')));
  var source = /^(netease|qishui|qq|kugou|spotify)$/.test(String(preferredSource || '')) ? preferredSource : defaultSource;
  loadHomePlatformRecommendations(source, false);
  setTimeout(function () {
    var activeTab = mask.querySelector('[data-home-recommend-source="' + source + '"]');
    if (activeTab) activeTab.focus();
  }, 0);
}

function openHomeDashboardRadio() {
  openHomePlatformRecommendations('netease', 'playlists');
}

function scheduleHomeDashboardRefresh() {
  if (homeDashboardRefreshTimer) {
    clearTimeout(homeDashboardRefreshTimer);
    homeDashboardRefreshTimer = null;
  }
  if (!emptyHomeActive || document.hidden) return;
  homeDashboardRefreshTimer = setTimeout(function () {
    homeDashboardRefreshTimer = null;
    if (!emptyHomeActive || document.hidden) return;
    homeDashboardUpdateClock();
    renderHomeInsightDock();
    scheduleHomeDashboardRefresh();
  }, 15000);
}

function renderHomeDashboard() {
  renderHomeDashboardHero();
  renderHomeDashboardQuickCards();
  renderHomeInsightDock();
  scheduleHomeDashboardRefresh();
}

var homeDashboardBaseRenderHomeDiscover = typeof renderHomeDiscover === 'function' ? renderHomeDiscover : null;
if (homeDashboardBaseRenderHomeDiscover) {
  renderHomeDiscover = function () {
    var result = homeDashboardBaseRenderHomeDiscover.apply(this, arguments);
    renderHomeDashboard();
    return result;
  };
}

document.addEventListener('visibilitychange', function () {
  if (!document.hidden && emptyHomeActive) renderHomeDashboard();
  else scheduleHomeDashboardRefresh();
  homeDashboardUpdateVideoPower();
});

bindHomeDashboardVideoControls();
bindHomePlatformRecommendationControls();
renderHomeDashboard();
