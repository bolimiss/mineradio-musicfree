package com.mineradio.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import java.net.HttpURLConnection
import java.net.URL

/** Metadata-import receiver. It never asks the playback/source APIs for media. */
class ShareImportActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> intent.data?.getQueryParameter("text") ?: intent.dataString
            else -> null
        }.orEmpty()
        Thread {
            runCatching {
                val connection = URL("http://127.0.0.1:3000/api/universal-import/import").openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.setRequestProperty("X-MineRadio-Receiver", "android-action-send")
                connection.doOutput = true
                val escaped = shared.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
                connection.outputStream.use { it.write("{\"text\":\"$escaped\",\"receiver\":\"android-action-send\"}".toByteArray()) }
                connection.inputStream.close()
            }
            runOnUiThread { finish() }
        }.start()
    }
}
