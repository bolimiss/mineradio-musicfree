'use strict';

const PLATFORM_RULES = [
  { id: 'qq', label: 'QQMusic', hosts: [/(^|\.)y\.qq\.com$/, /(^|\.)i\.y\.qq\.com$/, /(^|\.)c6\.y\.qq\.com$/, /(^|\.)music\.qq\.com$/], features: [/qqmusic/i, /songmid|disstid|songid|taoge|toplist/i] },
  { id: 'netease', label: 'NetEase', hosts: [/(^|\.)music\.163\.com$/, /(^|\.)163cn\.tv$/, /(^|\.)music\.163\.cn$/], features: [/orpheus|neteasecloudmusic/i, /playlist|song|album|program/i] },
  { id: 'kugou', label: 'KuGou', hosts: [/(^|\.)kugou\.com$/, /(^|\.)kugou\.cn$/, /(^|\.)kg\.qq\.com$/], features: [/kugou/i, /songlist|special|collection|song\.html/i] },
  { id: 'kuwo', label: 'KuWo', hosts: [/(^|\.)kuwo\.cn$/, /(^|\.)kuwo\.com$/], features: [/kuwo/i, /playlist|album|play_detail|rid=/i] },
  { id: 'qishui', label: 'Qishui', hosts: [/(^|\.)qishui\.com$/, /(^|\.)tsmusic\.cn$/, /(^|\.)music\.douyin\.com$/, /(^|\.)douyin\.com$/, /(^|\.)douyin\.cn$/], features: [/qishui|luna/i, /playlist|track|song|music/i] },
];

function detectPlatform(value) {
  const raw = String(value || '');
  let host = '';
  try { host = new URL(raw).hostname.toLowerCase(); } catch (_) { }
  for (const rule of PLATFORM_RULES) if (rule.hosts.some(test => test.test(host))) return { id: rule.id, label: rule.label };
  const schemeRules = [
    ['qq', 'QQMusic', /qqmusic:\/\//i],
    ['netease', 'NetEase', /(?:orpheus|neteasecloudmusic):\/\//i],
    ['kugou', 'KuGou', /kugou:\/\//i],
    ['kuwo', 'KuWo', /kuwo:\/\//i],
    ['qishui', 'Qishui', /(?:qishui|luna):\/\//i],
  ];
  for (const rule of schemeRules) if (rule[2].test(raw)) return { id: rule[0], label: rule[1] };
  return { id: '', label: 'Unknown' };
}

function detectResourceType(value) {
  const raw = String(value || '').toLowerCase();
  if (/\b(album|zhuanji)\b|\/album\//.test(raw)) return 'album';
  if (/\b(playlist|songlist|special|collection|taoge|toplist|sheet)\b|\/playlist(?:_detail)?\//.test(raw)) return 'playlist';
  if (/\b(song|track|play_detail)\b|songmid=|rid=music_|song\.html/.test(raw)) return 'song';
  return 'collection';
}

module.exports = { PLATFORM_RULES, detectPlatform, detectResourceType };
