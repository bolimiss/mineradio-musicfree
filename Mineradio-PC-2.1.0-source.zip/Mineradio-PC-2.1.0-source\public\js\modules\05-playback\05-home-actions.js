function songFromListenRecord(record) {
  if (!record) return null;
  var provider = record.sourceKey || '';
  if (!provider && record.type === 'qq') provider = 'qq';
  if (!provider) provider = record.mid ? 'qq' : 'netease';
  var isBilibili = String(record.musicFreePluginId || '') === (typeof MINERADIO_BILIBILI_PLUGIN_ID !== 'undefined' ? MINERADIO_BILIBILI_PLUGIN_ID : 'dea0a4b3f3697456bdef')
    || /bilibili|哔哩哔哩|dea0a4b3f3697456bdef/i.test([record.key, record.sourceKey, record.source, record.provider, record.musicFreePlatform].filter(Boolean).join(' '));
  var song = {
    key: record.key || '',
    provider: provider,
    source: provider,
    type: record.type || (provider === 'qq' ? 'qq' : 'song'),
    id: record.id || record.mid || record.key || '',
    mid: record.mid || '',
    songmid: record.mid || '',
    mediaMid: record.mediaMid || '',
    name: record.name || '继续听',
    artist: record.artist || '',
    cover: record.cover || '',
  };
  if (isBilibili) {
    song.provider = 'bilibili';
    song.source = 'bilibili';
    song.type = 'musicfree';
    song.mediaType = 'video';
    song.musicFreePluginId = record.musicFreePluginId || 'dea0a4b3f3697456bdef';
    song.musicFreePlatform = 'bilibili';
    song.musicFreeLabel = record.musicFreeLabel || 'bilibili';
    song.musicFreeSourceOnly = true;
    song.musicFreeFallbackPolicy = 'source-only';
    song.musicFreeItem = record.musicFreeItem || { id: song.id, bvid: /^BV/i.test(String(song.id || '')) ? song.id : '' };
  }
  return song;
}
async function playHomeRecent(record) {
  record = record || homeListenSummary().recent;
  if (!record) {
    showToast('还没有听歌记录');
    return;
  }
  var song = songFromListenRecord(record);
  if (!song || (!song.id && !song.mid)) {
    runHomeSearch(record.name || '');
    return;
  }
  activeRadioContext = null;
  playQueue = [cloneSong(song)];
  currentIdx = 0;
  safeRenderQueuePanel('home-recent-song');
  safeShelfRebuild('home-recent-song', true);
  forcePlaybackControlsInteractive();
  await playQueueAt(0);
}
function openHomeInsight() {
  var modal = document.getElementById('home-listen-detail-modal');
  var metricsRoot = document.getElementById('home-listen-detail-metrics');
  var tracksRoot = document.getElementById('home-listen-detail-tracks');
  var count = document.getElementById('home-listen-detail-count');
  var date = document.getElementById('home-listen-detail-date');
  var metrics = typeof homeDashboardTodayListenMetrics === 'function' ? homeDashboardTodayListenMetrics() : { listenMs: 0, songCount: 0, topArtist: '', streak: 0 };
  var now = new Date();
  var start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  var records = listenStatsState && Array.isArray(listenStatsState.history) ? listenStatsState.history.filter(function (item) { return item && Number(item.playedAt) >= start; }) : [];
  if (date) date.textContent = now.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });
  if (metricsRoot) metricsRoot.innerHTML =
    '<div><span>TIME</span><b>' + escHtml(homeDashboardListenDurationText(metrics.listenMs)) + '</b><small>今日聆听时长</small></div>' +
    '<div><span>TRACKS</span><b>' + metrics.songCount + ' 首</b><small>今日不同歌曲</small></div>' +
    '<div><span>ARTIST</span><b>' + escHtml(metrics.topArtist || '等待记录') + '</b><small>今日最常听歌手</small></div>' +
    '<div><span>STREAK</span><b>' + metrics.streak + ' 天</b><small>连续聆听天数</small></div>';
  if (count) count.textContent = String(records.length);
  if (tracksRoot) tracksRoot.innerHTML = records.length ? records.map(function (record, index) {
    return '<button type="button" onclick="playHomeRecent((listenStatsState.history||[]).filter(function(item){var d=new Date();d.setHours(0,0,0,0);return item&&Number(item.playedAt)>=d.getTime()})[' + index + ']);closeHomeInsight()">' +
      (record.cover ? '<img src="' + escHtml(record.cover) + '" alt="">' : '<i>♫</i>') + '<span><b>' + escHtml(record.name || '未知歌曲') + '</b><small>' + escHtml(record.artist || record.source || '未知歌手') + '</small></span><time>' + new Date(record.playedAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) + '</time></button>';
  }).join('') : '<div class="home-listen-detail-empty">今天还没有播放记录，去每日推荐听一首吧。</div>';
  if (modal) { modal.setAttribute('aria-hidden', 'false'); openGsapModal(modal); }
}
function closeHomeInsight() {
  var modal = document.getElementById('home-listen-detail-modal');
  if (modal) modal.setAttribute('aria-hidden', 'true');
  closeGsapModal(modal);
}
function handleHomeTileClick(index) {
  var row = document.getElementById('home-tile-row');
  var item = row && row._homeTiles && row._homeTiles[index];
  if (!item) return;
  if (item.kind === 'recent') playHomeRecent(item.record);
  else if (item.kind === 'profile') openHomeInsight();
  else if (item.kind === 'song') playHomeSong(item.index);
  else if (item.kind === 'sources') openMusicFreeSourceManager();
  else if (item.kind === 'local') openHomeLocalImport();
  else if (item.kind === 'guide') openHomeProductGuide();
  else if (item.kind === 'playlist') openHomePlaylist(item.index);
  else if (item.kind === 'podcast') openHomePodcast(item.index);
  else if (item.kind === 'podcastSearch') { setSearchMode('podcast'); loadPodcastHot(); }
  else if (item.kind === 'library') openHomeLibrary();
  else runHomeSearch(item.query || item.title || '');
}
