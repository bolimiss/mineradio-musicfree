'use strict';

const fs = require('fs');
const path = require('path');

class PlaylistDatabase {
  constructor(filePath) {
    this.filePath = filePath;
    this.state = { version: 1, playlists: [], events: [], tests: [] };
    this.load();
  }

  load() {
    try {
      const value = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      if (value && Array.isArray(value.playlists)) this.state = Object.assign(this.state, value);
    } catch (_) { }
    return this.state;
  }

  persist() {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const temporary = this.filePath + '.tmp-' + process.pid;
    fs.writeFileSync(temporary, JSON.stringify(this.state, null, 2), 'utf8');
    fs.renameSync(temporary, this.filePath);
  }

  list() { return this.state.playlists.slice(); }
  get(id) { return this.state.playlists.find(item => item.id === id || item.playlistId === id) || null; }

  upsert(playlist) {
    const index = this.state.playlists.findIndex(item => item.id === playlist.id || (item.platform === playlist.platform && item.sourceUrl === playlist.sourceUrl));
    if (index >= 0) this.state.playlists[index] = Object.assign({}, this.state.playlists[index], playlist);
    else this.state.playlists.unshift(playlist);
    this.persist();
    return index >= 0 ? this.state.playlists[index] : this.state.playlists[0];
  }

  remove(id) {
    const before = this.state.playlists.length;
    this.state.playlists = this.state.playlists.filter(item => item.id !== id && item.playlistId !== id);
    if (this.state.playlists.length !== before) this.persist();
    return before !== this.state.playlists.length;
  }

  event(type, data) {
    const entry = { id: Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7), type, at: Date.now(), data: data || {} };
    this.state.events.unshift(entry);
    this.state.events = this.state.events.slice(0, 500);
    this.persist();
    return entry;
  }

  recordTest(record) {
    this.state.tests.unshift(record);
    this.state.tests = this.state.tests.slice(0, 1000);
    this.persist();
  }

  diagnostics() {
    const tests = this.state.tests;
    const successful = tests.filter(item => item.ok).length;
    const averageMs = tests.length ? Math.round(tests.reduce((sum, item) => sum + Number(item.elapsedMs || 0), 0) / tests.length) : 0;
    const failures = {};
    tests.filter(item => !item.ok).forEach(item => { const reason = item.error || 'UNKNOWN'; failures[reason] = (failures[reason] || 0) + 1; });
    return { total: tests.length, successful, failed: tests.length - successful, successRate: tests.length ? successful / tests.length : 0, averageMs, failures, recent: tests.slice(0, 100) };
  }
}

module.exports = { PlaylistDatabase };
