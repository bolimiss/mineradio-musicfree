import Social
import UniformTypeIdentifiers

final class ShareViewController: SLComposeServiceViewController {
    override func didSelectPost() {
        let providers = extensionContext?.inputItems
            .compactMap { $0 as? NSExtensionItem }
            .flatMap(\.attachments) ?? []
        let provider = providers.first { $0.hasItemConformingToTypeIdentifier(UTType.url.identifier) }
            ?? providers.first { $0.hasItemConformingToTypeIdentifier(UTType.text.identifier) }
        guard let provider else { extensionContext?.completeRequest(returningItems: nil); return }
        let type = provider.hasItemConformingToTypeIdentifier(UTType.url.identifier) ? UTType.url.identifier : UTType.text.identifier
        provider.loadItem(forTypeIdentifier: type) { [weak self] item, _ in
            let text = (item as? URL)?.absoluteString ?? (item as? String) ?? ""
            var request = URLRequest(url: URL(string: "http://127.0.0.1:3000/api/universal-import/import")!)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("ios-share-extension", forHTTPHeaderField: "X-MineRadio-Receiver")
            request.httpBody = try? JSONSerialization.data(withJSONObject: ["text": text, "receiver": "ios-share-extension"])
            URLSession.shared.dataTask(with: request) { _, _, _ in
                self?.extensionContext?.completeRequest(returningItems: nil)
            }.resume()
        }
    }

    override func isContentValid() -> Bool { true }
}
