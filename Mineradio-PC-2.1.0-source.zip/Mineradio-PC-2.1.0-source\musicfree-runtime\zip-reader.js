'use strict';

const path = require('path');
const zlib = require('zlib');

const MAX_ENTRIES = 200;
const MAX_ENTRY_BYTES = 4 * 1024 * 1024;
const MAX_TOTAL_BYTES = 12 * 1024 * 1024;

function findEndRecord(buffer) {
  const minimum = Math.max(0, buffer.length - 65557);
  for (let offset = buffer.length - 22; offset >= minimum; offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  throw new Error('ZIP_END_RECORD_NOT_FOUND');
}

function safeEntryName(value) {
  const normalized = String(value || '').replace(/\\/g, '/').replace(/^\/+/, '');
  if (!normalized || normalized.includes('\0') || normalized.split('/').includes('..') || path.posix.isAbsolute(normalized)) {
    throw new Error('ZIP_UNSAFE_ENTRY_PATH');
  }
  return normalized;
}

function readZipEntries(input) {
  const buffer = Buffer.isBuffer(input) ? input : Buffer.from(input || []);
  if (buffer.length < 22 || buffer.readUInt32LE(0) !== 0x04034b50) throw new Error('INVALID_ZIP_FILE');
  const endOffset = findEndRecord(buffer);
  const entryCount = buffer.readUInt16LE(endOffset + 10);
  const centralOffset = buffer.readUInt32LE(endOffset + 16);
  if (entryCount > MAX_ENTRIES) throw new Error('ZIP_TOO_MANY_ENTRIES');
  let cursor = centralOffset;
  let totalBytes = 0;
  const entries = [];
  for (let index = 0; index < entryCount; index += 1) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== 0x02014b50) throw new Error('ZIP_CENTRAL_DIRECTORY_INVALID');
    const flags = buffer.readUInt16LE(cursor + 8);
    const method = buffer.readUInt16LE(cursor + 10);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localOffset = buffer.readUInt32LE(cursor + 42);
    const name = safeEntryName(buffer.slice(cursor + 46, cursor + 46 + nameLength).toString((flags & 0x800) ? 'utf8' : 'utf8'));
    cursor += 46 + nameLength + extraLength + commentLength;
    if (name.endsWith('/')) continue;
    if (flags & 0x1) throw new Error('ZIP_ENCRYPTED_ENTRY_UNSUPPORTED');
    if (uncompressedSize > MAX_ENTRY_BYTES) throw new Error('ZIP_ENTRY_TOO_LARGE:' + name);
    if (localOffset + 30 > buffer.length || buffer.readUInt32LE(localOffset) !== 0x04034b50) throw new Error('ZIP_LOCAL_HEADER_INVALID');
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataOffset = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.slice(dataOffset, dataOffset + compressedSize);
    let data;
    if (method === 0) data = Buffer.from(compressed);
    else if (method === 8) data = zlib.inflateRawSync(compressed, { maxOutputLength: MAX_ENTRY_BYTES });
    else throw new Error('ZIP_COMPRESSION_UNSUPPORTED:' + method);
    if (uncompressedSize && data.length !== uncompressedSize) throw new Error('ZIP_ENTRY_SIZE_MISMATCH:' + name);
    totalBytes += data.length;
    if (totalBytes > MAX_TOTAL_BYTES) throw new Error('ZIP_EXPANDED_CONTENT_TOO_LARGE');
    entries.push({ name, data });
  }
  return entries;
}

function pluginCandidates(entries) {
  const files = new Map(entries.map(entry => [entry.name.toLowerCase(), entry]));
  let packageMain = '';
  const packageEntry = entries.find(entry => /(^|\/)package\.json$/i.test(entry.name));
  if (packageEntry) {
    try {
      const info = JSON.parse(packageEntry.data.toString('utf8'));
      packageMain = String(info && (info.main || info.module) || '').replace(/^\.\//, '');
      if (packageMain && packageEntry.name.includes('/')) packageMain = packageEntry.name.slice(0, packageEntry.name.lastIndexOf('/') + 1) + packageMain;
    } catch (_) {}
  }
  const scripts = entries.filter(entry => /\.m?js$/i.test(entry.name));
  scripts.sort((a, b) => {
    const rank = entry => {
      if (packageMain && entry.name.toLowerCase() === packageMain.toLowerCase()) return 0;
      if (/^index\.js$/i.test(entry.name)) return 1;
      if (/(^|\/)dist\/index\.js$/i.test(entry.name)) return 2;
      if (/(^|\/)index\.js$/i.test(entry.name)) return 3;
      return 10;
    };
    return rank(a) - rank(b) || a.name.localeCompare(b.name);
  });
  return { scripts, manifests: entries.filter(entry => /\.json$/i.test(entry.name) && !/(^|\/)package\.json$/i.test(entry.name)), files };
}

module.exports = { readZipEntries, pluginCandidates, MAX_ENTRIES, MAX_ENTRY_BYTES, MAX_TOTAL_BYTES };
