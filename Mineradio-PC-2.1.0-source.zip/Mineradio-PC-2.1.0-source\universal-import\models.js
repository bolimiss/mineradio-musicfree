'use strict';

const crypto = require('crypto');

function text(value) { return String(value == null ? '' : value).trim(); }
function stableId(parts) { return crypto.createHash('sha1').update(parts.map(text).join('\u001f')).digest('hex').slice(0, 20); }

function toTrack(input, platform, sourceUrl) {
  const item = input && input.song ? input.song : (input || {});
  const title = text(item.title || item.name || item.songName);
  const artistValue = item.artist || item.artists || item.singer || item.author;
  const artist = Array.isArray(artistValue) ? artistValue.map(entry => text(entry && (entry.name || entry))).filter(Boolean).join(' / ') : text(artistValue);
  const id = text(item.id || item.songId || item.mid || item.rid || item.hash) || stableId([platform, title, artist, item.album]);
  return {
    id,
    platform: text(platform || item.platform || item.source),
    title,
    artist,
    album: text(item.album && item.album.name || item.album || item.albumName),
    cover: text(item.cover || item.artwork || item.pic || item.albumCover),
    duration: Math.max(0, Number(item.duration || item.interval || 0) || 0),
    sourceUrl: text(item.sourceUrl || item.url || sourceUrl),
  };
}

function toPlaylist(result, normalized) {
  const meta = result && result.playlist || {};
  const platform = text(result && result.provider || normalized.platform);
  const sourceUrl = text(result && (result.resolvedUrl || result.sourceUrl) || normalized.sourceUrl);
  const tracks = (Array.isArray(result && result.tracks) ? result.tracks : []).map(item => toTrack(item, platform, sourceUrl));
  const playlistId = text(meta.playlistId || meta.id) || stableId([platform, sourceUrl]);
  return {
    id: playlistId,
    playlistId,
    platform,
    sourceUrl,
    name: text(meta.title || meta.name) || '导入歌单',
    title: text(meta.title || meta.name) || '导入歌单',
    cover: text(meta.cover),
    creator: text(meta.creator),
    tracks,
    syncTime: Date.now(),
    lastSyncTime: Date.now(),
    autoSync: true,
    syncStatus: 'idle',
  };
}

function trackKey(track) { return text(track && track.platform) + ':' + text(track && track.id); }
function diffTracks(previous, next) {
  const oldMap = new Map((previous || []).map(item => [trackKey(item), item]));
  const newMap = new Map((next || []).map(item => [trackKey(item), item]));
  const added = [], removed = [], updated = [];
  for (const [key, item] of newMap) {
    if (!oldMap.has(key)) added.push(item);
    else if (JSON.stringify(oldMap.get(key)) !== JSON.stringify(item)) updated.push({ before: oldMap.get(key), after: item });
  }
  for (const [key, item] of oldMap) if (!newMap.has(key)) removed.push(item);
  return { added, removed, updated, changed: added.length + removed.length + updated.length };
}

module.exports = { diffTracks, stableId, toPlaylist, toTrack, trackKey };
