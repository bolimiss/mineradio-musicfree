var MINERADIO_BILIBILI_PLUGIN_ID = 'dea0a4b3f3697456bdef';

function isBilibiliTrack(song) {
  song = song || {};
  if (String(song.musicFreePluginId || '') === MINERADIO_BILIBILI_PLUGIN_ID) return true;
  var identity = [song.musicFreePlatform, song.musicFreeLabel, song.platform, song.provider, song.source, song.sourceKey, song.key]
    .filter(Boolean).join(' ').toLowerCase();
  if (/\bbilibili\b|\bbili\b|哔哩哔哩| bilibili:/.test(identity)) return true;
  var item = song.musicFreeItem || {};
  return !!(song.mediaType === 'video' && (item.bvid || item.aid || song.bvid || song.aid));
}

function mineradioMediaType(song) {
  song = song || {};
  // VideoPlayer is a Bilibili-only capability.  Imported tracks and old queue
  // snapshots can carry a stale `mediaType: video`; never allow that field by
  // itself to divert another MusicFree provider away from AudioPlayer.
  if (isBilibiliTrack(song)) return 'video';
  return 'audio';
}

function BilibiliVideoPlayer() {
  this.root = document.getElementById('bilibili-video-player');
  this.video = document.getElementById('bvp-video');
  this.audioEl = new Audio();
  this.audioEl.preload = 'auto';
  this.audioEl.crossOrigin = 'anonymous';
  this.active = false;
  this.loading = false;
  this.audioOnly = false;
  this.manualAudioOnly = false;
  this.warmAudioActive = false;
  this.song = null;
  this.queueIndex = -1;
  this.source = null;
  this.selectedQuality = '';
  this.serial = 0;
  this.syncTimer = 0;
  this.videoFallbackTimer = 0;
  this.resolveInFlight = false;
  this.resumeContext = null;
  this.sourceCache = new Map();
  this.failedKeys = new Map();
  this.skipBusy = false;
  this.bind();
}

BilibiliVideoPlayer.prototype.songKey = function (song) {
  if (!song) return '';
  if (typeof queueItemKey === 'function') return queueItemKey(song);
  return [song.musicFreePluginId || '', song.id || song.aid || song.bvid || '', song.name || song.title || '', song.artist || ''].join('|');
};

BilibiliVideoPlayer.prototype.resolveSource = async function (song, quality) {
  var key = this.songKey(song);
  var requested = quality || 64;
  var cached = key && this.sourceCache.get(key);
  if (cached && Date.now() - Number(cached.createdAt || 0) > 240000) {
    this.sourceCache.delete(key);
    cached = null;
  }
  if (cached && cached.quality === String(requested)) return cached.promise;
  var promise = apiJson('/api/musicfree/video', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ song: song, quality: requested }),
    timeoutMs: 7200,
  });
  if (key) this.sourceCache.set(key, { quality: String(requested), promise: promise, createdAt: Date.now() });
  try {
    var data = await promise;
    if (!data || data.error || !data.proxyAudioUrl) throw new Error(data && data.error || 'BILIBILI_AUDIO_SOURCE_EMPTY');
    return data;
  } catch (error) {
    if (key) this.sourceCache.delete(key);
    throw error;
  }
};

BilibiliVideoPlayer.prototype.prefetch = function (song) {
  if (!song || !isBilibiliTrack(song)) return;
  this.resolveSource(song, 64).catch(function () { });
};

BilibiliVideoPlayer.prototype.resolveWarmAudioSource = async function (song) {
  var data = await apiJson('/api/musicfree/bilibili-audio', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ song: song, quality: 'original' }),
    timeoutMs: 7000,
  });
  if (!data || data.error || !data.proxyUrl || data.fallbackUsed || Number(data.attemptedSources || 0) !== 1 || String(data.source || '').toLowerCase() !== 'bilibili') {
    throw new Error(data && data.error || 'BILIBILI_WARM_AUDIO_FAILED');
  }
  return data;
};

BilibiliVideoPlayer.prototype.startWarmAudio = async function (data, position, serial) {
  if (!data || !data.proxyUrl || serial !== this.serial || !this.active) return null;
  this.audioEl.pause();
  this.audioEl.src = data.proxyUrl;
  var speedControl = document.getElementById('bvp-speed');
  this.audioEl.playbackRate = Number(speedControl && speedControl.value || 1);
  this.audioEl.volume = Math.max(0, Math.min(1, typeof targetVolume === 'number' ? targetVolume : 0.85));
  this.audioEl.load();
  await this.waitForMetadata(this.audioEl, 4800);
  if (serial !== this.serial || !this.active) return null;
  var duration = Number(this.audioEl.duration || 0);
  var target = Math.max(0, Math.min(Number(position) || 0, duration > 0 ? Math.max(0, duration - 0.25) : Number(position) || 0));
  if (target > 0) this.audioEl.currentTime = target;
  this.audioOnly = true;
  this.warmAudioActive = true;
  this.root.classList.add('audio-only');
  await this.audioEl.play();
  this.startSync();
  this.updatePlayingState(true);
  this.updateProgress();
  this.setStatus('Bilibili 音频已开始播放，正在准备视频画面…', false);
  return { startedAt: Date.now(), data: data };
};

BilibiliVideoPlayer.prototype.loadVideoOntoWarmAudio = async function (videoUrl, deadlineMs) {
  if (!videoUrl || !this.warmAudioActive) return false;
  this.video.pause();
  this.video.src = videoUrl;
  this.video.playbackRate = this.audioEl.playbackRate;
  this.video.load();
  var remaining = Math.max(300, Number(deadlineMs || Date.now() + 1800) - Date.now());
  await this.waitForMetadata(this.video, Math.min(1800, remaining));
  this.video.currentTime = Math.max(0, Number(this.audioEl.currentTime || 0));
  return true;
};

BilibiliVideoPlayer.prototype.prefetchNext = function () {
  if (!Array.isArray(playQueue) || !playQueue.length || this.queueIndex < 0) return;
  var nextIndex = (this.queueIndex + 1) % playQueue.length;
  if (nextIndex === this.queueIndex) return;
  this.prefetch(playQueue[nextIndex]);
};

BilibiliVideoPlayer.prototype.markFailed = function (song) {
  var key = this.songKey(song);
  if (!key) return;
  this.failedKeys.set(key, Date.now());
  this.sourceCache.delete(key);
};

BilibiliVideoPlayer.prototype.skipToNextBilibili = async function (fromIndex) {
  if (this.skipBusy || !Array.isArray(playQueue) || playQueue.length < 2) return false;
  this.skipBusy = true;
  this.markFailed(this.song || playQueue[fromIndex]);
  var now = Date.now();
  var candidates = [];
  for (var offset = 1; offset < playQueue.length; offset++) {
    var index = (Number(fromIndex) + offset + playQueue.length) % playQueue.length;
    var candidate = playQueue[index];
    if (!isBilibiliTrack(candidate)) continue;
    var failedAt = Number(this.failedKeys.get(this.songKey(candidate)) || 0);
    if (failedAt && now - failedAt < 5 * 60 * 1000) continue;
    candidates.push({ index: index, song: candidate });
  }
  try {
    for (var i = 0; i < candidates.length; i++) {
      showToast('当前 Bilibili 视频不可播放，正在尝试下一条');
      var ok = await this.play(candidates[i].song, candidates[i].index, { autoSkipBilibili: false });
      if (ok) return true;
      this.markFailed(candidates[i].song);
    }
    this.setStatus('当前队列没有其他可播放的 Bilibili 视频', true);
    return false;
  } finally {
    this.skipBusy = false;
  }
};

BilibiliVideoPlayer.prototype.bind = function () {
  var self = this;
  if (!this.root || !this.video) return;
  this.video.crossOrigin = 'anonymous';
  this.video.addEventListener('click', function () { self.toggle(); });
  this.video.addEventListener('playing', function () { self.updatePlayingState(true); });
  this.video.addEventListener('pause', function () {
    if (!self.loading && self.audioEl.paused) self.updatePlayingState(false);
  });
  this.video.addEventListener('error', function () {
    if (self.active && !self.audioOnly) self.setStatus('视频画面载入失败，可点击“音频播放”继续收听', true);
  });
  this.audioEl.addEventListener('playing', function () { self.updatePlayingState(true); });
  this.audioEl.addEventListener('pause', function () {
    if (!self.loading) self.updatePlayingState(false);
  });
  this.audioEl.addEventListener('ended', function () { self.handleEnded(); });
  this.audioEl.addEventListener('error', function () {
    if (self.active) {
      self.setStatus('Bilibili 音频流载入失败，正在切换下一条视频', true);
      if (!self.loading) self.skipToNextBilibili(self.queueIndex);
    }
  });
  document.addEventListener('fullscreenchange', function () {
    if (!self.root) return;
    self.root.classList.toggle('is-fullscreen', document.fullscreenElement === self.root);
  });
  document.addEventListener('keydown', function (event) {
    if (!self.active || event.defaultPrevented) return;
    if (event.key === 'Escape' && !document.fullscreenElement && self.isViewVisible()) self.hideVideoView();
  });
};

BilibiliVideoPlayer.prototype.isViewVisible = function () {
  return !!(this.root && this.root.classList.contains('show'));
};

BilibiliVideoPlayer.prototype.currentBilibiliAudioTrack = function () {
  if (this.active || !Array.isArray(playQueue) || !playQueue.length) return null;
  var index = Math.max(0, Math.min(playQueue.length - 1, Number(currentIdx) || 0));
  var song = playQueue[index];
  if (!song || !isBilibiliTrack(song)) return null;
  if (typeof audio === 'undefined' || !audio || !audio.src) return null;
  return { song: song, index: index };
};

BilibiliVideoPlayer.prototype.updateVideoModeButton = function () {
  var button = document.getElementById('video-mode-btn');
  if (!button) return;
  var audioTrack = this.currentBilibiliAudioTrack();
  var available = !!this.active || !!audioTrack;
  button.classList.toggle('available', available);
  button.classList.toggle('active', !!this.active && this.isViewVisible());
  button.setAttribute('aria-pressed', this.active && this.isViewVisible() ? 'true' : 'false');
  button.disabled = !available;
  button.title = this.active && this.isViewVisible() ? '当前正在显示 Bilibili 视频' : '切换到 Bilibili 视频播放';
  button.setAttribute('aria-label', button.title);
};

BilibiliVideoPlayer.prototype.showVideoView = function () {
  if (!this.active) {
    var audioTrack = this.currentBilibiliAudioTrack();
    if (audioTrack) return this.resumeVideoFromAudio(audioTrack.song, audioTrack.index);
    return false;
  }
  if (!this.root) return false;
  this.manualAudioOnly = false;
  this.audioOnly = false;
  this.root.classList.add('show');
  this.root.classList.remove('audio-only');
  this.root.setAttribute('aria-hidden', 'false');
  document.body.classList.add('bilibili-video-active');
  if (this.source && this.video && this.audioEl) {
    try { this.video.currentTime = Number(this.audioEl.currentTime || 0); } catch (_) { }
    if (!this.audioEl.paused) this.video.play().catch(function () { });
  }
  var audioModeButton = document.getElementById('bvp-audio-mode');
  var topAudioModeButton = document.getElementById('bvp-audio-mode-top');
  if (audioModeButton) audioModeButton.classList.remove('active');
  if (topAudioModeButton) topAudioModeButton.classList.remove('active');
  if (!this.loading) this.setStatus('', false);
  this.updateVideoModeButton();
  return true;
};

BilibiliVideoPlayer.prototype.resumeVideoFromAudio = async function (song, index) {
  if (!song || !isBilibiliTrack(song)) return false;
  var resumeAt = typeof audio !== 'undefined' && audio ? Number(audio.currentTime || 0) : 0;
  var preservePaused = typeof audio !== 'undefined' && audio ? audio.paused : false;
  var started = await this.play(song, index, { resumeAt: resumeAt, quality: 64, reopenedFromAudio: true });
  if (started && preservePaused) {
    this.audioEl.pause();
    this.video.pause();
    this.updatePlayingState(false);
  }
  return started;
};

BilibiliVideoPlayer.prototype.hideVideoView = function () {
  if (!this.active || !this.root) return false;
  this.audioOnly = true;
  this.video.pause();
  this.root.classList.remove('show', 'is-fullscreen');
  this.root.classList.add('audio-only');
  this.root.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('bilibili-video-active');
  if (document.fullscreenElement === this.root && document.exitFullscreen) document.exitFullscreen().catch(function () { });
  this.updateVideoModeButton();
  showToast('已退出视频模式，当前 Bilibili 音频继续播放');
  return true;
};

BilibiliVideoPlayer.prototype.captureAudioResumeContext = function () {
  if (this.active || typeof audio === 'undefined' || !audio || !audio.src) return;
  var key = audio.__mineradioQueueItemKey || '';
  var index = -1;
  if (key && Array.isArray(playQueue)) {
    for (var i = 0; i < playQueue.length; i++) {
      if (queueItemKey(playQueue[i]) === key) { index = i; break; }
    }
  }
  this.resumeContext = {
    media: audio,
    index: index,
    wasPlaying: !audio.paused && !audio.ended,
  };
};

BilibiliVideoPlayer.prototype.prepareUi = function (song) {
  var title = song && (song.name || song.title) || 'Bilibili 视频';
  var artist = song && song.artist || 'Bilibili';
  var cover = song && (song.artwork || song.cover) || '';
  document.getElementById('bvp-title').textContent = title;
  document.getElementById('bvp-artist').textContent = artist;
  document.getElementById('bvp-cover').src = cover;
  document.getElementById('bvp-poster').style.backgroundImage = cover ? 'url("' + String(cover).replace(/"/g, '%22') + '")' : '';
  var currentTimeLabel = document.getElementById('bvp-current');
  var totalTimeLabel = document.getElementById('bvp-total');
  var videoProgress = document.getElementById('bvp-progress');
  if (currentTimeLabel) currentTimeLabel.textContent = '0:00';
  if (totalTimeLabel) totalTimeLabel.textContent = this.formatTime(this.songDurationSeconds());
  if (videoProgress) videoProgress.value = '0';
  document.getElementById('bvp-quality-list').innerHTML = '';
  document.getElementById('bvp-quality-badge').textContent = 'AUTO';
  document.getElementById('bvp-resolution').textContent = '正在读取画质';
  document.getElementById('bvp-duration-meta').textContent = this.formatTime(this.songDurationSeconds());
  if (typeof updateControlTrackInfo === 'function') updateControlTrackInfo(song);
  if (typeof setControlCoverSrc === 'function') setControlCoverSrc(cover);
  if (typeof updateLikeButtons === 'function') updateLikeButtons(song);
  this.setStatus('正在准备 DASH 视频流', false);
};

BilibiliVideoPlayer.prototype.play = async function (song, index, opts) {
  opts = opts || {};
  if (!song || !isBilibiliTrack(song)) return false;
  var serial = ++this.serial;
  var playbackDeadline = Date.now() + 7950;
  if (this.active) await this.close(false);
  this.captureAudioResumeContext();
  if (typeof audio !== 'undefined' && audio && !audio.paused) {
    try { audio.pause(); } catch (_) { }
  }
  this.song = song;
  this.queueIndex = index;
  this.active = true;
  this.loading = true;
  this.audioOnly = false;
  this.manualAudioOnly = false;
  currentIdx = index;
  song.mediaType = 'video';
  song.musicFreePluginId = song.musicFreePluginId || MINERADIO_BILIBILI_PLUGIN_ID;
  song.musicFreePlatform = 'bilibili';
  song.musicFreeLabel = song.musicFreeLabel || 'bilibili';
  song.musicFreeSourceOnly = true;
  song.musicFreeFallbackPolicy = 'source-only';
  if (!song.musicFreeItem) song.musicFreeItem = { id: song.id || '', bvid: /^BV/i.test(String(song.id || '')) ? song.id : '' };
  playQueue[index] = song;
  this.prepareUi(song);
  this.showVideoView();
  if (!opts.reopenedFromAudio && !opts.skipAudioBootstrap) {
    this.setStatus('正在先解析 Bilibili 音乐，播放稳定后自动进入视频…', false);
    var audioBootstrapped = await this.playAudioOnlyAndExit();
    if (!audioBootstrapped) return false;
    // AudioPlayer has already confirmed playback at this point. Keep only one
    // short render tick before handing the same Bilibili item to VideoPlayer,
    // so the transition feels seamless without sacrificing the audio-first
    // warm-up that makes the DASH request reliable.
    await new Promise(function (resolve) { setTimeout(resolve, 50); });
    var currentSong = playQueue[index] || song;
    return await this.resumeVideoFromAudio(currentSong, index);
  }
  clearTimeout(this.videoFallbackTimer);
  this.videoFallbackTimer = setTimeout(function () {
    if (serial !== this.serial || !this.active || !this.loading) return;
    if (this.warmAudioActive && !this.audioEl.paused) {
      this.loading = false;
      this.audioOnly = true;
      this.root.classList.add('audio-only');
      this.setStatus('视频画面仍在准备，Bilibili 音乐继续播放', false);
      return;
    }
    showToast('视频在 8 秒内仍未准备完成，自动切换为 Bilibili 纯音频');
    this.playAudioOnlyAndExit();
  }.bind(this), 7800);
  safeRenderQueuePanel('bilibili-video-start', { scrollCurrent: miniQueueOpen });
  if (typeof saveLastPlaybackSnapshot === 'function') saveLastPlaybackSnapshot(true, 'bilibili-video-start');
  var warmAudioState = null;
  try {
    this.resolveInFlight = true;
    var data;
    try {
      data = await this.resolveSource(song, opts.quality || 64);
    } finally {
      if (serial === this.serial) this.resolveInFlight = false;
    }
    if (serial !== this.serial || !this.active) return false;
    if (!data || data.error || !data.proxyAudioUrl) throw new Error(data && data.error || 'BILIBILI_AUDIO_SOURCE_EMPTY');
    this.source = data;
    this.selectedQuality = String(data.selectedQuality || '');
    if (data.resolvedSong) {
      var merged = Object.assign({}, song, data.resolvedSong, { mediaType: 'video', musicFreePluginId: song.musicFreePluginId || MINERADIO_BILIBILI_PLUGIN_ID, musicFreePlatform: 'bilibili' });
      this.song = merged;
      playQueue[index] = merged;
    }
    this.renderQualities();
    warmAudioState = opts.reopenedFromAudio
      ? null
      : await this.startWarmAudio({ proxyUrl: data.proxyAudioUrl }, Number(opts.resumeAt || 0), serial).catch(function () { return null; });
    if (warmAudioState) {
      var warmupRemaining = Math.max(0, 1000 - (Date.now() - Number(warmAudioState.startedAt || 0)));
      if (warmupRemaining > 0) await new Promise(function (resolve) { setTimeout(resolve, warmupRemaining); });
    }
    var videoReady = warmAudioState
      ? await this.loadVideoOntoWarmAudio(data.proxyVideoUrl || '', playbackDeadline).catch(function () { return false; })
      : await this.loadStreams(data.proxyVideoUrl || '', data.proxyAudioUrl, Number(opts.resumeAt || 0), playbackDeadline, this.manualAudioOnly);
    if (serial !== this.serial || !this.active) return false;
    clearTimeout(this.videoFallbackTimer);
    this.videoFallbackTimer = 0;
    this.loading = false;
    if (!videoReady) {
      if (warmAudioState && !this.audioEl.paused) {
        this.audioOnly = true;
        this.root.classList.add('audio-only');
        this.setStatus('视频画面暂未就绪，Bilibili 音乐继续播放；可稍后切换视频模式', false);
        this.updateVideoModeButton();
        return true;
      }
      this.setStatus('视频流不可用，正在重新解析 Bilibili 音频', false);
      return await this.playAudioOnlyAndExit();
    }
    this.audioOnly = false;
    this.warmAudioActive = false;
    this.root.classList.toggle('audio-only', this.audioOnly);
    this.setStatus(this.audioOnly ? '视频画面不可用，已自动切换为仅音频播放' : '', false);
    await this.startPlayback();
    this.failedKeys.delete(this.songKey(this.song));
    if (typeof beginListenSession === 'function' && (!listenSession || listenSession.key !== this.songKey(this.song))) beginListenSession(this.song, activeRadioContext);
    this.prefetchNext();
    return true;
  } catch (error) {
    if (serial !== this.serial) return false;
    clearTimeout(this.videoFallbackTimer);
    this.videoFallbackTimer = 0;
    this.loading = false;
    this.setStatus('视频载入失败 · ' + String(error && error.message || error || '未知错误'), true);
    if (warmAudioState && !this.audioEl.paused) {
      this.audioOnly = true;
      this.root.classList.add('audio-only');
      this.setStatus('视频解析暂未完成，Bilibili 音乐继续播放', false);
      this.updatePlayingState(true);
      return true;
    }
    this.updatePlayingState(false);
    if (opts.autoSkipBilibili !== false && this.active) return await this.playAudioOnlyAndExit();
    return false;
  }
};

BilibiliVideoPlayer.prototype.loadStreams = async function (videoUrl, audioUrl, position, deadlineMs, forceAudioOnly) {
  this.stopSync();
  this.video.pause();
  this.audioEl.pause();
  if (videoUrl) this.video.src = videoUrl;
  else this.video.removeAttribute('src');
  this.audioEl.src = audioUrl;
  var speedControl = document.getElementById('bvp-speed');
  this.video.playbackRate = Number(speedControl && speedControl.value || 1);
  this.audioEl.playbackRate = this.video.playbackRate;
  var sharedVolume = typeof targetVolume === 'number' ? targetVolume : 0.85;
  this.audioEl.volume = Math.max(0, Math.min(1, sharedVolume));
  if (videoUrl) this.video.load();
  this.audioEl.load();
  var remaining = function () { return Math.max(250, Number(deadlineMs || Date.now() + 6000) - Date.now()); };
  var videoMetadata = videoUrl ? this.waitForMetadata(this.video, Math.min(2200, remaining())).then(function () { return true; }).catch(function () { return false; }) : Promise.resolve(false);
  await this.waitForMetadata(this.audioEl, Math.min(5200, remaining()));
  var videoReady = forceAudioOnly ? false : await Promise.race([
    videoMetadata,
    new Promise(function (resolve) { setTimeout(function () { resolve(false); }, Math.min(900, remaining())); }),
  ]);
  var duration = this.durationSeconds();
  var target = Math.max(0, Math.min(Number(position) || 0, duration > 0 ? Math.max(0, duration - 0.25) : Number(position) || 0));
  if (target > 0) {
    this.video.currentTime = target;
    this.audioEl.currentTime = target;
  }
  this.updateProgress();
  return !!videoReady;
};

BilibiliVideoPlayer.prototype.waitForMetadata = function (media, timeoutMs) {
  if (media.readyState >= 1) return Promise.resolve(true);
  return new Promise(function (resolve, reject) {
    var timer = setTimeout(function () { cleanup(); reject(new Error('DASH_METADATA_TIMEOUT')); }, Math.max(250, Number(timeoutMs || 3500)));
    function cleanup() {
      clearTimeout(timer);
      media.removeEventListener('loadedmetadata', ready);
      media.removeEventListener('error', failed);
    }
    function ready() { cleanup(); resolve(true); }
    function failed() { cleanup(); reject(new Error('DASH_STREAM_LOAD_FAILED')); }
    media.addEventListener('loadedmetadata', ready, { once: true });
    media.addEventListener('error', failed, { once: true });
  });
};

BilibiliVideoPlayer.prototype.startPlayback = async function () {
  if (!this.active) return false;
  this.loading = false;
  var audioPlay = this.audioEl.play();
  var videoPlay = this.audioOnly ? Promise.resolve() : this.video.play();
  var results = await Promise.allSettled([audioPlay, videoPlay]);
  if (results[0].status === 'rejected') {
    this.setStatus('点击画面开始播放', false);
    this.updatePlayingState(false);
    return false;
  }
  this.startSync();
  this.updatePlayingState(true);
  return true;
};

BilibiliVideoPlayer.prototype.toggle = async function () {
  if (!this.active || this.loading) return false;
  if (this.audioEl.paused || this.audioEl.ended) return this.startPlayback();
  this.audioEl.pause();
  this.video.pause();
  this.stopSync();
  this.updatePlayingState(false);
  return true;
};

BilibiliVideoPlayer.prototype.startSync = function () {
  var self = this;
  this.stopSync();
  this.syncTimer = setInterval(function () {
    if (!self.active) return;
    self.updateProgress();
    if (self.audioOnly || self.audioEl.paused || self.video.paused) return;
    var drift = Number(self.video.currentTime || 0) - Number(self.audioEl.currentTime || 0);
    if (Math.abs(drift) > 0.22) self.video.currentTime = self.audioEl.currentTime;
  }, 160);
};

BilibiliVideoPlayer.prototype.stopSync = function () {
  if (this.syncTimer) clearInterval(this.syncTimer);
  this.syncTimer = 0;
};

BilibiliVideoPlayer.prototype.updateProgress = function () {
  if (!this.active) return;
  var current = Number(this.audioEl.currentTime || 0);
  var duration = this.durationSeconds();
  var currentTimeLabel = document.getElementById('bvp-current');
  var totalTimeLabel = document.getElementById('bvp-total');
  var videoProgress = document.getElementById('bvp-progress');
  if (currentTimeLabel) currentTimeLabel.textContent = this.formatTime(current);
  if (totalTimeLabel) totalTimeLabel.textContent = this.formatTime(duration);
  document.getElementById('bvp-duration-meta').textContent = this.formatTime(duration);
  if (videoProgress) videoProgress.value = duration > 0 ? String(Math.round(current / duration * 1000)) : '0';
  if (typeof setProgressVisual === 'function') setProgressVisual(duration > 0 ? current / duration * 100 : 0);
  var sharedTime = document.getElementById('time-display');
  if (sharedTime && typeof formatProgramTime === 'function') sharedTime.textContent = formatProgramTime(current) + ' / ' + formatProgramTime(duration);
};

BilibiliVideoPlayer.prototype.seekFromSlider = function (value) {
  var duration = this.durationSeconds();
  if (!duration) return;
  var target = Math.max(0, Math.min(duration, Number(value || 0) / 1000 * duration));
  this.audioEl.currentTime = target;
  this.video.currentTime = target;
  this.updateProgress();
};

BilibiliVideoPlayer.prototype.setVolume = function (value) {
  this.audioEl.volume = Math.max(0, Math.min(1, Number(value) || 0));
  var slider = document.getElementById('bvp-volume');
  if (slider && Math.abs(Number(slider.value) - this.audioEl.volume) > 0.001) slider.value = String(this.audioEl.volume);
};

BilibiliVideoPlayer.prototype.setSpeed = function (value) {
  var speed = Math.max(0.5, Math.min(2, Number(value) || 1));
  this.audioEl.playbackRate = speed;
  this.video.playbackRate = speed;
};

BilibiliVideoPlayer.prototype.toggleAudioOnly = function () {
  if (!this.active) return;
  this.audioOnly = !this.audioOnly;
  this.root.classList.toggle('audio-only', this.audioOnly);
  var audioModeButton = document.getElementById('bvp-audio-mode');
  var topAudioModeButton = document.getElementById('bvp-audio-mode-top');
  if (audioModeButton) audioModeButton.classList.toggle('active', this.audioOnly);
  if (topAudioModeButton) topAudioModeButton.classList.toggle('active', this.audioOnly);
  if (this.audioOnly) {
    this.video.pause();
    this.setStatus('后台音频模式 · 视频画面已暂停', false);
  } else {
    this.video.currentTime = this.audioEl.currentTime || 0;
    if (!this.audioEl.paused) this.video.play().catch(function () { });
    this.setStatus('', false);
  }
};

function applyBilibiliMultipartQueue(index, originalSong, data) {
  var parts = Array.isArray(data && data.parts) ? data.parts : [];
  if (parts.length < 2 || index < 0 || index >= playQueue.length) return originalSong;
  var originalKey = String(originalSong && (originalSong.bvid || originalSong.id || '') || '');
  var normalized = parts.map(function (part, partIndex) {
    var next = Object.assign({}, originalSong || {}, part || {});
    next.mediaType = 'video';
    next.musicFreePluginId = originalSong.musicFreePluginId || MINERADIO_BILIBILI_PLUGIN_ID;
    next.musicFreePlatform = 'bilibili';
    next.musicFreeLabel = originalSong.musicFreeLabel || 'bilibili';
    next.musicFreeSourceOnly = true;
    next.musicFreeFallbackPolicy = 'source-only';
    next.musicFreeAlternates = [];
    next.bilibiliMultipartRoot = originalKey;
    next.bilibiliPartIndex = partIndex + 1;
    next.bilibiliPartCount = parts.length;
    var durationMs = Number(next.durationMs || next.duration || 0) || 0;
    if (durationMs > 0) {
      next.durationMs = durationMs;
      next.duration = durationMs;
      next.dt = durationMs;
    }
    return next;
  });
  playQueue.splice.apply(playQueue, [index, 1].concat(normalized));
  if (typeof saveQueueSnapshot === 'function') saveQueueSnapshot();
  safeRenderQueuePanel('bilibili-multipart-expanded', { scrollCurrent: miniQueueOpen });
  showToast('已识别 Bilibili 分P合集，共 ' + normalized.length + ' 段，将按完整顺序播放');
  return playQueue[index];
}

BilibiliVideoPlayer.prototype.playAudioOnlyAndExit = async function () {
  if (!this.active) return false;
  clearTimeout(this.videoFallbackTimer);
  this.videoFallbackTimer = 0;
  var song = this.song || playQueue[this.queueIndex];
  var index = this.queueIndex;
  var resumeAt = Math.max(Number(this.audioEl && this.audioEl.currentTime || 0), Number(this.video && this.video.currentTime || 0));
  showToast('视频未就绪，正在单独解析 Bilibili 音频…');
  await this.close(false);
  if (!song || index < 0 || index >= playQueue.length) return false;
  song.mediaType = 'video';
  song.musicFreePluginId = song.musicFreePluginId || MINERADIO_BILIBILI_PLUGIN_ID;
  song.musicFreePlatform = 'bilibili';
  song.musicFreeSourceOnly = true;
  song.musicFreeFallbackPolicy = 'source-only';
  song.musicFreeAlternates = [];
  song.provider = 'musicfree';
  song.source = 'musicfree';
  song.type = 'musicfree';
  song._resolveWithMusicFree = false;
  playQueue[index] = song;
  try {
    var audioData = await apiJson('/api/musicfree/bilibili-audio', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ song: song, quality: 'original' }),
      timeoutMs: 7000,
    });
    if (!audioData || audioData.error || !audioData.url || !audioData.proxyUrl || audioData.fallbackUsed || Number(audioData.attemptedSources || 0) !== 1 || String(audioData.source || '').toLowerCase() !== 'bilibili') {
      throw new Error(audioData && audioData.error || 'BILIBILI_AUDIO_SOURCE_ISOLATION_FAILED');
    }
    song = applyBilibiliMultipartQueue(index, song, audioData);
    if (audioData.durationMs > 0) {
      song.durationMs = Number(audioData.durationMs);
      song.duration = Number(audioData.durationMs);
      song.dt = Number(audioData.durationMs);
      playQueue[index] = song;
    }
    var started = await playAudioQueueAt(index, {
      manual: true,
      bilibiliAudioFallback: true,
      resumeAt: resumeAt,
      preResolvedPlaybackData: audioData,
      suppressPlayFailureNotice: true,
    });
    if (started === true) {
      this.updateVideoModeButton();
      showToast('已切换为 Bilibili 纯音频播放');
      return true;
    }
  } catch (_) { }
  showToast('当前 Bilibili 音频不可用，正在尝试下一条视频');
  if (typeof this.skipToNextBilibili === 'function') return await this.skipToNextBilibili(index);
  return false;
};

BilibiliVideoPlayer.prototype.switchQuality = async function (qualityId) {
  if (!this.active || !this.source || this.loading || String(qualityId) === this.selectedQuality) return;
  var quality = (this.source.qualities || []).find(function (item) { return String(item.id) === String(qualityId); });
  if (!quality || !quality.proxyVideoUrl) return;
  var position = Number(this.audioEl.currentTime || 0);
  var wasPlaying = !this.audioEl.paused;
  this.loading = true;
  this.setStatus('正在切换到 ' + (quality.label || quality.id), false);
  try {
    this.video.pause();
    this.video.src = quality.proxyVideoUrl;
    this.video.load();
    await this.waitForMetadata(this.video);
    this.video.currentTime = position;
    this.video.playbackRate = this.audioEl.playbackRate;
    this.selectedQuality = String(quality.id);
    this.renderQualities();
    if (wasPlaying && !this.audioOnly) await this.video.play();
    this.setStatus('', false);
  } catch (error) {
    this.setStatus('清晰度切换失败，音频继续播放', true);
  } finally {
    this.loading = false;
  }
};

BilibiliVideoPlayer.prototype.renderQualities = function () {
  var self = this;
  var list = document.getElementById('bvp-quality-list');
  var qualities = this.source && Array.isArray(this.source.qualities) ? this.source.qualities : [];
  list.innerHTML = '';
  qualities.forEach(function (item) {
    var button = document.createElement('button');
    button.type = 'button';
    button.textContent = item.label || item.id;
    button.className = String(item.id) === self.selectedQuality ? 'active' : '';
    button.addEventListener('click', function () { self.switchQuality(item.id); });
    list.appendChild(button);
  });
  var selected = qualities.find(function (item) { return String(item.id) === self.selectedQuality; }) || qualities[0];
  document.getElementById('bvp-quality-badge').textContent = selected && selected.label || 'AUTO';
  document.getElementById('bvp-resolution').textContent = selected ? [selected.width && selected.height ? selected.width + '×' + selected.height : '', selected.codecs || ''].filter(Boolean).join(' · ') : '—';
  var sharedQuality = document.getElementById('quality-btn-label');
  if (sharedQuality) sharedQuality.textContent = selected && selected.label || 'VIDEO';
};

BilibiliVideoPlayer.prototype.toggleFullscreen = function () {
  if (!this.root) return;
  if (document.fullscreenElement === this.root) {
    if (document.exitFullscreen) document.exitFullscreen();
    return;
  }
  if (this.root.requestFullscreen) this.root.requestFullscreen().catch(function () { });
};

BilibiliVideoPlayer.prototype.close = async function (resumePreviousAudio) {
  if (!this.active && !this.root.classList.contains('show')) return false;
  ++this.serial;
  clearTimeout(this.videoFallbackTimer);
  this.videoFallbackTimer = 0;
  if (typeof listenSession !== 'undefined' && listenSession && this.song && listenSession.key === this.songKey(this.song) && typeof finalizeListenSession === 'function') finalizeListenSession(false);
  this.stopSync();
  this.active = false;
  this.loading = false;
  this.warmAudioActive = false;
  this.video.pause();
  this.audioEl.pause();
  this.video.removeAttribute('src');
  this.audioEl.removeAttribute('src');
  this.video.load();
  this.audioEl.load();
  if (document.fullscreenElement === this.root && document.exitFullscreen) {
    try { await document.exitFullscreen(); } catch (_) { }
  }
  this.root.classList.remove('show', 'audio-only', 'is-fullscreen');
  this.root.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('bilibili-video-active');
  this.updateVideoModeButton();
  this.updatePlayingState(false);
  var resume = this.resumeContext;
  this.source = null;
  this.song = null;
  this.queueIndex = -1;
  this.resumeContext = null;
  if (resumePreviousAudio && resume && resume.media && resume.media.src && resume.wasPlaying) {
    if (resume.index >= 0 && resume.index < playQueue.length) currentIdx = resume.index;
    try {
      var resumeSong = resume.index >= 0 ? playQueue[resume.index] : null;
      if (resumeSong && typeof updateControlTrackInfo === 'function') updateControlTrackInfo(resumeSong);
      if (resumeSong && typeof setControlCoverSrc === 'function') setControlCoverSrc(resumeSong.artwork || resumeSong.cover || '');
      if (resumeSong && typeof updateLikeButtons === 'function') updateLikeButtons(resumeSong);
      await resume.media.play();
      playing = true;
      setPlayIcon(true);
      safeRenderQueuePanel('bilibili-video-resume-audio', { scrollCurrent: miniQueueOpen });
      return true;
    } catch (_) {
      showToast('视频已关闭，点击播放按钮继续音乐');
    }
  }
  return true;
};

BilibiliVideoPlayer.prototype.handleEnded = function () {
  if (!this.active) return;
  if (typeof finalizeListenSession === 'function') finalizeListenSession(true);
  this.updatePlayingState(false);
  if (playMode === 'single') {
    this.audioEl.currentTime = 0;
    this.video.currentTime = 0;
    this.startPlayback();
    return;
  }
  nextTrack(false);
};

BilibiliVideoPlayer.prototype.updatePlayingState = function (isPlaying) {
  playing = !!isPlaying;
  setPlayIcon(!!isPlaying);
  var markup = isPlaying
    ? '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>'
    : '<path d="M8 5v14l11-7z"/>';
  var playButton = document.querySelector('#bvp-play svg');
  var centerButton = document.querySelector('#bvp-center-play svg');
  if (playButton) playButton.innerHTML = markup;
  if (centerButton) centerButton.innerHTML = markup;
  this.root.classList.toggle('is-playing', !!isPlaying);
};

BilibiliVideoPlayer.prototype.setStatus = function (message, error) {
  var status = document.getElementById('bvp-status');
  status.classList.toggle('show', !!message);
  status.classList.toggle('error', !!error);
  status.querySelector('b').textContent = message || '';
  status.querySelector('.bvp-spinner').style.display = error ? 'none' : '';
};

BilibiliVideoPlayer.prototype.durationSeconds = function () {
  if (isFinite(this.audioEl.duration) && this.audioEl.duration > 0) return Number(this.audioEl.duration);
  if (this.source && Number(this.source.durationMs) > 0) return Number(this.source.durationMs) / 1000;
  return this.songDurationSeconds();
};

BilibiliVideoPlayer.prototype.songDurationSeconds = function () {
  var value = Number(this.song && (this.song.durationMs || this.song.duration) || 0);
  return value > 10000 ? value / 1000 : value;
};

BilibiliVideoPlayer.prototype.formatTime = function (seconds) {
  seconds = Math.max(0, Number(seconds) || 0);
  var hours = Math.floor(seconds / 3600);
  var minutes = Math.floor(seconds % 3600 / 60);
  var rest = Math.floor(seconds % 60);
  return (hours ? hours + ':' + String(minutes).padStart(2, '0') : minutes) + ':' + String(rest).padStart(2, '0');
};

var bilibiliVideoPlayer = new BilibiliVideoPlayer();
var mediaManager = {
  async playQueueAt(index, opts) {
    opts = opts || {};
    if (index < 0 || index >= playQueue.length) return false;
    var song = playQueue[index];
    var mediaType = mineradioMediaType(song);
    song.mediaType = mediaType;
    if (mediaType === 'video') return bilibiliVideoPlayer.play(song, index, opts);
    if (bilibiliVideoPlayer.active) await bilibiliVideoPlayer.close(false);
    var started = await playAudioQueueAt(index, opts);
    bilibiliVideoPlayer.updateVideoModeButton();
    if (started && playQueue.length > 1) bilibiliVideoPlayer.prefetch(playQueue[(index + 1) % playQueue.length]);
    return started;
  },
};

async function playQueueAt(index, opts) {
  return mediaManager.playQueueAt(index, opts);
}
