'use strict';

const { ERROR_CODES, MusicFreeRuntimeError } = require('./errors');

const METHOD_ALIASES = Object.freeze({
  search: ['search', 'searchMusic', 'searchSong', 'searchSongs'],
  getMediaSource: ['getMediaSource', 'getPlayUrl', 'getMusicUrl', 'resolveUrl', 'getUrl'],
  getVideoSource: ['getVideoSource'],
  getMusicInfo: ['getMusicInfo', 'getSongInfo', 'getTrackInfo', 'getMusicDetail'],
  getLyric: ['getLyric', 'getLyrics', 'getLrc'],
  getAlbumInfo: ['getAlbumInfo'],
  getArtistWorks: ['getArtistWorks'],
  getMusicSheetInfo: ['getMusicSheetInfo', 'getPlaylistInfo'],
  importMusicSheet: ['importMusicSheet', 'importPlaylist'],
  getRecommendSheetTags: ['getRecommendSheetTags'],
  getRecommendSheetsByTag: ['getRecommendSheetsByTag'],
  getTopLists: ['getTopLists', 'getTopList'],
  getTopListDetail: ['getTopListDetail'],
  getComments: ['getComments'],
  getSuggest: ['getSuggest'],
});

function normalizeExport(value) {
  let result = value;
  const visited = new Set();
  while (result && typeof result === 'object' && !visited.has(result)) {
    visited.add(result);
    if (result.default && typeof result.default === 'object') result = result.default;
    else if (result.plugin && typeof result.plugin === 'object') result = result.plugin;
    else break;
  }
  return result;
}

function resultItems(result) {
  if (Array.isArray(result)) return result;
  if (!result || typeof result !== 'object') return [];
  const queue = [result];
  const seen = new Set();
  const keys = ['musicList', 'data', 'items', 'list', 'songs', 'tracks', 'results', 'result'];
  while (queue.length) {
    const current = queue.shift();
    if (!current || typeof current !== 'object' || seen.has(current)) continue;
    seen.add(current);
    if (Array.isArray(current)) return current;
    for (const key of keys) {
      if (Array.isArray(current[key])) return current[key];
      if (current[key] && typeof current[key] === 'object') queue.push(current[key]);
    }
  }
  return [];
}

function normalizeMedia(result) {
  if (typeof result === 'string') return { url: result, headers: {} };
  if (!result || typeof result !== 'object') return null;
  const nested = result.data && typeof result.data === 'object' ? result.data : null;
  const source = result.url || result.playUrl || result.src ? result : nested;
  if (!source) return null;
  const url = String(source.url || source.playUrl || source.src || '').trim();
  if (!url) return null;
  return {
    url,
    headers: Object.assign({}, source.headers || source.header || {}),
    userAgent: String(source.userAgent || source.ua || ''),
    quality: String(source.quality || source.level || ''),
    format: String(source.format || source.type || ''),
    durationMs: Math.max(0, Number(source.durationMs || source.timelength || source.duration || 0) || 0),
    segments: Array.isArray(source.segments) ? source.segments.map(segment => ({
      url: String(segment && (segment.url || segment.src) || ''),
      durationMs: Math.max(0, Number(segment && (segment.durationMs || segment.length || segment.duration) || 0) || 0),
      size: Math.max(0, Number(segment && segment.size || 0) || 0),
    })).filter(segment => segment.url) : [],
    raw: result,
  };
}

function normalizeVideoSource(result) {
  if (!result || typeof result !== 'object') return null;
  const source = result.data && typeof result.data === 'object' ? result.data : result;
  const headers = Object.assign({}, source.headers || source.header || {});
  const qualities = (Array.isArray(source.qualities) ? source.qualities : []).map(item => ({
    id: String(item && (item.id || item.quality || item.qn) || ''),
    label: String(item && (item.label || item.name || item.description) || ''),
    width: Math.max(0, Number(item && item.width || 0) || 0),
    height: Math.max(0, Number(item && item.height || 0) || 0),
    bandwidth: Math.max(0, Number(item && (item.bandwidth || item.bandWidth) || 0) || 0),
    codecs: String(item && (item.codecs || item.codec) || ''),
    mimeType: String(item && (item.mimeType || item.mime) || 'video/mp4'),
    videoUrl: String(item && (item.videoUrl || item.url || item.baseUrl || item.base_url) || ''),
    videoUrls: (Array.isArray(item && item.videoUrls) ? item.videoUrls : []).map(String).filter(Boolean),
  })).filter(item => item.videoUrl);
  const selectedQuality = String(source.selectedQuality || source.quality || source.qn || qualities[0] && qualities[0].id || '');
  const selected = qualities.find(item => item.id === selectedQuality) || qualities[0] || null;
  const videoUrl = String(source.videoUrl || source.url || selected && selected.videoUrl || '').trim();
  const audioUrl = String(source.audioUrl || source.audio || '').trim();
  if (!audioUrl) return null;
  return {
    videoUrl,
    videoUrls: (Array.isArray(source.videoUrls) ? source.videoUrls : []).map(String).filter(Boolean),
    audioUrl,
    audioUrls: (Array.isArray(source.audioUrls) ? source.audioUrls : []).map(String).filter(Boolean),
    headers,
    durationMs: Math.max(0, Number(source.durationMs || source.timelength || source.duration || 0) || 0),
    selectedQuality: selected && selected.id || selectedQuality,
    qualityLabel: String(source.qualityLabel || ''),
    qualities: qualities.length ? qualities : (videoUrl ? [{ id: selectedQuality || 'auto', label: String(source.qualityLabel || ''), videoUrl }] : []),
    audio: {
      bandwidth: Math.max(0, Number(source.audioBandwidth || source.audioBitrate || 0) || 0),
      codecs: String(source.audioCodecs || source.audioCodec || ''),
      mimeType: String(source.audioMimeType || 'audio/mp4'),
    },
    raw: result,
  };
}

class PluginAdapter {
  constructor(plugin, metadata = {}) {
    this.plugin = normalizeExport(plugin);
    if (!this.plugin || typeof this.plugin !== 'object') {
      throw new MusicFreeRuntimeError(ERROR_CODES.INVALID_EXPORT, '插件没有导出有效对象');
    }
    this.metadata = Object.assign({}, metadata, {
      platform: String(this.plugin.platform || metadata.platform || metadata.label || ''),
      version: String(this.plugin.version || metadata.version || '0.0.0'),
      author: String(this.plugin.author || metadata.author || ''),
    });
    this.methods = {};
    for (const [capability, aliases] of Object.entries(METHOD_ALIASES)) {
      const name = aliases.find(alias => typeof this.plugin[alias] === 'function');
      if (name) this.methods[capability] = name;
    }
    if (!Object.keys(this.methods).length) {
      throw new MusicFreeRuntimeError(ERROR_CODES.INVALID_EXPORT, '插件没有实现可识别的 MusicFree 功能接口');
    }
  }

  has(capability) { return !!this.methods[capability]; }
  methodName(capability) { return this.methods[capability] || ''; }
  capabilities() { return Object.keys(this.methods); }

  async call(capability, ...args) {
    const method = this.methods[capability];
    if (!method) throw new MusicFreeRuntimeError(ERROR_CODES.UNSUPPORTED, '插件不支持 ' + capability, { capability });
    return this.plugin[method].apply(this.plugin, args);
  }

  async search(query, page = 1, type = 'music') {
    const result = await this.call('search', String(query || ''), Math.max(1, Number(page) || 1), type);
    return { items: resultItems(result), isEnd: !!(result && result.isEnd === true), raw: result };
  }

  async media(item, quality) {
    return normalizeMedia(await this.call('getMediaSource', item, quality));
  }

  async video(item, quality) {
    return normalizeVideoSource(await this.call('getVideoSource', item, quality));
  }
}

module.exports = { PluginAdapter, METHOD_ALIASES, normalizeExport, resultItems, normalizeMedia, normalizeVideoSource };
