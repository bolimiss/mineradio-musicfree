# MineRadio Universal Music Import Layer

This subsystem owns only link receipt, metadata normalization, playlist persistence and synchronization. It deliberately does not import or call playback URLs, players, MusicFree media resolution or lyrics.

## HTTP contract

- `POST /api/universal-import/import` with `{ "text": "shared text or URL", "receiver": "web|windows-web|android-action-send|ios-share-extension" }`
- `POST /api/universal-import/preview` parses without saving.
- `POST /api/universal-import/migrate` converts legacy browser-stored playlists to the metadata-only database model.
- `GET /api/universal-import/playlists` returns the database and scheduler status.
- `POST /api/universal-import/playlists/:id/sync` runs an on-demand diff sync.
- `POST /api/universal-import/sync-all` syncs all enabled imports.
- `DELETE /api/universal-import/playlists/:id` removes an imported playlist.
- `GET /api/universal-import/test-center` returns import success, failure and timing statistics.

The server scheduler ticks every five seconds, prevents overlapping cycles, and stores added/removed/updated counts. Mobile fragments are integration contracts because this Electron source tree contains no Android or iOS build target.
