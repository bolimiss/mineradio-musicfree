'use strict';

var MUSICFREE_DEFAULT_MANIFEST_URL = 'https://13413.kstore.vip/yuanli/yuanli.json';
var musicFreePlugins = [];
var currentMusicFreePluginFilter = '';
var musicFreeImportBusy = false;
var expandedMusicFreeGroups = Object.create(null);

function openGsapModal(mask) {
  if (!mask) return;
  var panel = mask.querySelector('.modal');
  mask.classList.add('show');
  if (window.gsap) {
    window.gsap.killTweensOf(mask);
    if (panel) window.gsap.killTweensOf(panel);
    window.gsap.set(mask, { display: 'flex', visibility: 'visible' });
    window.gsap.fromTo(mask, { autoAlpha: 0 }, { autoAlpha: 1, duration: .3, ease: 'power2.out', overwrite: true });
    if (panel) window.gsap.fromTo(panel,
      { autoAlpha: 0, y: 22, scale: .97, filter: 'blur(10px)' },
      { autoAlpha: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: .5, ease: 'expo.out', overwrite: true });
  } else {
    mask.style.display = 'flex';
    mask.style.visibility = 'visible';
    mask.style.opacity = '1';
  }
}

function closeGsapModal(mask, afterClose) {
  if (!mask || !mask.classList.contains('show')) {
    if (afterClose) afterClose();
    return;
  }
  var panel = mask.querySelector('.modal');
  function finish() {
    mask.classList.remove('show');
    mask.style.display = '';
    mask.style.visibility = '';
    mask.style.opacity = '';
    if (afterClose) afterClose();
  }
  if (window.gsap) {
    if (panel) window.gsap.to(panel, { autoAlpha: 0, y: 16, scale: .98, duration: .2, overwrite: true });
    window.gsap.to(mask, { autoAlpha: 0, duration: .24, overwrite: true, onComplete: finish });
  } else finish();
}

function bindModalBackdropClose() {
  [
    ['track-detail-modal', typeof closeTrackDetailModal === 'function' ? closeTrackDetailModal : null],
    ['audio-output-workflow-modal', typeof closeAudioOutputWorkflowPanel === 'function' ? closeAudioOutputWorkflowPanel : null],
    ['custom-lyric-modal', typeof closeCustomLyricModal === 'function' ? closeCustomLyricModal : null],
    ['update-modal', typeof closeUpdatePanel === 'function' ? closeUpdatePanel : null],
    ['musicfree-source-modal', closeMusicFreeSourceManager],
    ['musicfree-diagnostic-modal', closeMusicFreeDiagnosticCenter],
    ['musicfree-config-modal', closeMusicFreeConfigModal]
  ].forEach(function (pair) {
    var mask = document.getElementById(pair[0]);
    var close = pair[1];
    if (!mask || !close || mask.__backdropCloseBound) return;
    mask.__backdropCloseBound = true;
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
  });
}

// Removed account modules used to provide these helpers. Keep compatibility
// for unrelated playback/history code without creating any login entry point.
function platformStatus() { return { loggedIn: false, capabilities: {} }; }
function platformMeta(provider) { return { key: provider, label: String(provider || '音源').toUpperCase() }; }
function hasPlatformLogin() { return false; }
function hasAnyPlatformLogin() { return false; }
function hasProviderVip() { return false; }
function hasProviderSvip() { return false; }
function firstLoggedProvider() { return ''; }
function refreshLoginStatus() { return Promise.resolve(loginStatus); }
function refreshQQLoginStatus() { return Promise.resolve(qqLoginStatus); }
function refreshKugouLoginStatus() { return Promise.resolve(kugouLoginStatus); }
function refreshQishuiLoginStatus() { return Promise.resolve(qishuiLoginStatus); }
function refreshSpotifyLoginStatus() { return Promise.resolve(spotifyLoginStatus); }
function startQQLoginStatusAutoRefresh() { }
function startKugouLoginStatusAutoRefresh() { }
function startQishuiLoginStatusAutoRefresh() { }
function startSpotifyLoginStatusAutoRefresh() { }
function renderUserBtn() { }
function bindTopAccountPillSorting() { }
function maybeRunStartupLoginGuide() { return false; }
function prepareLoginEasterEggGate() { return Promise.resolve(true); }
function applyKugouPlaybackStatusEvidence() { }
function applyQQPlaybackStatusEvidence() { }
function qqLoginNeedsAuthorizationRefresh() { return false; }
function qqMembershipNeedsSync() { return false; }
function openProviderLogin() { openMusicFreeSourceManager(); }
function showLoginModal() { openMusicFreeSourceManager(); }

function musicFreeApi(url, options) {
  options = options || {};
  return apiJson(url, options);
}

function ensureMusicFreeSourceControls() {
  if (document.getElementById('musicfree-local-import')) return;
  var panel = document.getElementById('fx-panel');
  if (!panel) return;
  var local = document.createElement('div');
  local.id = 'musicfree-local-import';
  local.className = 'musicfree-source-setting';
  local.innerHTML =
    '<button class="musicfree-source-entry" type="button" onclick="chooseLocalMusicFreeSource()">' +
      '<span class="musicfree-source-icon">＋</span><span><b>本地导入音源</b><small>选择 MusicFree .js / .json / .zip 音源文件</small></span><i>›</i>' +
    '</button>' +
    '<input id="musicfree-local-input" type="file" accept=".js,.json,.zip,application/javascript,application/json,application/zip" multiple hidden>';
  var network = document.createElement('div');
  network.id = 'musicfree-network-import';
  network.className = 'musicfree-source-setting';
  network.innerHTML =
    '<button class="musicfree-source-entry" type="button" onclick="openMusicFreeSourceManager()">' +
      '<span class="musicfree-source-icon">↗</span><span><b>网络导入音源</b><small id="musicfree-source-count">正在读取当前音源…</small></span><i>›</i>' +
    '</button>';
  panel.appendChild(local);
  panel.appendChild(network);
  var input = local.querySelector('#musicfree-local-input');
  input.addEventListener('change', function () { importLocalMusicFreeFiles(input.files); input.value = ''; });
}

function ensureMusicFreeSourceManager() {
  var mask = document.getElementById('musicfree-source-modal');
  if (mask) return mask;
  mask = document.createElement('div');
  mask.id = 'musicfree-source-modal';
  mask.className = 'modal-mask';
  mask.innerHTML =
    '<div class="modal musicfree-source-modal">' +
      '<div class="musicfree-source-head"><div><small>MUSICFREE PLUGINS</small><h2>音源管理</h2><p>支持 MusicFree CommonJS、JSON 清单和 QingMusic 线路配置。</p></div>' +
      '<button type="button" onclick="closeMusicFreeSourceManager()" aria-label="关闭">×</button></div>' +
      '<label class="musicfree-network-box"><span>网络音源地址</span><div><input id="musicfree-network-url" type="url" spellcheck="false"><button id="musicfree-network-submit" type="button" onclick="importNetworkMusicFreeSource()">导入</button></div></label>' +
      '<div class="musicfree-source-toolbar"><button type="button" onclick="chooseLocalMusicFreeSource()">选择本地插件</button><button type="button" onclick="reloadMusicFreeSources()">重新加载</button></div>' +
      '<div id="musicfree-source-status" class="musicfree-source-status" aria-live="polite"></div>' +
      '<div id="musicfree-source-list" class="musicfree-source-list"></div>' +
    '</div>';
  document.body.appendChild(mask);
  mask.querySelector('#musicfree-network-url').value = '';
  mask.addEventListener('click', function (event) { if (event.target === mask) closeMusicFreeSourceManager(); });
  return mask;
}

function musicFreeSourceStatus(text, error) {
  var status = document.getElementById('musicfree-source-status');
  if (!status) return;
  status.textContent = text || '';
  status.classList.toggle('error', !!error);
}

function musicFreeSearchPluginParam() {
  return currentMusicFreePluginFilter ? ('&plugin=' + encodeURIComponent(currentMusicFreePluginFilter)) : '';
}

function setMusicFreeSearchPlugin(id) {
  currentMusicFreePluginFilter = String(id || '');
  renderMusicFreeSearchTags();
  var input = document.getElementById('search-input');
  if (input && input.value.trim() && typeof doSearch === 'function') doSearch(input.value.trim());
}

function playableMusicFreeSearchPlugins() {
  return musicFreePlugins.filter(function (plugin) {
    return plugin && plugin.loaded && plugin.searchable && plugin.playable && plugin.configured !== false && plugin.enabled !== false;
  });
}

function renderMusicFreeSearchTags() {
  var tabs = document.getElementById('search-mode-tabs');
  var input = document.getElementById('search-input');
  if (!tabs) return;
  var usablePlugins = playableMusicFreeSearchPlugins();
  if (currentMusicFreePluginFilter && !usablePlugins.some(function (plugin) { return plugin.id === currentMusicFreePluginFilter; })) {
    currentMusicFreePluginFilter = '';
  }
  tabs.setAttribute('aria-label', '当前 MusicFree 音源');
  tabs.innerHTML =
    '<button class="musicfree-tag' + (!currentMusicFreePluginFilter ? ' active' : '') + '" type="button" onclick="setMusicFreeSearchPlugin(\'\')">全部</button>' +
    usablePlugins.map(function (plugin) {
      return '<button class="musicfree-tag' + (currentMusicFreePluginFilter === plugin.id ? ' active' : '') + '" type="button" title="' + escHtml(plugin.platform || plugin.label) + '" onclick="setMusicFreeSearchPlugin(\'' + plugin.id + '\')">' + escHtml(plugin.label) + '</button>';
    }).join('');
  if (input) {
    var selected = musicFreePlugins.filter(function (plugin) { return plugin.id === currentMusicFreePluginFilter; })[0];
    input.placeholder = selected ? ('使用「' + selected.label + '」搜索歌曲、歌手…') : '搜索歌曲、歌手…';
  }
}

function renderMusicFreeSourceList() {
  var list = document.getElementById('musicfree-source-list');
  var count = document.getElementById('musicfree-source-count');
  var loaded = musicFreePlugins.filter(function (plugin) { return plugin.loaded; });
  if (count) count.textContent = loaded.length ? ('已启用 ' + loaded.length + ' 个音源 · 点击管理') : '还没有可用音源 · 点击导入';
  if (!list) return;
  if (!musicFreePlugins.length) {
    list.innerHTML = '<div class="musicfree-source-empty">暂无音源，请从本地或网络导入。</div>';
    return;
  }
  var groups = [];
  var byKey = Object.create(null);
  musicFreePlugins.forEach(function (plugin) {
    var key = plugin.manifestUrl ? ('manifest:' + plugin.manifestUrl) : ('plugin:' + plugin.id);
    if (!byKey[key]) {
      byKey[key] = { key: key, manifestUrl: plugin.manifestUrl || '', pluginId: plugin.manifestUrl ? '' : plugin.id, plugins: [] };
      groups.push(byKey[key]);
    }
    byKey[key].plugins.push(plugin);
  });
  list.innerHTML = groups.map(renderMusicFreeSourceGroup).join('');
}

function musicFreeGroupName(group) {
  if ((MUSICFREE_DEFAULT_MANIFEST_URL && group.manifestUrl === MUSICFREE_DEFAULT_MANIFEST_URL) || /\/yuanli(?:\/|\.json|$)/i.test(group.manifestUrl)) return '元力';
  if (!group.manifestUrl) return (group.plugins[0] && (group.plugins[0].label || group.plugins[0].platform)) || '本地音源';
  try {
    var parsed = new URL(group.manifestUrl);
    var parts = parsed.pathname.split('/').filter(Boolean);
    var raw = parts.length > 1 ? parts[parts.length - 2] : String(parts[0] || parsed.hostname);
    return decodeURIComponent(raw).replace(/[-_]+/g, ' ') || '网络音源';
  } catch (_) { return '网络音源'; }
}

function musicFreeGroupPayload(group) {
  return encodeURIComponent(JSON.stringify({ manifestUrl: group.manifestUrl || '', pluginId: group.pluginId || '' }));
}

function musicFreePluginBuiltIn(plugin) {
  return !!(plugin && plugin.builtIn === true);
}

function renderMusicFreeSourceGroup(group) {
  var enabledCount = group.plugins.filter(function (plugin) { return plugin.enabled !== false; }).length;
  var loadedCount = group.plugins.filter(function (plugin) { return plugin.loaded; }).length;
  var allEnabled = enabledCount === group.plugins.length;
  var builtInGroup = group.plugins.some(musicFreePluginBuiltIn);
  var expanded = !!expandedMusicFreeGroups[group.key];
  var payload = musicFreeGroupPayload(group);
  var detail = group.plugins.map(function (plugin) {
    var pluginPayload = encodeURIComponent(JSON.stringify({ manifestUrl: '', pluginId: plugin.id || '' }));
    return '<div class="musicfree-source-item' + (plugin.loaded ? '' : ' failed') + '">' +
      '<span class="musicfree-source-badge">' + escHtml(String(plugin.label || '?').slice(0, 2).toUpperCase()) + '</span>' +
      '<span><b>' + escHtml(plugin.label || plugin.platform || '未命名音源') + (musicFreePluginBuiltIn(plugin) ? ' <em class="musicfree-builtin-chip">内置</em>' : '') + '</b><small>' + escHtml(plugin.platform || '') + ' · v' + escHtml(plugin.version || '0.0.0') + (plugin.local ? ' · 本地' : ' · 网络') + ' · ' + escHtml(plugin.runtimeStatus || (plugin.loaded ? 'ready' : 'unloaded')) + (plugin.configured === false ? ' · 需要配置后使用' : '') + '</small></span>' +
      '<span class="musicfree-source-item-actions">' + (plugin.requiresConfiguration ? '<button type="button" title="配置插件变量" onclick="configureMusicFreeSource(\'' + plugin.id + '\')">配置</button>' : '') +
      '<button type="button" title="测试搜索、播放、歌词和封面" onclick="diagnoseMusicFreeSource(\'' + plugin.id + '\')">检测</button>' +
      '<button type="button" title="' + (plugin.enabled === false ? '启用这个音源' : '停用这个音源') + '" onclick="setMusicFreeGroupEnabled(\'' + pluginPayload + '\',' + (plugin.enabled === false) + ')">' + (plugin.enabled === false ? '启用' : '停用') + '</button>' +
      (musicFreePluginBuiltIn(plugin) ? '<span class="musicfree-builtin-lock" title="内置音源只能停用，不能删除">不可删除</span>' : '<button type="button" class="danger" title="删除这个平台音源" onclick="removeMusicFreeSource(\'' + plugin.id + '\')">删除</button>') + '</span>' +
    '</div>';
  }).join('');
  return '<section class="musicfree-source-group' + (allEnabled ? '' : ' disabled') + '">' +
    '<div class="musicfree-source-group-main">' +
      '<span class="musicfree-source-group-icon">MF</span>' +
      '<span class="musicfree-source-group-copy"><span class="musicfree-source-group-title"><b>' + escHtml(musicFreeGroupName(group)) + '</b><em>MusicFree</em></span>' +
        '<small>' + group.plugins.length + ' 个平台 · ' + loadedCount + ' 个已加载' + (allEnabled ? '' : ' · 已禁用') + '</small></span>' +
      '<button class="musicfree-group-expand" type="button" onclick="toggleMusicFreeGroup(\'' + encodeURIComponent(group.key) + '\')">' + (expanded ? '收起' : '展开') + '</button>' +
    '</div>' +
    '<div class="musicfree-source-group-actions">' +
      '<button type="button" onclick="setMusicFreeGroupEnabled(\'' + payload + '\',' + (!allEnabled) + ')">' + (allEnabled ? '整体禁用' : '整体启用') + '</button>' +
      (builtInGroup ? '<span class="musicfree-builtin-lock" title="内置音源包只能停用，不能删除">内置音源</span>' : '<button class="danger" type="button" onclick="removeMusicFreeGroup(\'' + payload + '\')">整体删除</button>') +
    '</div>' +
    '<div class="musicfree-source-group-detail' + (expanded ? ' show' : '') + '">' + detail + '</div>' +
  '</section>';
}

function ensureMusicFreeConfigModal() {
  var mask = document.getElementById('musicfree-config-modal');
  if (mask) return mask;
  mask = document.createElement('div');
  mask.id = 'musicfree-config-modal';
  mask.className = 'modal-mask';
  mask.innerHTML = '<div class="modal musicfree-source-modal musicfree-config-modal">' +
    '<div class="musicfree-source-head"><div><small>PLUGIN VARIABLES</small><h2 id="musicfree-config-title">插件配置</h2><p>配置仅保存在本机，不会显示已保存的敏感值。</p></div>' +
    '<button type="button" onclick="closeMusicFreeConfigModal()" aria-label="关闭">×</button></div>' +
    '<div id="musicfree-config-fields" class="musicfree-config-fields"></div>' +
    '<div class="musicfree-config-actions"><button type="button" onclick="closeMusicFreeConfigModal()">取消</button><button class="primary" type="button" onclick="saveMusicFreeConfig()">保存并重载</button></div>' +
  '</div>';
  document.body.appendChild(mask);
  mask.addEventListener('click', function (event) { if (event.target === mask) closeMusicFreeConfigModal(); });
  return mask;
}

function closeMusicFreeConfigModal() { closeGsapModal(document.getElementById('musicfree-config-modal')); }

function configureMusicFreeSource(id) {
  var plugin = musicFreePlugins.filter(function (item) { return item.id === id; })[0];
  if (!plugin) return;
  var mask = ensureMusicFreeConfigModal();
  mask.dataset.pluginId = id;
  document.getElementById('musicfree-config-title').textContent = (plugin.label || '音源') + ' · 配置';
  document.getElementById('musicfree-config-fields').innerHTML = (plugin.configurationFields || []).map(function (field) {
    var secret = /token|secret|pass|password|cookie|key/i.test(field.key || '') || /password/i.test(field.type || '');
    return '<label><span><b>' + escHtml(field.name || field.key) + '</b><small>' + escHtml(field.description || '') + '</small></span>' +
      '<input data-key="' + escHtml(field.key) + '" type="' + (secret ? 'password' : 'text') + '" placeholder="' + (field.hasValue ? '已保存，留空保持原值' : '请输入配置值') + '" autocomplete="off"></label>';
  }).join('');
  openGsapModal(mask);
}

async function saveMusicFreeConfig() {
  var mask = document.getElementById('musicfree-config-modal');
  if (!mask || !mask.dataset.pluginId) return;
  var values = {};
  Array.prototype.forEach.call(mask.querySelectorAll('[data-key]'), function (input) {
    if (input.value !== '') values[input.dataset.key] = input.value;
  });
  try {
    var result = await musicFreeApi('/api/musicfree/plugins/' + encodeURIComponent(mask.dataset.pluginId) + '/config', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ values: values }), timeoutMs: 20000
    });
    if (!result || result.ok === false) throw new Error(result && result.error || '保存失败');
    closeMusicFreeConfigModal();
    await refreshMusicFreeSources();
    musicFreeSourceStatus('插件配置已保存并重新加载');
  } catch (error) { musicFreeSourceStatus('配置失败：' + (error.message || error), true); }
}

function ensureMusicFreeDiagnosticCenter() {
  var mask = document.getElementById('musicfree-diagnostic-modal');
  if (mask) return mask;
  mask = document.createElement('div');
  mask.id = 'musicfree-diagnostic-modal';
  mask.className = 'modal-mask';
  mask.innerHTML = '<div class="modal musicfree-source-modal musicfree-diagnostic-modal">' +
    '<div class="musicfree-source-head"><div><small>MUSICFREE DIAGNOSTICS</small><h2 id="musicfree-diagnostic-title">音源诊断</h2><p>真实调用搜索、播放地址、歌词和封面接口。</p></div>' +
    '<button type="button" onclick="closeMusicFreeDiagnosticCenter()" aria-label="关闭">×</button></div>' +
    '<div id="musicfree-diagnostic-content" class="musicfree-diagnostic-content"></div>' +
  '</div>';
  document.body.appendChild(mask);
  mask.addEventListener('click', function (event) { if (event.target === mask) closeMusicFreeDiagnosticCenter(); });
  return mask;
}

function closeMusicFreeDiagnosticCenter() {
  closeGsapModal(document.getElementById('musicfree-diagnostic-modal'));
}

function musicFreeDiagnosticCheck(label, check) {
  check = check || {};
  var detail = check.detail || {};
  var summary = check.ok
    ? [detail.track && (detail.track.title + ' · ' + detail.track.artist), detail.level, detail.mediaType, detail.source, detail.length ? (detail.length + ' 字符') : ''].filter(Boolean).join(' · ')
    : (check.error || '未执行');
  return '<div class="musicfree-diagnostic-check ' + (check.ok ? 'ok' : 'failed') + '"><span>' + escHtml(label) + '</span><b>' + (check.ok ? '通过' : '失败') + '</b><small>' + escHtml(summary) + ' · ' + Number(check.durationMs || 0) + 'ms</small></div>';
}

async function diagnoseMusicFreeSource(id) {
  var plugin = musicFreePlugins.filter(function (item) { return item.id === id; })[0] || {};
  var mask = ensureMusicFreeDiagnosticCenter();
  var title = document.getElementById('musicfree-diagnostic-title');
  var content = document.getElementById('musicfree-diagnostic-content');
  if (title) title.textContent = (plugin.label || '音源') + ' · 诊断';
  if (content) content.innerHTML = '<div class="musicfree-diagnostic-loading">正在执行真实接口测试…</div>';
  openGsapModal(mask);
  try {
    var result = await musicFreeApi('/api/musicfree/diagnose', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pluginId: id, query: '稻香' }), timeoutMs: 45000
    });
    var checks = result.checks || {};
    content.innerHTML = '<div class="musicfree-diagnostic-summary ' + (result.ok ? 'ok' : 'failed') + '">' +
      '<b>' + (result.ok ? '音源核心链路可用' : '音源存在异常') + '</b><small>' + escHtml(result.platform || result.label || '') + ' · 总耗时 ' + Number(result.durationMs || 0) + 'ms</small></div>' +
      '<div class="musicfree-diagnostic-grid">' +
        musicFreeDiagnosticCheck('搜索', checks.search) + musicFreeDiagnosticCheck('播放', checks.play) +
        musicFreeDiagnosticCheck('歌词', checks.lyrics) + musicFreeDiagnosticCheck('封面', checks.cover) +
      '</div>';
  } catch (error) {
    content.innerHTML = '<div class="musicfree-diagnostic-summary failed"><b>诊断未完成</b><small>' + escHtml(error.message || String(error)) + '</small></div>';
  }
}

function toggleMusicFreeGroup(encodedKey) {
  var key = decodeURIComponent(encodedKey || '');
  expandedMusicFreeGroups[key] = !expandedMusicFreeGroups[key];
  renderMusicFreeSourceList();
}

async function musicFreeGroupAction(encodedPayload, action) {
  var payload = {};
  try { payload = JSON.parse(decodeURIComponent(encodedPayload || '')); } catch (_) { return; }
  payload.action = action;
  var result = await musicFreeApi('/api/musicfree/group-action', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  });
  if (!result || result.ok === false) throw new Error(result && result.error || '操作失败');
  await refreshMusicFreeSources();
}

async function setMusicFreeGroupEnabled(encodedPayload, enabled) {
  try {
    await musicFreeGroupAction(encodedPayload, enabled ? 'enable' : 'disable');
    musicFreeSourceStatus(enabled ? '音源包已整体启用' : '音源包已整体禁用');
  } catch (error) { musicFreeSourceStatus('操作失败：' + (error.message || error), true); }
}

async function removeMusicFreeGroup(encodedPayload) {
  try {
    await musicFreeGroupAction(encodedPayload, 'remove');
    musicFreeSourceStatus('音源包已整体删除');
  } catch (error) { musicFreeSourceStatus('整体删除失败：' + (error.message || error), true); }
}

async function refreshMusicFreeSources() {
  ensureMusicFreeSourceControls();
  ensureMusicFreeSourceManager();
  try {
    var data = await musicFreeApi('/api/musicfree/plugins');
    musicFreePlugins = Array.isArray(data && data.plugins) ? data.plugins : [];
    if (data && data.defaultManifestUrl) MUSICFREE_DEFAULT_MANIFEST_URL = data.defaultManifestUrl;
    renderMusicFreeSourceList();
    renderMusicFreeSearchTags();
    return musicFreePlugins;
  } catch (error) {
    musicFreeSourceStatus('读取音源失败：' + (error.message || error), true);
    return [];
  }
}

function chooseLocalMusicFreeSource() {
  var input = document.getElementById('musicfree-local-input');
  if (input) input.click();
}

async function importLocalMusicFreeFiles(files) {
  files = Array.prototype.slice.call(files || []);
  if (!files.length || musicFreeImportBusy) return;
  musicFreeImportBusy = true;
  openMusicFreeSourceManager();
  var imported = 0;
  var failed = [];
  try {
    for (var i = 0; i < files.length; i++) {
      var file = files[i];
      musicFreeSourceStatus('正在导入 ' + file.name + '…');
      try {
        var isZip = /\.zip$/i.test(file.name || '');
        var source = isZip ? '' : await file.text();
        var zipBase64 = '';
        if (isZip) {
          zipBase64 = await new Promise(function (resolve, reject) {
            var reader = new FileReader();
            reader.onerror = function () { reject(reader.error || new Error('ZIP 读取失败')); };
            reader.onload = function () { resolve(String(reader.result || '').split(',')[1] || ''); };
            reader.readAsDataURL(file);
          });
        }
        var result = await musicFreeApi('/api/musicfree/import-local', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: file.name, source: source, zipBase64: zipBase64 })
        });
        if (!result || result.ok === false) throw new Error(result && result.error || '导入失败');
        imported += Array.isArray(result.imported) ? result.imported.length : 1;
      } catch (error) { failed.push(file.name + ': ' + (error.message || error)); }
    }
    await refreshMusicFreeSources();
    musicFreeSourceStatus('已导入 ' + imported + ' 个音源' + (failed.length ? ('，失败 ' + failed.length + ' 个') : ''), !!failed.length);
    showToast(failed.length ? '部分音源导入失败' : '本地音源导入完成');
  } finally { musicFreeImportBusy = false; }
}

async function importNetworkMusicFreeSource() {
  if (musicFreeImportBusy) return;
  var input = document.getElementById('musicfree-network-url');
  var url = String(input && input.value || '').trim();
  if (!url) { musicFreeSourceStatus('请输入音源 JS 或 JSON 清单地址', true); return; }
  musicFreeImportBusy = true;
  musicFreeSourceStatus('正在下载并验证音源…');
  try {
    var result = await musicFreeApi('/api/musicfree/import-network', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: url })
    });
    if (!result || result.ok === false) throw new Error(result && result.error || '导入失败');
    await refreshMusicFreeSources();
    if (input) input.value = '';
    var imported = Array.isArray(result.imported) ? result.imported.length : 0;
    var failures = Array.isArray(result.failures) ? result.failures.length : 0;
    musicFreeSourceStatus('已导入 ' + imported + ' 个音源' + (failures ? ('，' + failures + ' 个下载失败') : ''), !!failures);
    showToast('网络音源导入完成');
  } catch (error) {
    musicFreeSourceStatus('导入失败：' + (error.message || error), true);
    showToast('网络音源导入失败');
  } finally { musicFreeImportBusy = false; }
}

async function reloadMusicFreeSources() {
  musicFreeSourceStatus('正在重新加载音源…');
  try {
    await musicFreeApi('/api/musicfree/reload', { method: 'POST' });
    await refreshMusicFreeSources();
    musicFreeSourceStatus('音源已重新加载');
  } catch (error) { musicFreeSourceStatus('重新加载失败：' + (error.message || error), true); }
}

async function removeMusicFreeSource(id) {
  if (!id) return;
  try {
    await musicFreeApi('/api/musicfree/plugins/' + encodeURIComponent(id), { method: 'DELETE' });
    await refreshMusicFreeSources();
    musicFreeSourceStatus('音源已删除');
  } catch (error) { musicFreeSourceStatus('删除失败：' + (error.message || error), true); }
}

function openMusicFreeSourceManager() {
  var mask = ensureMusicFreeSourceManager();
  openGsapModal(mask);
  refreshMusicFreeSources();
}

function closeMusicFreeSourceManager() {
  closeGsapModal(document.getElementById('musicfree-source-modal'));
}

ensureMusicFreeSourceControls();
ensureMusicFreeSourceManager();
setTimeout(refreshMusicFreeSources, 0);
