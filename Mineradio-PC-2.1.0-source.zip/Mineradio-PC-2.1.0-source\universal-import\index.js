'use strict';

const path = require('path');
const { PlaylistDatabase } = require('./playlist-database');
const { UniversalImportService } = require('./import-service');
const { PlaylistSyncEngine } = require('./sync-engine');

function createUniversalImport(options) {
  const database = new PlaylistDatabase(options.databaseFile || path.join(options.appRoot, 'data', 'universal-import-playlists.json'));
  const parse = options.parse;
  const service = new UniversalImportService({ database, parse });
  const sync = new PlaylistSyncEngine({ database, parse, intervalMs: options.intervalMs || 5000 });
  return { database, service, sync };
}

module.exports = { createUniversalImport };
