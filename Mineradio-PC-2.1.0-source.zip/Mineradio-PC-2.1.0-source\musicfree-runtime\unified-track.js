'use strict';

const crypto = require('crypto');

const TRACK_SCHEMA_VERSION = 1;

function text(value, fallback = '') {
  if (Array.isArray(value)) return value.map(item => text(item)).filter(Boolean).join(' / ');
  if (value && typeof value === 'object') return text(value.name || value.title || value.value, fallback);
  const normalized = String(value == null ? '' : value).trim();
  return normalized || fallback;
}

function stableId(value) {
  return crypto.createHash('sha256').update(String(value || '')).digest('hex').slice(0, 20);
}

function clone(value) {
  try { return JSON.parse(JSON.stringify(value)); }
  catch (_) { return null; }
}

function durationMs(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number) || number <= 0) return 0;
  return number < 100000 ? Math.round(number * 1000) : Math.round(number);
}

function qualityLevels(item) {
  const source = item && (item.qualities || item.quality || item.qualitys || item.br || item.bitrate);
  const output = [];
  const push = value => {
    const key = text(value && typeof value === 'object' ? (value.level || value.quality || value.name || value.key) : value).toLowerCase();
    if (key && !output.includes(key)) output.push(key);
  };
  if (Array.isArray(source)) source.forEach(push);
  else if (source && typeof source === 'object') Object.keys(source).forEach(key => {
    if (source[key] !== false && source[key] != null) push(key);
  });
  else push(source);
  return output;
}

function createUnifiedTrack(item, runtime = {}, options = {}) {
  const raw = clone(item) || {};
  const title = text(item && (item.title || item.name || item.songName), '未知歌曲');
  const artist = text(item && (item.artist || item.artists || item.singer || item.author), '未知歌手');
  const album = text(item && (item.album || item.albumName));
  const artwork = text(item && (item.artwork || item.cover || item.pic || item.image));
  const pluginId = text(runtime.id || options.pluginId);
  const platform = text(runtime.platform || runtime.label || options.platform);
  const mediaType = /^bilibili$/i.test(platform) ? 'video' : 'audio';
  const fallbackPolicy = text(runtime.fallbackPolicy || options.fallbackPolicy).toLowerCase();
  const qualityPolicy = text(runtime.qualityPolicy || options.qualityPolicy).toLowerCase();
  const sourceId = item && (item.id || item.mid || item.hash || item.songmid || item.rid || item.url);
  const id = text(sourceId) || stableId([pluginId, title, artist, album].join('|'));
  const rawLyric = text(item && (item.rawLrc || item.lyric || item.lrc));
  const translatedLyric = text(item && (item.translation || item.trans || item.tlyric || item.translatedLyric));
  const levels = qualityLevels(item);

  return {
    schemaVersion: TRACK_SCHEMA_VERSION,
    id,
    title,
    artist,
    album,
    cover: artwork,
    duration: item && item.durationMs != null
      ? Math.max(0, Number(item.durationMs) || 0)
      : durationMs(item && item.duration),
    mediaType,
    source: {
      runtime: 'musicfree',
      pluginId,
      platform,
      itemId: text(sourceId || id),
      fallbackPolicy,
      qualityPolicy,
    },
    quality: {
      available: levels,
      selected: '',
      format: '',
      bitrate: 0,
    },
    playUrl: text(item && item.url),
    lyrics: {
      raw: rawLyric,
      translated: translatedLyric,
      format: rawLyric ? 'lrc' : '',
      offsetMs: 0,
    },
    _pluginPayload: raw,
  };
}

function toLegacySong(track) {
  const source = track && track.source || {};
  const lyrics = track && track.lyrics || {};
  return Object.assign({}, track, {
    unifiedSource: Object.assign({}, source),
    name: track.title,
    artwork: track.cover,
    provider: 'musicfree',
    source: 'musicfree',
    musicFreePluginId: source.pluginId || '',
    musicFreeLabel: source.platform || '',
    musicFreePlatform: source.platform || '',
    musicFreeFallbackPolicy: source.fallbackPolicy || '',
    musicFreeQualityPolicy: source.qualityPolicy || '',
    musicFreeSourceOnly: source.fallbackPolicy === 'source-only',
    mediaType: track.mediaType === 'video' ? 'video' : 'audio',
    musicFreeItem: clone(track._pluginPayload) || {},
    musicFreeAvailableQualities: track.quality && track.quality.available || [],
    playable: true,
    url: track.playUrl || '',
    lyric: lyrics.raw || '',
  });
}

function isUnifiedTrack(value) {
  return !!(value && value.schemaVersion === TRACK_SCHEMA_VERSION && value.source && value.source.runtime === 'musicfree');
}

module.exports = { TRACK_SCHEMA_VERSION, createUnifiedTrack, toLegacySong, isUnifiedTrack, durationMs, qualityLevels };
